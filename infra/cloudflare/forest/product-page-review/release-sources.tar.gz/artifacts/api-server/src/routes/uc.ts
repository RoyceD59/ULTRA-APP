import { validateCustomerContact } from "@workspace/api-zod/customer-contact";
import { orderEvidence } from "../lib/order-evidence.js";
import { receiptOrderPaymentStatus } from "@workspace/api-zod/order-receipt";
import { checkoutQuote, claimReferralBenefit, type Fulfillment } from "../lib/checkout-pricing.js";
import { prepareCheckoutOrder, confirmCheckoutOrder, checkoutOrderResponse } from "../lib/checkout-orders.js";
import { enqueueReferralSettlement } from "./referrals.js";
import { effectiveEditorial } from "../lib/product-editorial.js";
import { readCompanionCollection, readCompanionProduct } from "../lib/companion-catalogue.js";
import { CatalogueCache } from "../lib/catalogue-cache.js";
import { Router, type Request, type Response } from "express";
import { createHash, randomBytes, randomUUID } from "node:crypto";
import { appendFile, readFile, writeFile, rename } from "node:fs/promises";
import { join } from "node:path";

// Durable data folder — shared with the account-records module, which
// resolves it correctly for both the bundled runtime and tsx-run tests.
const UC_DATA_DIR = ACCOUNT_DATA_DIR;
import {
  validateCodeForDiscount,
  registerReferralAtSignupWithClient,
  getReferralExportData,
} from "./referrals";
import { sanitiseCsvCell } from "./uc-water-chat.js";
import { issueToken, verifyToken } from "../lib/jwt.js";
import { isAdminRequest } from "../lib/adminAuth.js";
import { validateCodShipping } from "../lib/order-validation.js";
import { normalizeInternationalPhone, countryCodeFromValue } from "@workspace/api-zod/phone";
import { remoteImageProxyPath } from "./product-images.js";
import { authLimiter, lookupLimiter, locationQualityLimiter } from "../lib/rate-limiters.js";
import { getWhatsAppStatus, sendWhatsAppMessage } from "../lib/whatsapp.js";
import {
  sendSms,
  orderConfirmationSms,
  ticketConfirmationSms,
  waterTestConfirmationSms,
} from "../lib/sms.js";
import {
  sendEmail,
  buildOrderReceiptEmail,
  buildTicketConfirmationEmail,
  buildWaterTestConfirmationEmail,
  orderReceiptSerial,
} from "../lib/email.js";
import { promoUtmParams, promoUtmQuery } from "../lib/utm.js";
import { decryptSecret } from "../lib/secret-crypto.js";
import { ssrfSafePost, SsrfBlockedError } from "../lib/ssrf-safe-fetch.js";
import { sendViaResend } from "../lib/resend.js";
import { sendSlackTeamMessage } from "../lib/slack.js";
import { ucApiBaseUrl } from "../lib/uc-reset-url.js";
import {
  pool,
  db,
  ucPushTokensTable, ucEnquiriesTable, ucNotifPrefsTable,
  ucUsersTable, ucOrdersTable, ucOrderItemsTable, ucTicketsTable, ucWaterTestsTable,
  ucReviewsTable, ucProductMediaTable, ucNotificationLogTable, mpesaStkInitiationsTable,
  ucLifespanAlertsTable, teamSettingsTable, passwordResetTokensTable, ucWishlistTable,
  ucRestockDemandAlertsTable, ucRegisteredFiltersTable, ucWaterImpactLedgerTable,
  ucRewardConversionTable, ucLocationsTable, teamUsersTable, ucPasswordResetAuditTable,
  ucContactVerificationTokensTable, ucLocationRatingsTable, ucLocationRatingReportsTable,
  ucLocationAssessmentsTable,
  type ReviewMediaItem, type UcProductMedia,
} from "@workspace/db";
import { eq, desc, inArray, notInArray, and, asc, ne, gt, or, sql, isNull } from "drizzle-orm";
import bcryptjs from "bcryptjs";
import { logger } from "../lib/logger";
import { ACCOUNT_DATA_DIR, recordAccountRegistration } from "../lib/account-records";
import { normalizeEmail, normalizePhone, phoneValidationMessage } from "../lib/customer-identity";
import { resolveCustomerIdentity } from "../lib/customer-identity-resolution.js";
import {
  MAX_IMAGE_BYTES,
  MAX_VIDEO_BYTES,
  ObjectNotFoundError,
  ObjectStorageService,
} from "../lib/objectStorage";
import { verifyReviewMediaContent, mediaMimeFamily } from "../lib/review-media-signature.js";
import { creditQualifyingProductPoints } from "../lib/reminder-dispatch.js";
import { sendPushToUser, getPushTokenRow, callExpoPushApi, removePushToken } from "../lib/push.js";
import {
  checkRestockDemandForProduct,
  getRestockDemandThreshold,
  projectHubInventoryUrl,
} from "../lib/wishlist-demand.js";
import { quotePromotion, consumePromotionOnClient, type PromotionQuote } from "../lib/reward-promotions.js";
import { appPurchaseOwnedBy, storePurchaseOwnedBy } from "../lib/purchase-ownership.js";
import { transitionOrderStatus, ORDER_CUSTOMER_STAGES } from "../lib/order-status-pipeline.js";
import {
  reconcileCanonicalPurchaseDualWrite,
  CanonicalPurchaseDualWriteError,
} from "../lib/canonical-purchase-dual-write.js";
import { isCustomerLifecycleFlagEnabled } from "../lib/customer-lifecycle-flags.js";

class CheckoutKeyOwnershipConflict extends Error {
  readonly code = "CHECKOUT_KEY_OWNERSHIP_CONFLICT";
  constructor() {
    super("Checkout idempotency key is already in use");
    this.name = "CheckoutKeyOwnershipConflict";
  }
}

const router = Router();

// ─── Mock data ────────────────────────────────────────────────────────────────
// Real Ultra Clear 2026 product catalogue — 5 segments, 27 products.
// When WooCommerce credentials are present these are bypassed entirely.
const CAT_BOTTLES   = { id: 1, name: "Bottles & Portable" };
const CAT_HOME      = { id: 2, name: "Home Filters" };
const CAT_SHOWER    = { id: 3, name: "Shower & Skin" };
const CAT_ACCESS    = { id: 4, name: "Accessories" };
const CAT_SOLUTIONS = { id: 5, name: "Solutions" };

export const MOCK_PRODUCTS: Record<string, unknown>[] = [
  // ── Segment 01 · Bottles & Portable Filters ──────────────────────────────
  {
    id: 1, name: "Hydra Flux", sku: "UC-BTL-HFX-001",
    price: "3499", regularPrice: "3499", salePrice: "",
    lifespanDays: 90,
    tagline: "Certified hydration, elevated.",
    description: "750ml BPA-free filter bottle with SGS-certified >99.9% bacteria removal. Ahlstrom Disruptor® filter. 60-second cartridge swap. Available in 4 colours. Filter: 150L or 3 months — whichever comes first.",
    shortDescription: "750ml certified filter bottle — 4 colours",
    categories: [CAT_BOTTLES],
    images: [{ src: "/api/uc/product-images/hydra-flux-premium-filter-bottle.jpg", alt: "Hydra Flux" }],
    stockStatus: "instock", stockQuantity: 30,
    tags: [{ name: "bestseller" }],
  },
  {
    id: 2, name: "Truva Go", sku: "UC-BTL-TGO-002",
    price: "2599", regularPrice: "2599", salePrice: "",
    lifespanDays: 90,
    tagline: "Slim. Certified. Goes everywhere you go.",
    description: "Slim 750ml BPA-free filter bottle for urban commuters. Fits any bike holder or bag. Ahlstrom Disruptor® filter. 60-second filter replacement. SGS-certified. Filter: 150L or 3 months.",
    shortDescription: "Slim 750ml certified filter bottle for commuters",
    categories: [CAT_BOTTLES],
    images: [{ src: "/api/uc/product-images/truva-go-slim-filter-bottle.jpg", alt: "Truva Go" }],
    stockStatus: "instock", stockQuantity: 25,
    tags: [],
  },
  {
    id: 3, name: "Viva Drop", sku: "UC-BTL-VDP-003",
    price: "2199", regularPrice: "2199", salePrice: "",
    lifespanDays: 90,
    tagline: "Compact. Certified. Carry it everywhere.",
    description: "Compact 500ml BPA-free filter bottle for desk, commute, campus, and gym. Ahlstrom Disruptor® filter with SGS-certified bacteria removal. Replaces daily plastic bottle purchases. Filter: 150L or 3 months.",
    shortDescription: "500ml compact certified filter bottle",
    categories: [CAT_BOTTLES],
    images: [{ src: "/api/uc/product-images/viva-drop-compact-filter-bottle.jpg", alt: "Viva Drop" }],
    stockStatus: "instock", stockQuantity: 40,
    tags: [],
  },
  {
    id: 4, name: "Flex", sku: "UC-BTL-FLX-004",
    price: "2399", regularPrice: "2399", salePrice: "",
    lifespanDays: 90,
    tagline: "1 litre. Squeezable. Certified clean.",
    description: "1000ml squeezable BPA-free filter bottle. Ahlstrom Disruptor® filter with SGS-certified bacteria removal. Great for hiking, travel, and outdoor use. Filter: 150L or 3 months.",
    shortDescription: "1L squeezable certified filter bottle",
    categories: [CAT_BOTTLES],
    images: [{ src: "/api/uc/product-images/flex-squeezable-filter-bottle.jpg", alt: "Flex" }],
    stockStatus: "instock", stockQuantity: 20,
    tags: [],
  },
  {
    id: 5, name: "Timbo", sku: "UC-BTL-TMB-005",
    price: "1299", regularPrice: "1299", salePrice: "",
    lifespanDays: 90,
    tagline: "350ml. Kids. Certified safe.",
    description: "350ml BPA-free kids' filter bottle. SGS-certified bacteria removal keeps your child's water safe at school, sports, and on the go. Easy-squeeze design. Filter: 150L or 3 months.",
    shortDescription: "350ml kids' certified filter bottle",
    categories: [CAT_BOTTLES],
    images: [{ src: "/api/uc/product-images/timbo-kids-filter-bottle.jpg", alt: "Timbo" }],
    stockStatus: "instock", stockQuantity: 35,
    tags: [],
  },
  {
    id: 6, name: "Gym Buddy", sku: "UC-BTL-GYM-006",
    price: "2799", regularPrice: "2799", salePrice: "",
    lifespanDays: 90,
    tagline: "1.2L. Certified. Built for the grind.",
    description: "1200ml motivational filter bottle for gym-goers and athletes. SGS-certified bacteria removal. Wide-mouth design for ice. Ahlstrom Disruptor® filter. Filter: 150L or 3 months.",
    shortDescription: "1.2L motivational certified filter bottle",
    categories: [CAT_BOTTLES],
    images: [{ src: "/api/uc/product-images/gym-buddy-1-2l-training-filter-bottle.jpg", alt: "Gym Buddy" }],
    stockStatus: "instock", stockQuantity: 20,
    tags: [],
  },
  {
    id: 7, name: "Survivor Straw", sku: "UC-STR-SVV-007",
    price: "1299", regularPrice: "1299", salePrice: "",
    lifespanDays: 120,
    tagline: "Drink safe from any source.",
    description: "Portable emergency filter straw. SGS-certified filtration — drink directly from streams, taps, or any water source. Lightweight and compact. Filter: 400L or 4 months — whichever comes first.",
    shortDescription: "Portable certified emergency filter straw",
    categories: [CAT_BOTTLES],
    images: [{ src: "/api/uc/product-images/survivor-straw-filter.jpg", alt: "Survivor Straw" }],
    stockStatus: "instock", stockQuantity: 50,
    tags: [],
  },
  {
    id: 8, name: "Breeze", sku: "UC-BTL-BRZ-008",
    price: "1699", regularPrice: "1699", salePrice: "",
    lifespanDays: 90,
    tagline: "Entry-level certified filtration.",
    description: "500ml entry-level BPA-free filter bottle. SGS-certified bacteria removal. Ideal first certified filter bottle. Ahlstrom Disruptor® filter. Filter: 150L or 3 months.",
    shortDescription: "500ml entry-level certified filter bottle",
    categories: [CAT_BOTTLES],
    images: [{ src: "/api/uc/product-images/breeze-filter-bottle.jpg", alt: "Breeze" }],
    stockStatus: "instock", stockQuantity: 45,
    tags: [],
  },
  {
    id: 9, name: "EcoSmart Elite", sku: "UC-ESE-ELT-009",
    price: "9799", regularPrice: "9799", salePrice: "",
    lifespanDays: 90,
    tagline: "Solar. Electric. Always clean.",
    description: "Advanced portable filter with solar charging, electric pump, and built-in power bank. Multi-stage filtration: Nylon Mesh, UF Membrane 0.01µm, Ahlstrom Disruptor®, Carbon Block. Filter: 400L or 3 months — whichever comes first.",
    shortDescription: "Solar-powered certified portable filter with power bank",
    categories: [CAT_BOTTLES],
    images: [{ src: "/api/uc/product-images/ecosmart-elite-field-purifier.jpg", alt: "EcoSmart Elite" }],
    stockStatus: "instock", stockQuantity: 10,
    tags: [{ name: "premium" }],
  },

  // ── Segment 02 · Home Water Filters ──────────────────────────────────────
  {
    id: 11, name: "Sweet Home", sku: "UC-FCT-SWH-011",
    price: "3699", regularPrice: "3699", salePrice: "",
    lifespanDays: 120,
    tagline: "Your tap. Certified. In under 5 minutes.",
    description: "Clips onto your kitchen tap in under 5 minutes — no tools, no plumber, no drilling. SGS-certified >99.9% bacteria removal. Removes chlorine, sediment, and selected heavy metals that boiling leaves behind. Filter: 4–5 months.",
    shortDescription: "Faucet filter — tool-free, SGS-certified, 4–5 month filter",
    categories: [CAT_HOME],
    images: [{ src: "/api/uc/product-images/sweet-home-faucet-filter.jpg", alt: "Sweet Home" }],
    stockStatus: "instock", stockQuantity: 30,
    tags: [{ name: "bestseller" }],
  },
  {
    id: 12, name: "Counter Reverse Osmosis", sku: "UC-HOM-CRO-012",
    price: "38999", regularPrice: "38999", salePrice: "",
    lifespanDays: 180,
    tagline: "Full RO purity. No drilling. No plumber.",
    description: "Counter-top reverse osmosis delivering multi-stage RO-grade purity without under-sink installation. Sits on your kitchen counter, connects to any standard tap. Removes bacteria, dissolved solids, heavy metals, and chlorine. Ideal for renters and apartments. SGS-certified. Filter: 6 months.",
    shortDescription: "Counter-top RO — no plumbing, SGS-certified, 6-month filter",
    categories: [CAT_HOME],
    images: [{ src: "/api/uc/product-images/counter-reverse-osmosis-system.jpg", alt: "Counter Reverse Osmosis" }],
    stockStatus: "instock", stockQuantity: 8,
    tags: [{ name: "premium" }],
  },
  {
    id: 13, name: "Electric Pitcher", sku: "UC-PCT-ELP-013",
    price: "10999", regularPrice: "10999", salePrice: "",
    lifespanDays: 90,
    tagline: "Counter-top certified water. No installation required.",
    description: "Ultra Clear's counter-top electric filtration pitcher — certified clean water without any tap attachment or installation. Fill from your kitchen tap, press to filter, pour certified clean. Multi-stage filtration with SGS-certified performance. Filter: 400L or 3 months.",
    shortDescription: "Electric counter-top filter pitcher — no installation",
    categories: [CAT_HOME],
    images: [{ src: "/api/uc/product-images/electric-pitcher-counter-top-filter.jpg", alt: "Electric Pitcher" }],
    stockStatus: "instock", stockQuantity: 12,
    tags: [],
  },
  {
    id: 14, name: "RO Home System", sku: "UC-ROS-HOM-022",
    price: "0", regularPrice: "0", salePrice: "",
    lifespanDays: 180,
    enquiryOnly: true,
    tagline: "Whole-home certified purity. Under the sink.",
    description: "Under-sink reverse osmosis home filtration in 50G, 75G, and 100G configurations. Multi-stage RO filtration removing bacteria, heavy metals, dissolved solids, and chlorine. Professional installation by Ultra Clear. Annual maintenance contract available. Filter: 6 months. Contact info@ucfilters.com for site assessment.",
    shortDescription: "Under-sink RO system — 50G/75G/100G, professional installation",
    categories: [CAT_HOME],
    images: [{ src: "/api/uc/product-images/ro-home-system.jpg", alt: "RO Home System" }],
    stockStatus: "instock", stockQuantity: 5,
    tags: [],
  },

  // ── Segment 03 · Shower & Skin Filters ───────────────────────────────────
  {
    id: 15, name: "J'adore", sku: "UC-SHW-JAD-015",
    price: "4399", regularPrice: "4399", salePrice: "",
    lifespanDays: 150,
    tagline: "Certified softer water. Every shower.",
    description: "Shower filter delivering SGS-certified >95% chlorine removal. Multi-layer filtration media: PP Cotton, KDF, Activated Carbon, Vitamin C. Universal attachment — fits any shower head. Filter: 5 months.",
    shortDescription: "Shower filter — 5-month filter, SGS-certified >95% chlorine removal",
    categories: [CAT_SHOWER],
    images: [{ src: "/api/uc/product-images/jadore-aluminium-shower-filter.jpg", alt: "J'adore" }],
    stockStatus: "instock", stockQuantity: 20,
    tags: [],
  },
  {
    id: 16, name: "Channel", sku: "UC-SHW-DFF-016",
    price: "3699", regularPrice: "3699", salePrice: "",
    lifespanDays: 135,
    tagline: "Purer water. Purer skincare results.",
    description: "Dedicated facial basin filter — SGS-certified >95% chlorine removal at the precise point your skincare routine begins and ends. The water used to cleanse and rinse your face affects how every product performs. Remove the chlorine first. Filter: 4–5 months.",
    shortDescription: "Facial basin filter — removes chlorine at the source of your skincare",
    categories: [CAT_SHOWER],
    images: [{ src: "/api/uc/product-images/channel-facial-basin-filter.jpg", alt: "Channel" }],
    stockStatus: "instock", stockQuantity: 18,
    tags: [],
  },
  {
    id: 17, name: "Derma Care", sku: "UC-SHW-DCR-017",
    price: "3299", regularPrice: "3299", salePrice: "",
    lifespanDays: 150,
    tagline: "Gentler water for sensitive skin, every day.",
    description: "Shower filter designed for sensitive, dry, and eczema-prone skin. SGS-certified >95% chlorine removal to reduce the daily chemical load that tap water places on vulnerable skin and scalp. Universal attachment. Filter: 5 months.",
    shortDescription: "Shower filter for sensitive skin — 5-month, SGS-certified",
    categories: [CAT_SHOWER],
    images: [{ src: "/api/uc/product-images/derma-care-shower-filter.jpg", alt: "Derma Care" }],
    stockStatus: "instock", stockQuantity: 15,
    tags: [],
  },
  {
    id: 18, name: "Pure Drop", sku: "UC-SKW-SHF-022",
    price: "2699", regularPrice: "2699", salePrice: "",
    lifespanDays: 150,
    tagline: "Certified clean. Simple. Every shower.",
    description: "SGS-certified shower filter delivering >95% chlorine removal with an easy universal attachment. Compact, lightweight design fits any shower head with no tools. 5-month filter life. The entry point to certified shower water. Filter media: PP Cotton, KDF, Activated Carbon.",
    shortDescription: "Entry-level shower filter — 5-month, universal fit",
    categories: [CAT_SHOWER],
    images: [{ src: "/api/uc/product-images/pure-drop-shower-filter.jpg", alt: "Pure Drop" }],
    stockStatus: "instock", stockQuantity: 25,
    tags: [],
  },
  {
    id: 19, name: "Derma Flux", sku: "UC-SKW-DFS-024",
    price: "6499", regularPrice: "6499", salePrice: "",
    lifespanDays: 135,
    tagline: "Softer water at the source. For every skincare ritual.",
    description: "Faucet-mounted facial filter with SGS-certified >95% chlorine removal at your basin. 6-layer precision filtration: PP Cotton, Carbon Fibre, KDF, Vitamin C, PSS, and UF Membrane. Tool-free install. Perspective window shows condition in real time — swap when colour shifts. Filter: 4–5 months.",
    shortDescription: "Faucet facial filter — 6-layer, perspective window, 4–5 months",
    categories: [CAT_SHOWER],
    images: [{ src: "/api/uc/product-images/derma-flux-faucet-facial-filter.jpg", alt: "Derma Flux" }],
    stockStatus: "instock", stockQuantity: 12,
    tags: [{ name: "premium" }],
  },

  // ── Segment 04 · Accessories & Replacements ──────────────────────────────
  {
    id: 20, name: "Gift & Bundle Sets", sku: "UC-ACC-GFT-020",
    price: "0", regularPrice: "0", salePrice: "",
    lifespanDays: 0,
    enquiryOnly: true,
    tagline: "The gift of certified clean water.",
    description: "Curated gift and bundle sets — mix and match Ultra Clear products. Filter lifespan varies by bundle contents. Contact us to build your perfect bundle.",
    shortDescription: "Mix & match gift bundles — contact us for pricing",
    categories: [CAT_ACCESS],
    images: [{ src: "/api/uc/product-images/gift-and-bundle-sets.jpg", alt: "Gift Sets" }],
    stockStatus: "instock", stockQuantity: 999,
    tags: [],
  },
  {
    id: 21, name: "Bottle Carry Sleeve", sku: "UC-ACC-SLV-021",
    price: "0", regularPrice: "0", salePrice: "",
    lifespanDays: 0,
    enquiryOnly: true,
    tagline: "Protect your bottle in style.",
    description: "Neoprene and crochet carry sleeves in universal fit for all Ultra Clear bottles. No filter media — housing accessory only. Price on request.",
    shortDescription: "Neoprene & crochet bottle sleeve — universal fit",
    categories: [CAT_ACCESS],
    images: [{ src: "/api/uc/product-images/ultra-clear-bottle-carry-sleeve-crocheted.jpg", alt: "Bottle Carry Sleeve" }],
    stockStatus: "instock", stockQuantity: 999,
    tags: [],
  },
  {
    id: 22, name: "Bottle Filter Cartridge", sku: "UC-RPL-BTL-010",
    price: "1099", regularPrice: "1099", salePrice: "",
    lifespanDays: 90,
    tagline: "Genuine replacement. Keep the certification active.",
    description: "Genuine Ahlstrom Disruptor® replacement cartridge for all Ultra Clear filter bottles (Hydra Flux, Truva Go, Viva Drop, Flex, Timbo, Gym Buddy, Breeze). Maintains SGS-certified >99.9% bacteria removal. Replace every 150L or 3 months.",
    shortDescription: "Genuine replacement cartridge for all UC filter bottles — 3 months",
    categories: [CAT_ACCESS],
    images: [{ src: "/api/uc/product-images/bottle-filter-cartridge.jpg", alt: "Bottle Filter Cartridge" }],
    stockStatus: "instock", stockQuantity: 100,
    tags: [{ name: "replacement" }, { name: "bestseller" }],
  },
  {
    id: 23, name: "Faucet Filter Cartridge", sku: "UC-RPL-FCT-014",
    price: "1999", regularPrice: "1999", salePrice: "",
    lifespanDays: 120,
    tagline: "Replace every 4–5 months. Keep the certification active.",
    description: "Genuine replacement cartridge for the Sweet Home Faucet Filter. Maintains SGS-certified >99.9% bacteria removal and >95% chlorine removal performance. Replace every 4–5 months or ~1,500–2,000 litres. Ultra Clear replacement reminders included.",
    shortDescription: "Genuine replacement cartridge for Sweet Home faucet filter — 4–5 months",
    categories: [CAT_ACCESS],
    images: [{ src: "/api/uc/product-images/home-sweet-home-faucet-filter-cartridge.jpg", alt: "Faucet Filter Cartridge" }],
    stockStatus: "instock", stockQuantity: 80,
    tags: [{ name: "replacement" }],
  },
  {
    id: 24, name: "Shower Filter Cartridge", sku: "UC-RPL-SHW-018",
    price: "1499", regularPrice: "1499", salePrice: "",
    lifespanDays: 150,
    tagline: "Replace every 5 months. Keep every shower certified.",
    description: "Genuine replacement cartridge for the J'adore, Derma Care, and Pure Drop shower and basin filters. Maintains SGS-certified >95% chlorine removal. Multi-layer filtration media: PP Cotton, KDF, Activated Carbon, Vitamin C. Replace every 5 months.",
    shortDescription: "Genuine shower cartridge for J'adore, Derma Care, Pure Drop — 5 months",
    categories: [CAT_ACCESS],
    images: [{ src: "/api/uc/product-images/shower-filter-cartridge.jpg", alt: "Shower Filter Cartridge" }],
    stockStatus: "instock", stockQuantity: 60,
    tags: [{ name: "replacement" }],
  },
  {
    id: 25, name: "Derma Flux Cartridge", sku: "UC-SKW-DFO-025",
    price: "2499", regularPrice: "2499", salePrice: "",
    lifespanDays: 120,
    tagline: "Replace every 4 months. Keep the skincare edge.",
    description: "Genuine replacement cartridge for the Derma Flux facial faucet filter. Precision 6-layer filtration: PP Cotton, Carbon Fibre, KDF, Vitamin C, PSS, and UF Membrane. Perspective window shows condition — swap when colour shifts. Maintains SGS-certified >95% chlorine removal. Replace every 4–5 months.",
    shortDescription: "Genuine 6-layer replacement cartridge for Derma Flux — 4–5 months",
    categories: [CAT_ACCESS],
    images: [{ src: "/api/uc/product-images/derma-flux-filter-cartridge.jpg", alt: "Derma Flux Cartridge" }],
    stockStatus: "instock", stockQuantity: 40,
    tags: [{ name: "replacement" }],
  },
  {
    id: 26, name: "Survivor Straw Cartridge", sku: "UC-BOG-FCS-017",
    price: "499", regularPrice: "499", salePrice: "",
    // Matches Survivor Straw: 400L or 4 months.
    lifespanDays: 120,
    tagline: "Renew the straw. Restore the protection.",
    description: "Genuine replacement filter cartridge for the Ultra Clear Survivor Straw. Restores full SGS-certified filtration performance. Compact, lightweight, and easy to swap in the field. Replace every 400L or 4 months — whichever comes first.",
    shortDescription: "Genuine replacement cartridge for Survivor Straw",
    categories: [CAT_ACCESS],
    images: [{ src: "/api/uc/product-images/survivor-straw-filter-cartridge.jpg", alt: "Survivor Straw Cartridge" }],
    stockStatus: "instock", stockQuantity: 100,
    tags: [{ name: "replacement" }],
  },
  {
    id: 27, name: "Filter Shell", sku: "UC-BOG-SHL-018",
    price: "499", regularPrice: "499", salePrice: "",
    lifespanDays: 0,
    tagline: "The shell that carries the clean.",
    description: "Replacement outer shell for the Survivor Straw filter. Durable BPA-free housing with universal thread fit — pair with a fresh Survivor Straw Cartridge for a fully rebuilt straw at minimal cost. Lightweight and compact.",
    shortDescription: "Replacement housing shell for Survivor Straw",
    categories: [CAT_ACCESS],
    images: [{ src: "/api/uc/product-images/filter-shell-straw-shell.jpg", alt: "Filter Shell" }],
    stockStatus: "instock", stockQuantity: 50,
    tags: [],
  },

  // ── Segment 05 · Solutions ────────────────────────────────────────────────
  {
    id: 29, name: "Aqua Stream 1200", sku: "UC-COM-UP-027",
    price: "69990", regularPrice: "69990", salePrice: "",
    lifespanDays: 210,
    tagline: "Institutional-grade certified water. Zero management overhead.",
    description: "Commercial reverse osmosis infrastructure for 50–200+ staff. Two configurations: Aqua Stream 1200 at KES 69,990 and Aqua Stream 1200 Pro on request. Full documentation pack (SGS, FDA, RoHS) within 24 hours. Annual ESG impact statement for corporate reporting. Site assessment, installation, and maintenance contract available. Filter: 6–9 months.",
    shortDescription: "Commercial 1200GPD RO system — KES 69,990 / Pro on request",
    categories: [CAT_SOLUTIONS],
    images: [{ src: "/api/uc/product-images/aqua-stream-1200-commercial-ro-system.jpg", alt: "Aqua Stream 1200" }],
    stockStatus: "instock", stockQuantity: 3,
    tags: [{ name: "commercial" }],
  },
  {
    id: 30, name: "Water ATMs", sku: "UC-ATM-001",
    price: "0", regularPrice: "0", salePrice: "",
    lifespanDays: 0,
    enquiryOnly: true,
    tagline: "KES 2–5 per litre. Certified. For every community.",
    description: "Pay-per-litre certified water infrastructure. Ultra Clear Water ATMs bring SGS-certified filtered water to communities at KES 2–5 per litre. Host and placement enquiries: info@ucfilters.com.",
    shortDescription: "Community certified water ATMs — host enquiries welcome",
    categories: [CAT_SOLUTIONS],
    images: [{ src: "/api/uc/product-images/ultra-clear-water-atm.jpg", alt: "Water ATMs" }],
    stockStatus: "instock", stockQuantity: 0,
    tags: [{ name: "commercial" }],
  },
];

/** Single authoritative fallback-catalog pricing implementation for checkout
 * quotes and order creation. Unknown products are rejected rather than priced
 * at zero. */
export async function serverPricedLines(lineItems: { productId: number; quantity: number; variationId?: number; childSku?: string }[], allowEmpty = false) {
  if (!Array.isArray(lineItems) || (!lineItems.length && !allowEmpty)) return null;
  if (lineItems.length > 100 || lineItems.some(item => !item || typeof item !== "object" ||
      !Number.isInteger(item.productId) || item.productId <= 0 ||
      !Number.isInteger(item.quantity) || item.quantity <= 0 || item.quantity > 1000 ||
      (item.variationId !== undefined && (!Number.isSafeInteger(item.variationId) || item.variationId <= 0)) ||
      (item.childSku !== undefined && (typeof item.childSku !== "string" || !item.childSku.trim())) ||
      (!!item.variationId !== !!item.childSku))) return null;
  const catalogue = hasCompanionCatalogue()
    ? await wcFetchArray("/products", { include: [...new Set(lineItems.map(i => i.productId))].join(","), per_page: "100" })
    : MOCK_PRODUCTS;
  // A live product must never be priced using an unrelated demo ID.
  if (!catalogue) return null;
  const { collection } = await effectiveEditorial();
  const lines = await Promise.all(lineItems.map(async (item) => {
    const productId = Number(item.productId), quantity = Number(item.quantity);
    const product = catalogue.find((candidate) => candidate["id"] === productId);
    if (!product || !Number.isInteger(quantity) || quantity <= 0) return null;
    if (product["status"] !== "publish") return null;
    const record = collection.products.find((p: any) => p.parentSku === product["sku"]);
    if (record && !record.purchasable) return null;
    let selected = product;
    let variantLabel: string | undefined;
    if (item.variationId) {
      if (!record) return null;
      const variant = record.variants.find((v: any) => v.childSku === item.childSku);
      if (!variant) return null;
      const live = await wcFetchOne(`/products/${productId}/variations/${item.variationId}`);
      if (!live || Number(live.id) !== item.variationId || live.sku !== item.childSku ||
          (live.parent_id !== undefined && Number(live.parent_id) !== productId) || live.status !== "publish") return null;
      // Verify SKU uniqueness among the parent's complete set, not ID alone.
      const children = await wcFetchAllPages(`/products/${productId}/variations`, { per_page: "100" });
      if (!children || children.filter(c => c.sku === item.childSku).length !== 1) return null;
      selected = live;
      variantLabel = variant.label;
    } else if (record?.variants.length || product["type"] === "variable") return null;
    // Owner-approved editorial prices (initially Excel CATALOGUE RETAIL)
    // supersede Woo prices. Woo still verifies identity, publication and stock.
    const price = record ? record.price : Number(selected["price"]);
    if (typeof price !== "number" || !Number.isFinite(price) || price <= 0 || product["enquiryOnly"] ||
        selected["purchasable"] === false ||
        (selected["manage_stock"] === true && typeof selected["stock_quantity"] === "number" &&
          selected["stock_quantity"] < quantity && selected["backorders_allowed"] !== true) ||
        !["instock", "onbackorder"].includes(String(selected["stock_status"]))) return null;
    return { productId, name: `${String(product["name"])}${variantLabel ? ` — ${variantLabel} (${item.childSku})` : ''}`,
      sku: String(selected["sku"] || product["sku"] || ""), size: String(record?.specs?.Capacity || ""),
      quantity, subtotal: price * quantity,
      ...(item.variationId ? { variationId: item.variationId, childSku: item.childSku, variantLabel } : {}) };
  }));
  return lines.some((line) => !line) ? null : lines as {
    productId: number; name: string; sku: string; size: string; quantity: number; subtotal: number;
    variationId?: number; childSku?: string; variantLabel?: string;
  }[];
}

/** Attach a verified provider recovery payment to its authenticated account
 * and server-priced catalogue lines. A recovery row is only eligible for
 * referral settlement after this transaction has completed. */
export async function finalizeRecoveryOrder(params: {
  orderId: number;
  accountId: number;
  lineItems: { productId: number; quantity: number }[];
  shippingAddress?: Record<string, string>;
  applyReferralDiscount?: boolean;
}): Promise<void> {
  if (params.applyReferralDiscount) {
    throw Object.assign(
      new Error("A referral discount cannot be added after payment"),
      { code: "RECOVERY_DISCOUNT_REJECTED" },
    );
  }
  const lines = legacyCallbackPricedLines(params.lineItems);
  if (!lines || lines.reduce((sum, line) => sum + line.subtotal, 0) <= 0) {
    throw Object.assign(
      new Error("Recovery requires known products with positive quantities"),
      { code: "INVALID_RECOVERY_LINES" },
    );
  }
  const expectedTotal =
    lines.reduce((sum, line) => sum + line.subtotal, 0) + 500;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const orderResult = await client.query(
      "SELECT * FROM uc_orders WHERE id=$1 FOR UPDATE",
      [params.orderId],
    );
    const order = orderResult.rows[0];
    if (!order) {
      throw Object.assign(new Error("Recovery order not found"), {
        code: "RECOVERY_NOT_FOUND",
      });
    }
    const account = await client.query(
      `SELECT id FROM uc_users
       WHERE id=$1 AND deleted_at IS NULL FOR UPDATE`,
      [params.accountId],
    );
    if (!account.rows[0]) {
      throw Object.assign(new Error("Authenticated active account required"), {
        code: "RECOVERY_ACCOUNT_REQUIRED",
      });
    }
    // Idempotent duplicate recovery finalization: once the provider row has
    // been claimed, do not replace its authenticated account or line items.
    if (!order.webhook_recovery) {
      await client.query("COMMIT");
      return;
    }
    if (Number(order.total) !== expectedTotal) {
      throw Object.assign(
        new Error("Submitted products do not match the settled payment total"),
        { code: "RECOVERY_TOTAL_MISMATCH" },
      );
    }
    await client.query(
      "DELETE FROM uc_order_items WHERE order_id=$1",
      [params.orderId],
    );
    for (const line of lines) {
      await client.query(
        `INSERT INTO uc_order_items
           (order_id,product_id,name,quantity,total)
         VALUES($1,$2,$3,$4,$5)`,
        [
          params.orderId,
          line.productId,
          line.name,
          line.quantity,
          String(line.subtotal),
        ],
      );
    }
    await client.query(
      `UPDATE uc_orders SET user_id=$2,shipping_address=$3,
         webhook_recovery=false,
         payment_confirmed_at=COALESCE(payment_confirmed_at,now())
       WHERE id=$1`,
      [
        params.orderId,
        String(params.accountId),
        JSON.stringify(params.shippingAddress ?? {}),
      ],
    );
    await client.query(
      `INSERT INTO uc_referral_settlements
         (order_id,referral_code,user_email,status,next_attempt_at)
       SELECT $1,COALESCE(a.referral_code,''),u.email,'pending',now()
       FROM uc_users u
       LEFT JOIN uc_referral_attributions a ON a.referred_user_id=u.id
       WHERE u.id=$2
       ON CONFLICT(order_id) DO UPDATE SET
         status='pending',completed_at=NULL,last_error=NULL,
         next_attempt_at=now(),updated_at=now()`,
      [params.orderId, params.accountId],
    );
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK").catch(() => undefined);
    throw error;
  } finally {
    client.release();
  }
}

const MOCK_LOCATIONS = [
  { id: "loc1", type: "experience_centre", name: "UC Experience Centre Westlands", address: "Woodvale Groove, Westlands, Nairobi", lat: -1.2633, lng: 36.8072, hours: "Mon–Sat 8am–6pm, Sun 10am–4pm", phone: "+254 700 123456" },
  { id: "loc2", type: "experience_centre", name: "UC Service Centre Karen", address: "Karen Hardy Estate, Karen, Nairobi", lat: -1.3319, lng: 36.7097, hours: "Mon–Fri 8am–5pm", phone: "+254 700 654321" },
  { id: "loc3", type: "refill_atm", name: "Water ATM – Village Market", address: "Village Market Mall, Limuru Rd, Gigiri", lat: -1.2194, lng: 36.8083, hours: "24/7", phone: null },
  { id: "loc4", type: "refill_atm", name: "Water ATM – Sarit Centre", address: "Sarit Centre, Karuna Rd, Westlands", lat: -1.2592, lng: 36.8027, hours: "6am–11pm daily", phone: null },
  { id: "loc5", type: "refill_atm", name: "Water ATM – Two Rivers Mall", address: "Two Rivers Mall, Rhapta Rd, Westlands", lat: -1.2178, lng: 36.7985, hours: "7am–10pm daily", phone: null },
  { id: "loc6", type: "refill_atm", name: "Water ATM – Garden City", address: "Garden City Mall, Thika Superhighway", lat: -1.2241, lng: 36.8801, hours: "6am–10pm daily", phone: null },
  { id: "loc7", type: "refill_atm", name: "Water ATM – Junction Mall", address: "Junction Mall, Ngong Rd, Nairobi", lat: -1.3003, lng: 36.7773, hours: "7am–9pm daily", phone: null },
];

// In-memory stores removed — all data now persists in PostgreSQL.
// Fallback arrays used only when the DB is temporarily unavailable.
const orderStoreFallback:  Record<string, unknown>[] = [];
const ticketStoreFallback: Record<string, unknown>[] = [];
const waterTestStoreFallback: Record<string, unknown>[] = [];

// ─── WooCommerce helpers ──────────────────────────────────────────────────────
export function hasWCCredentials(): boolean {
  // Retained temporarily for old recovery branches/test seams. Credentials
  // must never turn a retired external authority back on.
  return false;
}

function wcUrl(path: string, extra: Record<string, string> = {}): string {
  const base = process.env["WC_BASE_URL"] || "https://www.ucfilters.com";
  const url = new URL(`${base}/wp-json/wc/v3${path}`);
  url.searchParams.set("consumer_key", process.env["WC_CONSUMER_KEY"]!);
  url.searchParams.set("consumer_secret", process.env["WC_CONSUMER_SECRET"]!);
  Object.entries(extra).forEach(([k, v]) => url.searchParams.set(k, v));
  return url.toString();
}

/**
 * Parse a WooCommerce REST API response that may have PHP notices prepended.
 * WordPress sites with WP_DEBUG enabled output HTML notices before the JSON body.
 * We scan for the first `[` or `{` and parse from there.
 */
function parseWcJson(text: string): unknown {
  const start = text.search(/[{[]/);
  if (start === -1) throw new SyntaxError("No JSON object found in WC response");
  return JSON.parse(text.slice(start));
}

export async function wcFetchArray(
  path: string,
  extra: Record<string, string> = {},
  signal?: AbortSignal,
  maxResponseBytes?: number,
): Promise<Record<string, unknown>[] | null> {
  try {
    const data = await readCompanionCollection(path, extra, signal);
    if (maxResponseBytes !== undefined && Buffer.byteLength(JSON.stringify(data)) > maxResponseBytes) return null;
    return data;
  } catch {
    return null;
  }
}

const WC_PAGE_SIZE = 100;
const MAX_WC_PAGES = 50;

/**
 * WooCommerce paginates every collection endpoint. Returning a partial list is
 * worse than returning an error for catalogue filtering, because it presents a
 * successful but incorrect category result to the shopper.
 */
export async function wcFetchAllPages(
  path: string,
  extra: Record<string, string> = {},
  signal: AbortSignal = AbortSignal.timeout(12_000),
): Promise<Record<string, unknown>[] | null> {
  const all: Record<string, unknown>[] = [];
  for (let page = 1; page <= MAX_WC_PAGES; page++) {
    const batch = await wcFetchArray(path, {
      ...extra,
      per_page: String(WC_PAGE_SIZE),
      page: String(page),
    }, signal);
    if (!batch) return null;
    all.push(...batch);
    if (batch.length < WC_PAGE_SIZE) return all;
  }
  // A bounded request prevents a bad upstream from causing unbounded work; do
  // not serve a silently truncated catalogue when that bound is reached.
  return null;
}

export async function wcFetchOne(
  path: string,
  extra: Record<string, string> = {}
): Promise<Record<string, unknown> | null> {
  try {
    void extra;
    return await readCompanionProduct(path);
  } catch {
    return null;
  }
}

export function normalizeProduct(p: Record<string, unknown>): Record<string, unknown> {
  // lifespanDays: present on mock products; for WooCommerce products we check
  // meta_data for a "filter_lifespan_days" key. 0 = not a trackable filter —
  // never guess a lifespan for unknown products (the mobile filter tracker
  // treats lifespanDays > 0 as "trackable" and schedules reminders from it).
  let lifespanDays: number = typeof p["lifespanDays"] === "number" ? p["lifespanDays"] : 0;
  const mockCapacityById: Record<number, number> = {
    1: 150, 2: 150, 3: 150, 4: 150, 5: 150, 6: 150, 7: 400,
    8: 150, 9: 400, 11: 2000, 13: 400, 22: 150, 23: 2000, 26: 400,
  };
  let filterCapacityLitres =
    Number(p["filterCapacityLitres"] ?? p["capacityLitres"] ?? mockCapacityById[Number(p["id"])] ?? 0) || 0;
  if (Array.isArray(p["meta_data"])) {
    const meta = (p["meta_data"] as Array<{ key: string; value: unknown }>)
      .find(m => m.key === "filter_lifespan_days");
    if (meta && Number(meta.value) > 0) lifespanDays = Number(meta.value);
    const capacityMeta = (p["meta_data"] as Array<{ key: string; value: unknown }>)
      .find(m => m.key === "filter_capacity_litres");
    if (capacityMeta && Number(capacityMeta.value) > 0) filterCapacityLitres = Number(capacityMeta.value);
  }
  return {
    id: p["id"],
    name: typeof p["name"] === "string" ? p["name"] : "Product",
    price: typeof p["price"] === "string" ? p["price"] : "",
    regularPrice: p["regular_price"] ?? p["regularPrice"],
    salePrice: p["sale_price"] ?? p["salePrice"],
    description: typeof p["description"] === "string" ? p["description"] : "",
    shortDescription: p["short_description"] ?? p["shortDescription"],
    tagline: p["tagline"] ?? p["short_description"] ?? p["shortDescription"] ?? "",
    categories: Array.isArray(p["categories"]) ? p["categories"] : [],
    // WooCommerce image srcs point at multi-megapixel originals on the store
    // CDN. Route eligible ones through the resize proxy so the app can load
    // width-appropriate WebP derivatives; ineligible srcs pass through as-is.
    images: Array.isArray(p["images"])
      ? (p["images"] as Array<Record<string, unknown>>).map((img) => {
          const src = typeof img?.["src"] === "string" ? (img["src"] as string) : "";
          return { src: remoteImageProxyPath(src) ?? src, alt: img?.["alt"] ?? "" };
        })
      : [],
    sku: p["sku"],
    stockStatus: p["stock_status"] ?? p["stockStatus"],
    stockQuantity: p["stock_quantity"] === null ? null : p["stock_quantity"] ?? p["stockQuantity"],
    manageStock: p["manage_stock"] ?? false,
    revision: p["revision"],
    tags: Array.isArray(p["tags"]) ? p["tags"] : [],
    lifespanDays,
    filterCapacityLitres,
    enquiryOnly: p["enquiryOnly"] ?? false,
    // WooCommerce lifetime sales counter — used by the mobile app to rank
    // recommendations. Mock products have no sales history → 0.
    totalSales: Number(p["total_sales"] ?? p["totalSales"] ?? 0) || 0,
  };
}

function normalizeOrder(o: Record<string, unknown>): Record<string, unknown> {
  const li = Array.isArray(o["line_items"])
    ? (o["line_items"] as Record<string, unknown>[]).map((i) => ({
        productId: i["product_id"],
        name: i["name"],
        quantity: i["quantity"],
        total: i["total"],
      }))
    : [];
  return {
    id: o["id"],
    orderNumber: o["number"] ?? o["id"],
    status: o["status"],
    fulfillmentStatus: o["status"],
    paymentStatus: o["date_paid"] || o["status"] === "completed" || o["status"] === "processing"
      ? "paid"
      : o["status"] === "cancelled" || o["status"] === "failed" || o["status"] === "refunded"
        ? o["status"]
        : "pending",
    dateCreated: o["date_created"],
    total: o["total"],
    currency: o["currency"],
    paymentMethod: o["payment_method"],
    shippingAddress: o["shipping"],
    delivery: {
      method: Array.isArray(o["shipping_lines"])
        ? (o["shipping_lines"] as Record<string, unknown>[]).map(line => line["method_title"]).filter(Boolean).join(", ")
        : "",
      trackingNumber: Array.isArray(o["meta_data"])
        ? (o["meta_data"] as Record<string, unknown>[]).find(meta => meta["key"] === "_tracking_number")?.["value"] ?? null
        : null,
    },
    lineItems: li,
  };
}

// ─── Product media overlay ────────────────────────────────────────────────────
// Team-uploaded photos/videos stored in uc_product_media are merged on top of
// the base catalogue (mock or WooCommerce) so extra media survives a future
// switch to the live store. A DB hiccup must never take down the catalogue —
// failures are logged loudly and the base product is served unchanged.
async function fetchProductMediaMap(productIds: number[]): Promise<Map<number, UcProductMedia[]>> {
  const map = new Map<number, UcProductMedia[]>();
  if (productIds.length === 0) return map;
  try {
    const rows = await db
      .select()
      .from(ucProductMediaTable)
      .where(inArray(ucProductMediaTable.productId, productIds))
      .orderBy(asc(ucProductMediaTable.position), asc(ucProductMediaTable.id));
    for (const row of rows) {
      const list = map.get(row.productId) ?? [];
      list.push(row);
      map.set(row.productId, list);
    }
  } catch (err) {
    logger.error({ err }, "Failed to load product media overlay — serving base catalogue only");
  }
  return map;
}

function applyProductMedia(
  product: Record<string, unknown>,
  media: UcProductMedia[] | undefined,
): Record<string, unknown> {
  const baseImages = (product["images"] as { src: string; alt: string }[] | undefined) ?? [];
  if (!media || media.length === 0) {
    return { ...product, videoUrl: null };
  }
  const photos = media
    .filter((m) => m.type === "photo")
    .map((m) => ({ src: m.url, alt: m.alt || (product["name"] as string) }));
  const video = media.find((m) => m.type === "video");
  return { ...product, images: [...baseImages, ...photos], videoUrl: video?.url ?? null };
}

// ─── Products ─────────────────────────────────────────────────────────────────
router.get("/uc/products", async (req: Request, res: Response): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  const publicationSafe = req.query["publicationSafe"] === "true";
  if (publicationSafe) {
    res.setHeader("Cache-Control", "no-store");
    if (!hasCompanionCatalogue()) {
      res.status(503).json({ error: "Published product catalogue provider is not configured" });
      return;
    }
  }
  try {
    let payload: Record<string, unknown>[] | null = null;
    let publishedSource = false;
    if (hasCompanionCatalogue()) {
      const requestedCategory = typeof req.query["category"] === "string"
        ? req.query["category"].trim()
        : "";
      const search = typeof req.query["search"] === "string" ? req.query["search"].trim() : "";
      const start = performance.now();
      const result = await catalogueCache.read(JSON.stringify([requestedCategory, search]), async () => {
        // One provider budget covers category discovery and ALL product pages,
        // leaving room inside the client's 15s timeout for response/media work.
        const signal = AbortSignal.timeout(12_000);
        const extra: Record<string, string> = { status: "publish" };
        const categoryId = requestedCategory ? await resolveWcCategoryId(requestedCategory, signal) : null;
        if (categoryId) extra["category"] = String(categoryId);
        if (search) extra["search"] = search;
        const products = await wcFetchAllPages("/products", extra, signal);
        if (!products) throw new Error("WooCommerce catalogue unavailable or incomplete");
        let normalized = products.map(normalizeProduct);
        // If the category lookup was unavailable, fetch-all + normalized
        // filtering is safer than sending a label to WooCommerce and showing
        // an accidental blank grid.
        if (requestedCategory && !categoryId) {
          normalized = normalized.filter(product => {
            const categories = Array.isArray(product["categories"])
              ? product["categories"] as { name?: unknown }[]
              : [];
            return categories.some(category =>
              categoryNameMatches(requestedCategory, String(category?.name ?? "")));
          });
        }
        return { payload: normalized, publishedSource: products.every(product => product["status"] === "publish") };
      });
      payload = result.value.payload;
      publishedSource = result.value.publishedSource;
      res.setHeader("Server-Timing", `catalogue;dur=${(performance.now() - start).toFixed(1)};desc="${result.source}"`);
      res.setHeader("X-UC-Catalogue-Cache", result.source);
    }
    if (!payload) {
      let data = MOCK_PRODUCTS;
      if (req.query["category"]) {
        const cat = req.query["category"] as string;
        data = data.filter((p) => {
          const cats = p["categories"] as { name: string }[] | undefined;
          return cats?.some((c) => categoryNameMatches(cat, c.name));
        });
      }
      if (req.query["search"]) {
        const q = (req.query["search"] as string).toLowerCase();
        data = data.filter(
          (p) =>
            (p["name"] as string).toLowerCase().includes(q) ||
            (p["sku"] as string).toLowerCase().includes(q)
        );
      }
      payload = data;
    }
    warnForMissingProductLifespans(payload);
    if (publicationSafe && !publishedSource) {
      res.status(503).json({ error: "Published product catalogue could not be verified" });
      return;
    }
    const mediaMap = await fetchProductMediaMap(payload.map((p) => Number(p["id"])));
    if (publicationSafe) res.setHeader("X-UC-Catalogue-Provenance", "companion-published");
    res.setHeader("X-UC-Product-Source", publishedSource ? "companion-published" : "unverified");
    res.json(payload.map((p) => applyProductMedia(p, mediaMap.get(Number(p["id"])))));
  } catch (error) {
    req.log?.warn({ err: error }, "Product catalogue refresh failed");
    res.status(502).json({ error: "The product catalogue is temporarily unavailable" });
  }
});

// ─── WooCommerce category resolution ─────────────────────────────────────────
// The app sends customer-friendly labels, while WooCommerce's products endpoint
// expects a numeric category id. Cache that mapping independently from product
// responses so the category tabs remain fast without becoming stale forever.
const STORE_CATEGORY_ALIASES: Record<string, string[]> = {
  "bottle and portable": ["bottle portable", "portable filter", "water bottle"],
  "home filter": ["household filter", "faucet filter", "under sink"],
  "shower and skin": ["shower skin", "shower filter", "skin filter", "bathroom filter"],
  accessory: ["accessories"],
  solution: ["solutions", "commercial", "water treatment"],
};
const CATEGORY_CACHE_TTL_MS = 10 * 60 * 1000;
let _categoryCache: { at: number; byName: Map<string, number> } | null = null;
let _categoryRefresh: Promise<Map<string, number> | null> | null = null;

export function normalizeStoreCategory(value: string): string {
  return value
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/filters?/g, "filter")
    .replace(/bottles?/g, "bottle")
    .replace(/showers?/g, "shower")
    .replace(/skins?/g, "skin")
    .replace(/accessories/g, "accessory")
    .replace(/solutions?/g, "solution")
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");
}

export function categoryNameMatches(requested: string, actual: string): boolean {
  const wanted = normalizeStoreCategory(requested);
  const got = normalizeStoreCategory(actual);
  if (!wanted || !got) return false;
  const aliases = STORE_CATEGORY_ALIASES[wanted] ?? [];
  return got === wanted || aliases.includes(got) ||
    got.includes(wanted) || wanted.includes(got) ||
    aliases.some(alias => got.includes(alias) || alias.includes(got));
}

async function getWcCategoryMap(): Promise<Map<string, number> | null> {
  if (_categoryCache && Date.now() - _categoryCache.at < CATEGORY_CACHE_TTL_MS) {
    return _categoryCache.byName;
  }
  if (_categoryRefresh) return _categoryRefresh;
  _categoryRefresh = (async () => {
    try {
      const categories = await wcFetchAllPages("/products/categories", {
        hide_empty: "false",
      });
      if (!categories) return _categoryCache?.byName ?? null;
      const byName = new Map<string, number>();
      for (const category of categories) {
        const id = Number(category["id"]);
        const name = String(category["name"] ?? "");
        if (id > 0 && name) byName.set(normalizeStoreCategory(name), id);
      }
      _categoryCache = { at: Date.now(), byName };
      return byName;
    } finally {
      _categoryRefresh = null;
    }
  })();
  return _categoryRefresh;
}

export async function resolveWcCategoryId(category: string): Promise<number | null> {
  const map = await getWcCategoryMap();
  if (!map) return null;
  const requested = normalizeStoreCategory(category);
  const direct = map.get(requested);
  if (direct) return direct;
  const aliases = STORE_CATEGORY_ALIASES[requested] ?? [];
  for (const [name, id] of map) {
    if (aliases.some(alias => name === alias || name.includes(alias) || alias.includes(name))) {
      return id;
    }
  }
  return null;
}

/** Test hook — reset category lookup state between tests. */
export function _resetCategoryCacheForTests(): void {
  _categoryCache = null;
  _categoryRefresh = null;
}

// ─── Lifespan audit ───────────────────────────────────────────────────────────
// Replacement reminders depend on every live filter product carrying a
// `filter_lifespan_days` meta value (normalizeProduct → lifespanDays > 0).
// New products added to the store default to lifespanDays 0 (non-trackable)
// and would silently ship without reminders. This audit flags such products
// so the team can add the meta before customers miss reminders.
//
// Exempt (never flagged — these legitimately have no lifespan):
//   • enquiry-only products (enquiryOnly flag or zero/absent price)
//   • products whose only categories are accessory-type (no filter media)
const LIFESPAN_EXEMPT_CATEGORY = /accessor/i;

/**
 * Classify normalized products and return the ones that need a lifespan but
 * lack one. Exported for tests.
 */
export function auditProductLifespans(
  products: Record<string, unknown>[],
): Record<string, unknown>[] {
  return products.filter((p) => {
    if (Number(p["lifespanDays"]) > 0) return false; // already trackable
    if (p["enquiryOnly"]) return false; // enquiry-only → no reminders expected
    if (!(Number(p["price"]) > 0)) return false; // no purchasable price → enquiry-only in practice
    const cats = Array.isArray(p["categories"])
      ? (p["categories"] as { name?: unknown }[])
      : [];
    // Exempt when every category is accessory-type (a product also listed in a
    // filter category still gets flagged).
    if (
      cats.length > 0 &&
      cats.every((c) => LIFESPAN_EXEMPT_CATEGORY.test(String(c?.name ?? "")))
    ) {
      return false;
    }
    return true;
  });
}

type LifespanWarningLogger = (
  details: { productId: number; productName: string },
  message: string,
) => void;

/**
 * Warn whenever the customer catalogue is about to emit a trackable product
 * whose reminder lifespan has disappeared. Products legitimately exempt from
 * reminders are filtered by auditProductLifespans.
 */
export function warnForMissingProductLifespans(
  products: Record<string, unknown>[],
  warn: LifespanWarningLogger = (details, message) => logger.warn(details, message),
): void {
  for (const product of auditProductLifespans(products)) {
    warn(
      {
        productId: Number(product["id"]),
        productName: String(product["name"] ?? "Product"),
      },
      "Product catalogue is emitting a trackable product without filter_lifespan_days",
    );
  }
}

/**
 * Fetch every published product across all WooCommerce pages.
 *
 * WooCommerce caps `per_page` at 100, so stores with more products need
 * pagination. Returns null when ANY page fails — a partial catalogue must
 * never produce a false all-clear audit.
 *
 * `fetchPage` is injectable for tests; defaults to the live wcFetchArray.
 * Exported for tests.
 */
export async function fetchAllPublishedProducts(
  fetchPage: (page: number) => Promise<Record<string, unknown>[] | null> = (page) =>
    wcFetchArray("/products", {
      per_page: "100",
      status: "publish",
      page: String(page),
    }),
): Promise<Record<string, unknown>[] | null> {
  const all: Record<string, unknown>[] = [];
  const MAX_PAGES = 50; // 5,000 products — hard safety cap
  for (let page = 1; page <= MAX_PAGES; page++) {
    const batch = await fetchPage(page);
    if (batch === null) return null; // page unreachable → whole audit fails
    all.push(...batch);
    if (batch.length < 100) return all; // short page = last page, catalogue complete
  }
  // Reached the cap with every page full — the catalogue may extend beyond
  // what we fetched. Fail loudly rather than audit a partial catalogue and
  // report a false all-clear.
  return null;
}

// ─── Product lifespan map (cached) ───────────────────────────────────────────
// Shared lookup of productId → filter_lifespan_days for the impact calculator
// and receipt-based filter registration. Sources the same catalogue as
// /uc/products (live WooCommerce when credentials exist, mock otherwise) so
// lifespans are never guessed — products without the meta simply aren't in
// the map. Cached for 10 minutes; on a live-store outage the last good map is
// served, and `null` is returned only when no data has ever been fetched
// (callers must fail loudly, not fabricate lifespans).
let _lifespanCache: { at: number; map: Map<number, number> } | null = null;
let _lifespanRefresh: Promise<Map<number, number> | null> | null = null;
const LIFESPAN_CACHE_TTL_MS = 10 * 60 * 1000;

export async function getProductLifespanMap(): Promise<Map<number, number> | null> {
  if (_lifespanCache && Date.now() - _lifespanCache.at < LIFESPAN_CACHE_TTL_MS) {
    return _lifespanCache.map;
  }
  // Coalesce concurrent refreshes — at TTL expiry, impact + registration
  // requests must not each paginate the whole Woo catalogue.
  if (_lifespanRefresh) return _lifespanRefresh;
  _lifespanRefresh = (async () => {
    try {
      let normalized: Record<string, unknown>[] | null = null;
      if (hasWCCredentials()) {
        const products = await fetchAllPublishedProducts();
        if (products) normalized = products.map(normalizeProduct);
      } else {
        normalized = MOCK_PRODUCTS.map(normalizeProduct);
      }
      if (!normalized) return _lifespanCache?.map ?? null; // stale beats nothing
      const map = new Map<number, number>();
      for (const p of normalized) {
        const lifespan = Number(p["lifespanDays"]);
        if (lifespan > 0) map.set(Number(p["id"]), lifespan);
      }
      // Timestamp on completion — never on fetch start — so a slow fetch
      // can't shorten the effective freshness window.
      _lifespanCache = { at: Date.now(), map };
      return map;
    } finally {
      _lifespanRefresh = null;
    }
  })();
  return _lifespanRefresh;
}

export async function getProductCapacityMap(): Promise<Map<number, number> | null> {
  let normalized: Record<string, unknown>[] | null = null;
  if (hasWCCredentials()) {
    const products = await fetchAllPublishedProducts();
    if (products) normalized = products.map(normalizeProduct);
  } else {
    normalized = MOCK_PRODUCTS.map(normalizeProduct);
  }
  if (!normalized) return null;
  const map = new Map<number, number>();
  for (const product of normalized) {
    const capacity = Number(product["filterCapacityLitres"]);
    if (Number.isInteger(capacity) && capacity > 0) {
      map.set(Number(product["id"]), capacity);
    }
  }
  return map;
}

/** Test hook — reset the lifespan cache between test cases. */
export function _resetLifespanCacheForTests(): void {
  _lifespanCache = null;
  _lifespanRefresh = null;
}

// GET /api/uc/admin/products/lifespan-audit — admin-only report of live
// products missing the filter_lifespan_days meta. ProjectHub surfaces this
// as a dashboard warning so new store products can't ship untracked.
router.get(
  "/uc/admin/products/lifespan-audit",
  async (req: Request, res: Response): Promise<void> => {
    const admin = await isAdminRequest(req.headers["authorization"]);
    if (!admin) {
      res.status(403).json({ error: "Admin access required" });
      return;
    }
    try {
      let source = "mock";
      let normalized: Record<string, unknown>[] | null = null;
      if (hasWCCredentials()) {
        const products = await fetchAllPublishedProducts();
        if (products) {
          normalized = products.map(normalizeProduct);
          source = "woocommerce";
        } else {
          // Store unreachable — say so loudly instead of silently auditing
          // the mock catalogue and reporting a false all-clear.
          res.status(502).json({ error: "Could not reach the WooCommerce store to audit products" });
          return;
        }
      }
      if (!normalized) normalized = MOCK_PRODUCTS.map(normalizeProduct);

      const flagged = auditProductLifespans(normalized);
      const flaggedIds = flagged.map((p) => Number(p["id"])).filter(Boolean);

      // Pull alert history for each flagged product so the dashboard can show
      // repeat offenders (alertCount > 1) and regression status (resolvedAt).
      let alertsByProductId = new Map<number, { alertCount: number; resolvedAt: Date | null }>();
      if (flaggedIds.length > 0) {
        const rows = await db
          .select({
            productId: ucLifespanAlertsTable.productId,
            alertCount: ucLifespanAlertsTable.alertCount,
            resolvedAt: ucLifespanAlertsTable.resolvedAt,
          })
          .from(ucLifespanAlertsTable)
          .where(inArray(ucLifespanAlertsTable.productId, flaggedIds));
        for (const row of rows) {
          alertsByProductId.set(row.productId, {
            alertCount: row.alertCount,
            resolvedAt: row.resolvedAt,
          });
        }
      }

      const missing = flagged.map((p) => {
        const pid = Number(p["id"]);
        const alert = alertsByProductId.get(pid);
        return {
          id: pid,
          name: p["name"],
          sku: p["sku"] ?? "",
          categories: Array.isArray(p["categories"])
            ? (p["categories"] as { name?: string }[]).map((c) => c?.name ?? "")
            : [],
          alertCount: alert?.alertCount ?? null,
          resolvedAt: alert?.resolvedAt?.toISOString() ?? null,
        };
      });

      res.json({
        source,
        checkedAt: new Date().toISOString(),
        checkedCount: normalized.length,
        missing,
      });
    } catch (err) {
      logger.error({ err }, "Lifespan audit failed");
      res.status(500).json({ error: "Lifespan audit failed" });
    }
  },
);

// ─── Product compatibility map ────────────────────────────────────────────────
// Keyed by full SKU or SKU prefix (ends with "-").
// Values are { ids: product IDs from MOCK_PRODUCTS, reason: compatibilityReason }.
const COMPATIBILITY_MAP: Record<string, { ids: number[]; reason: string }> = {
  // All filter bottles → bottle replacement cartridge + carry sleeve
  "UC-BTL-HFX-001": { ids: [22, 21], reason: "Replacement Filter" },
  "UC-BTL-TGO-002": { ids: [22, 21], reason: "Replacement Filter" },
  "UC-BTL-VDP-003": { ids: [22, 21], reason: "Replacement Filter" },
  "UC-BTL-FLX-004": { ids: [22, 21], reason: "Replacement Filter" },
  "UC-BTL-TMB-005": { ids: [22, 21], reason: "Replacement Filter" },
  "UC-BTL-GYM-006": { ids: [22, 21], reason: "Replacement Filter" },
  "UC-BTL-BRZ-008": { ids: [22, 21], reason: "Replacement Filter" },
  // Survivor Straw → straw cartridge + replacement shell
  "UC-STR-SVV-007": { ids: [26, 27], reason: "Replacement Filter" },
  // EcoSmart Elite (advanced portable filter) → bottle cartridge
  "UC-ESE-ELT-009": { ids: [22], reason: "Replacement Filter" },
  // Sweet Home faucet filter → faucet cartridge
  "UC-FCT-SWH-011": { ids: [23], reason: "Replacement Filter" },
  // Standard shower/skin filters → shower cartridge
  "UC-SHW-JAD-015": { ids: [24], reason: "Replacement Filter" },
  "UC-SHW-DFF-016": { ids: [24], reason: "Replacement Filter" },
  "UC-SHW-DCR-017": { ids: [24], reason: "Replacement Filter" },
  "UC-SKW-SHF-022": { ids: [24], reason: "Replacement Filter" },
  // Derma Flux facial faucet filter → Derma Flux cartridge
  "UC-SKW-DFS-024": { ids: [25], reason: "Replacement Filter" },
  // Replacement cartridges → matching parent filter as accessory suggestion
  "UC-RPL-BTL-010": { ids: [21], reason: "Compatible Accessory" },
  "UC-RPL-FCT-014": { ids: [11], reason: "Compatible Accessory" },
  "UC-RPL-SHW-018": { ids: [15, 17, 18], reason: "Compatible Accessory" },
  "UC-SKW-DFO-025": { ids: [19], reason: "Compatible Accessory" },
  "UC-BOG-FCS-017": { ids: [7, 27], reason: "Compatible Accessory" },
  "UC-BOG-SHL-018": { ids: [7, 26], reason: "Compatible Accessory" },
  // Bottle sleeve → any bottle is compatible; suggest cartridge
  "UC-ACC-SLV-021": { ids: [22], reason: "Compatible Accessory" },
};

// Returns the compatibilityReason for a product based on its tags/category.
function resolveCompatibilityReason(
  product: Record<string, unknown>,
  defaultReason: string
): string {
  const tags = product["tags"] as { name: string }[] | undefined;
  if (tags?.some((t) => t.name === "replacement")) return "Replacement Filter";
  const cats = product["categories"] as { name: string }[] | undefined;
  if (cats?.some((c) => c.name === CAT_ACCESS.name)) return "Compatible Accessory";
  return defaultReason;
}

router.get("/uc/products/compatibility", async (req: Request, res: Response): Promise<void> => {
  try {
    const rawSkus = req.query["skus"];
    const skus: string[] = typeof rawSkus === "string" && rawSkus.trim()
      ? rawSkus.split(",").map((s) => s.trim()).filter(Boolean)
      : [];

    // Collect compatible product IDs + their default reason from the map.
    const collected: Map<number, string> = new Map();

    for (const sku of skus) {
      const entry = COMPATIBILITY_MAP[sku];
      if (entry) {
        for (const id of entry.ids) {
          // First writer wins for reason; avoid overwriting with a weaker match.
          if (!collected.has(id)) collected.set(id, entry.reason);
        }
      }
    }

    // WooCommerce cross-sell enrichment (best-effort; silently skipped when absent).
    if (hasWCCredentials() && skus.length > 0) {
      for (const sku of skus) {
        // Look up the WC product by SKU to get its cross_sell_ids.
        const wcProducts = await wcFetchArray("/products", { sku, per_page: "1" });
        const wcp = wcProducts?.[0];
        const crossSellIds = Array.isArray(wcp?.["cross_sell_ids"])
          ? (wcp["cross_sell_ids"] as number[])
          : [];
        for (const id of crossSellIds) {
          if (!collected.has(id)) collected.set(id, "Compatible Accessory");
        }
      }
    }

    // Resolve full product objects.
    let results: Record<string, unknown>[] = [];

    if (collected.size > 0) {
      const ids = [...collected.keys()];

      if (hasWCCredentials()) {
        const include = ids.join(",");
        const wcProducts = await wcFetchArray("/products", { include, per_page: "50" });
        if (wcProducts && wcProducts.length > 0) {
          results = wcProducts.map((p) => {
            const norm = normalizeProduct(p);
            return {
              ...norm,
              compatibilityReason: resolveCompatibilityReason(
                norm,
                collected.get(Number(norm["id"])) ?? "Compatible Accessory"
              ),
            };
          });
        }
      }

      // Fall back to MOCK_PRODUCTS for any IDs not resolved from WooCommerce.
      const resolvedIds = new Set(results.map((p) => Number(p["id"])));
      for (const id of ids) {
        if (!resolvedIds.has(id)) {
          const mock = MOCK_PRODUCTS.find((p) => p["id"] === id);
          if (mock) {
            results.push({
              ...mock,
              compatibilityReason: resolveCompatibilityReason(
                mock,
                collected.get(id) ?? "Compatible Accessory"
              ),
            });
          }
        }
      }
    }

    // Best-seller fallback — return first 4 products when nothing was matched.
    if (results.length === 0) {
      let fallback: Record<string, unknown>[] = [];
      if (hasWCCredentials()) {
        const wc = await wcFetchArray("/products", { orderby: "popularity", per_page: "4" });
        if (wc && wc.length > 0) {
          fallback = wc.map(normalizeProduct);
        }
      }
      if (fallback.length === 0) {
        fallback = MOCK_PRODUCTS.slice(0, 4);
      }
      results = fallback.map((p) => ({
        ...p,
        compatibilityReason: resolveCompatibilityReason(p, "Compatible Accessory"),
      }));
    }

    // Deduplicate (by id) and cap at 8.
    const seen = new Set<number>();
    const deduped: Record<string, unknown>[] = [];
    for (const p of results) {
      const pid = Number(p["id"]);
      if (!seen.has(pid)) {
        seen.add(pid);
        deduped.push(p);
        if (deduped.length >= 8) break;
      }
    }

    // Apply product-media overlays.
    const mediaMap = await fetchProductMediaMap(deduped.map((p) => Number(p["id"])));
    res.json(
      deduped.map((p) => ({
        ...applyProductMedia(p, mediaMap.get(Number(p["id"]))),
        compatibilityReason: p["compatibilityReason"],
      }))
    );
  } catch (err) {
    logger.error({ err }, "Failed to fetch product compatibility");
    res.status(500).json({ error: "Failed to fetch product compatibility" });
  }
});

router.get("/uc/products/:id", async (req: Request, res: Response): Promise<void> => {
  const id = parseInt(String(req.params["id"]));
  const publicationSafe = req.query["publicationSafe"] === "true";
  if (publicationSafe) {
    res.setHeader("Cache-Control", "no-store");
    if (!hasCompanionCatalogue()) {
      res.status(503).json({ error: "Live product provider is not configured" });
      return;
    }
  }
  try {
    let payload: Record<string, unknown> | null = null;
    let publishedSource = false;
    if (hasCompanionCatalogue()) {
      const product = await wcFetchOne(`/products/${id}`);
      if (product) {
        if (product["status"] !== "publish") {
          res.status(404).json({ error: "Published product not found" }); return;
        }
        payload = normalizeProduct(product);
        publishedSource = product["status"] === "publish";
      }
    }
    if (!payload) {
      if (publicationSafe) {
        res.status(503).json({ error: "Live product could not be verified" });
        return;
      }
      res.status(404).json({ error: "Product not found in the app catalogue. Refresh your basket or use its permanent product address." });
      return;
    }
    if (publicationSafe && !publishedSource) {
      res.status(404).json({ error: "Published product not found" });
      return;
    }
    const mediaMap = await fetchProductMediaMap([id]);
    res.setHeader("X-UC-Product-Source", publishedSource ? "companion-published" : "unverified");
    if (publicationSafe) {
      const photos = (mediaMap.get(id) || []).filter(m => m.type === "photo");
      res.setHeader("X-UC-Catalogue-Provenance", "companion-published");
      res.json({
        id: payload["id"], sku: payload["sku"], stockStatus: payload["stockStatus"],
        price: payload["price"], salePrice: payload["salePrice"], regularPrice: payload["regularPrice"],
        images: payload["images"],
        uploadedPhotos: photos.map(m => ({ slot: m.position + 1, src: m.url, alt: m.alt })),
      });
      return;
    }
    res.json(applyProductMedia(payload, mediaMap.get(id)));
  } catch {
    res.status(500).json({ error: "Failed to fetch product" });
  }
});

// ─── Reviews ──────────────────────────────────────────────────────────────────
const REVIEW_MAX_MEDIA = 4;

/** Accepts "/objects/…" (raw objectPath), "/api/storage/objects/…",
 *  "/api/uc/product-images/…" or absolute http(s) URLs. Anything else → null. */
function normalizeMediaUrl(raw: unknown): string | null {
  if (typeof raw !== "string" || raw.length === 0 || raw.length > 2048) return null;
  if (/^https?:\/\//i.test(raw)) return raw;
  if (raw.startsWith("/objects/")) return `/api/storage${raw}`;
  if (raw.startsWith("/api/storage/objects/")) return raw;
  if (raw.startsWith("/api/uc/product-images/")) return raw;
  return null;
}

router.get("/uc/products/:id/reviews", async (req: Request, res: Response): Promise<void> => {
  const productId = parseInt(String(req.params["id"]));
  if (isNaN(productId)) {
    res.status(400).json({ error: "Invalid product id" });
    return;
  }
  try {
    const rows = await db
      .select()
      .from(ucReviewsTable)
      .where(eq(ucReviewsTable.productId, productId))
      .orderBy(desc(ucReviewsTable.createdAt));
    const count = rows.length;
    const average = count
      ? Math.round((rows.reduce((s, r) => s + r.rating, 0) / count) * 10) / 10
      : 0;
    const claims = verifyToken(req.headers["authorization"]);
    const uid = claims ? String(claims.id) : null;
    res.json({
      average,
      count,
      reviews: rows.map((r) => ({
        id: r.id,
        rating: r.rating,
        title: r.title,
        body: r.body,
        authorName: r.authorName,
        media: r.media ?? [],
        createdAt: r.createdAt,
        mine: uid !== null && r.userId === uid,
      })),
    });
  } catch (err) {
    logger.error({ err, productId }, "Failed to load reviews");
    res.status(500).json({ error: "Failed to load reviews" });
  }
});

router.post("/uc/products/:id/reviews", async (req: Request, res: Response): Promise<void> => {
  const claims = verifyToken(req.headers["authorization"]);
  if (!claims) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  const productId = parseInt(String(req.params["id"]));
  if (isNaN(productId)) {
    res.status(400).json({ error: "Invalid product id" });
    return;
  }

  const { rating, title, body, media } = req.body as {
    rating?: unknown; title?: unknown; body?: unknown;
    media?: { url?: unknown; type?: unknown }[];
  };

  // Reject deleted accounts — their JWT is still cryptographically valid.
  const reviewNumericId = Number(claims.id);
  if (await guardDeletedAccount(reviewNumericId, res)) return;

  const stars = Number(rating);
  if (!Number.isInteger(stars) || stars < 1 || stars > 5) {
    res.status(400).json({ error: "Rating must be a whole number from 1 to 5" });
    return;
  }
  const text = typeof body === "string" ? body.trim() : "";
  if (text.length < 3) {
    res.status(400).json({ error: "Please write a few words about the product" });
    return;
  }
  if (text.length > 2000) {
    res.status(400).json({ error: "Review is too long (max 2000 characters)" });
    return;
  }

  const items: ReviewMediaItem[] = [];
  if (media !== undefined) {
    if (!Array.isArray(media) || media.length > REVIEW_MAX_MEDIA) {
      res.status(400).json({ error: `You can attach up to ${REVIEW_MAX_MEDIA} photos/videos` });
      return;
    }
    let videos = 0;
    for (const m of media) {
      const url = normalizeMediaUrl(m?.url);
      const type = m?.type === "video" ? "video" : m?.type === "photo" ? "photo" : null;
      if (!url || !type) {
        res.status(400).json({ error: "Invalid attachment" });
        return;
      }
      if (type === "video" && ++videos > 1) {
        res.status(400).json({ error: "Only one video per review" });
        return;
      }
      items.push({ url, type });
    }
  }
  const reviewMediaError = await verifyUploadedMediaItems(items);
  if (reviewMediaError) {
    res.status(400).json({ error: reviewMediaError });
    return;
  }

  const userId = String(claims.id);
  // Prefer the fresh DB name; fall back to whatever the JWT carries.
  let authorName = [claims.firstName, claims.lastName?.[0] ? `${claims.lastName[0]}.` : ""]
    .filter(Boolean).join(" ") || "Customer";
  try {
    const numericId = Number(userId);
    if (!isNaN(numericId) && numericId > 0 && numericId < 1_000_000_000) {
      const dbUser = await db.query.ucUsersTable.findFirst({ where: eq(ucUsersTable.id, numericId) });
      if (dbUser) {
        authorName = [dbUser.firstName, dbUser.lastName?.[0] ? `${dbUser.lastName[0]}.` : ""]
          .filter(Boolean).join(" ") || "Customer";
      }
    }
  } catch { /* keep JWT-derived name */ }

  try {
    const result = await db.transaction(async (tx) => {
      // Serialize saves with account deletion and other saves by this identity.
      // Re-check after the lock: the earlier guard alone has a deletion race.
      if (reviewNumericId > 0 && reviewNumericId < 1_000_000_000) {
        const [user] = await tx.select().from(ucUsersTable)
          .where(eq(ucUsersTable.id, reviewNumericId)).for("update");
        if (user?.deletedAt) throw new Error("REVIEW_ACCOUNT_DELETED");
      } else {
        await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtext(${`review:${userId}`}))`);
      }
      const [existing] = await tx.select().from(ucReviewsTable)
        .where(and(eq(ucReviewsTable.productId, productId), eq(ucReviewsTable.userId, userId))).limit(1).for("update");
      const fields = { productId, userId, authorName, rating: stars,
        title: typeof title === "string" ? title.trim() : "", body: text, media: items };
      const [row] = existing
        ? await tx.update(ucReviewsTable).set(fields).where(eq(ucReviewsTable.id, existing.id)).returning()
        : await tx.insert(ucReviewsTable).values(fields).returning();
      return { row, updated: !!existing };
    });
    // Explicit customer response allowlist. Internal AI status, assessment,
    // revisions, leases and fingerprints never leak to public clients.
    const r = result.row!;
    res.status(result.updated ? 200 : 201).json({
      id: r.id, productId: r.productId, userId: r.userId, authorName: r.authorName,
      rating: r.rating, title: r.title, body: r.body, media: r.media,
      createdAt: r.createdAt, ...(result.updated ? { updated: true } : {}),
    });
  } catch (err) {
    if (err instanceof Error && err.message === "REVIEW_ACCOUNT_DELETED") {
      res.status(401).json({ error: "This account has been deleted" });
      return;
    }
    logger.error({ err, productId, userId }, "Failed to save review");
    res.status(500).json({ error: "Failed to save review" });
  }
});

// ─── Admin · product media management ─────────────────────────────────────────
function adminEmailList(): string[] {
  return (process.env["UC_ADMIN_EMAILS"] ?? "")
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
}

// Admin gate: shared helper in ../lib/adminAuth.js — accepts DB-anchored
// uc_users admins, Woo-verified (src:"woo") emails on UC_ADMIN_EMAILS, and
// ProjectHub team-session admins re-verified against the team_users row.

// Attach-time verification of uploaded media ---------------------------------
const objectStorage = new ObjectStorageService();
const UPLOADED_MEDIA_PREFIX = "/api/storage/objects/";

/** Presigned PUT URLs cannot bind size or content-type, so whatever the
 *  client actually uploaded must be re-checked here, the moment an object is
 *  attached to a review / ticket / water test / product. Returns an error
 *  message, or null when every attachment checks out. Never throws. */
async function verifyUploadedMediaItems(items: ReviewMediaItem[]): Promise<string | null> {
  for (const item of items) {
    if (!item.url.startsWith(UPLOADED_MEDIA_PREFIX)) continue; // catalogue/external URL — nothing stored to verify
    const objectPath = item.url.slice("/api/storage".length); // "/objects/uploads/<id>"
    if (!objectPath.startsWith("/objects/uploads/")) return "Invalid attachment";
    try {
      const file = await objectStorage.getObjectEntityFile(objectPath);
      const [metadata] = await file.getMetadata();
      const contentType = String(metadata.contentType ?? "").split(";")[0].trim().toLowerCase();
      const size = Number(metadata.size ?? 0);
      const cap = item.type === "video" ? MAX_VIDEO_BYTES : MAX_IMAGE_BYTES;
      if (!Number.isFinite(size) || size <= 0 || size > cap) {
        return `Attachment exceeds the ${Math.round(cap / 1024 / 1024)} MB limit`;
      }
      if (!contentType || contentType === "application/octet-stream") {
        const uploadResult = await pool.query(
          `SELECT declared_type, declared_size
             FROM instant_water_media_uploads
            WHERE object_path = $1 AND expires_at > now()
            LIMIT 1`,
          [objectPath],
        );
        const upload = uploadResult.rows[0] as {
          declared_type?: string;
          declared_size?: number | string;
        } | undefined;
        const declaredType = String(upload?.declared_type ?? "").toLowerCase();
        const declaredSize = Number(upload?.declared_size ?? 0);
        if (mediaMimeFamily(declaredType) !== item.type || declaredSize !== size) {
          return `Attachment is not ${item.type === "photo" ? "an image" : "a video"}`;
        }
      }
      const detectedType = await verifyReviewMediaContent(file, contentType, item.type);
      if (!detectedType) {
        return `Attachment is not ${item.type === "photo" ? "an image" : "a video"}`;
      }
      if (!contentType || contentType === "application/octet-stream") {
        await file.setMetadata({ contentType: detectedType });
      }
    } catch (err) {
      if (err instanceof ObjectNotFoundError) return "Attachment upload not found — please re-attach it";
      logger.error({ err, url: item.url }, "Failed to verify uploaded media");
      return "Could not verify attachment — please try again";
    }
  }
  return null;
}

/** Normalize an optional array of media URLs from the client. Returns null on
 *  malformed input (wrong shape, too many, or off-whitelist URL). */
function sanitizeMediaUrls(value: unknown, max: number): string[] | null {
  if (value === undefined || value === null) return [];
  if (!Array.isArray(value) || value.length > max) return null;
  const out: string[] = [];
  for (const v of value) {
    const normalized = normalizeMediaUrl(v);
    if (!normalized) return null;
    out.push(normalized);
  }
  return out;
}

router.get("/uc/admin/products/:id/media", async (req: Request, res: Response): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  const productId = parseInt(String(req.params["id"]));
  if (isNaN(productId)) {
    res.status(400).json({ error: "Invalid product id" });
    return;
  }
  try {
    const rows = await db
      .select()
      .from(ucProductMediaTable)
      .where(eq(ucProductMediaTable.productId, productId))
      .orderBy(asc(ucProductMediaTable.position), asc(ucProductMediaTable.id));
    res.json(rows);
  } catch (err) {
    logger.error({ err, productId }, "Failed to load product media");
    res.status(500).json({ error: "Failed to load product media" });
  }
});

router.post("/uc/admin/products/:id/media", async (req: Request, res: Response): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  const productId = parseInt(String(req.params["id"]));
  if (isNaN(productId)) {
    res.status(400).json({ error: "Invalid product id" });
    return;
  }
  const { url, type, alt, position } = req.body as {
    url?: unknown; type?: unknown; alt?: unknown; position?: unknown;
  };
  const normalized = normalizeMediaUrl(url);
  const mediaType = type === "video" ? "video" : type === "photo" ? "photo" : null;
  if (!normalized || !mediaType) {
    res.status(400).json({ error: "A valid url and type ('photo' | 'video') are required" });
    return;
  }
  const adminMediaError = await verifyUploadedMediaItems([{ url: normalized, type: mediaType }]);
  if (adminMediaError) {
    res.status(400).json({ error: adminMediaError });
    return;
  }
  try {
    const [row] = await db
      .insert(ucProductMediaTable)
      .values({
        productId,
        type: mediaType,
        url: normalized,
        alt: typeof alt === "string" ? alt : "",
        position: Number.isInteger(Number(position)) ? Number(position) : 0,
      })
      .returning();
    res.status(201).json(row);
  } catch (err) {
    logger.error({ err, productId }, "Failed to add product media");
    res.status(500).json({ error: "Failed to add product media" });
  }
});

router.delete("/uc/admin/media/:mediaId", async (req: Request, res: Response): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  const mediaId = parseInt(String(req.params["mediaId"]));
  if (isNaN(mediaId)) {
    res.status(400).json({ error: "Invalid media id" });
    return;
  }
  try {
    const deleted = await db
      .delete(ucProductMediaTable)
      .where(eq(ucProductMediaTable.id, mediaId))
      .returning();
    if (deleted.length === 0) {
      res.status(404).json({ error: "Media not found" });
      return;
    }
    res.json({ ok: true });
  } catch (err) {
    logger.error({ err, mediaId }, "Failed to delete product media");
    res.status(500).json({ error: "Failed to delete product media" });
  }
});

// ─── Auth ─────────────────────────────────────────────────────────────────────
function publicCompanionEmail(email: string): string {
  // Phone-only offline accounts use an opaque database-compatible address.
  // It is an implementation detail, never the customer's login identity.
  return email.endsWith("@accounts.ucfilters.invalid") ? "" : email;
}

export type RegistrationDbErrorCode = "unique_conflict" | "unavailable" | "unknown";

/** Convert database failures to an allowlisted, non-sensitive operational code. */
export function classifyRegistrationDbError(error: unknown): RegistrationDbErrorCode {
  const code = typeof error === "object" && error !== null && "code" in error
    ? String((error as { code?: unknown }).code)
    : "";
  if (code === "23505") return "unique_conflict";
  if (["08000", "08001", "08003", "08004", "08006", "57P01"].includes(code)) return "unavailable";
  return "unknown";
}

router.post("/uc/auth/login", authLimiter, async (req: Request, res: Response): Promise<void> => {
  res.set("Cache-Control", "no-store");
  const { email, identifier, phone, password } = req.body as {
    email?: string; identifier?: string; phone?: string; password?: string;
  };
  const loginIdentifier = identifier ?? email ?? phone;
  if (!loginIdentifier || !password) {
    res.status(400).json({ error: "Email or phone and password required" });
    return;
  }

  const normalizedEmail = loginIdentifier.includes("@") ? normalizeEmail(loginIdentifier) : null;
  const normalizedPhone = normalizedEmail ? null : normalizePhone(loginIdentifier);
  if (!normalizedEmail && !normalizedPhone) {
    res.status(400).json({ error: phoneValidationMessage() });
    return;
  }

  // Prefer an existing Companion account. A same-email WooCommerce account
  // must never bypass the Companion password or silently replace its identity.
  try {
    const dbUsers = await db.select().from(ucUsersTable).where(and(
      normalizedEmail ? eq(ucUsersTable.email, normalizedEmail) : eq(ucUsersTable.phone, normalizedPhone!),
      isNull(ucUsersTable.deletedAt),
    )).limit(2);
    // A legacy duplicate phone must fail closed rather than selecting an
    // arbitrary customer's password.
    if (dbUsers.length > 1) {
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }
    const dbUser = dbUsers[0];
    if (dbUser && dbUser.authProvider !== "woocommerce") {
      const match = await bcryptjs.compare(password, dbUser.passwordHash);
      if (!match) {
        res.status(401).json({ error: "Invalid credentials" });
        return;
      }
      if (
        dbUser.mustChangePassword
        && (!dbUser.temporaryPasswordExpiresAt
          || dbUser.temporaryPasswordExpiresAt.getTime() <= Date.now())
      ) {
        res.status(401).json({ error: "This temporary password has expired. Request a new one." });
        return;
      }
      const user = {
        id: dbUser.id,
        email: publicCompanionEmail(dbUser.email),
        phone: dbUser.phone,
        firstName: dbUser.firstName,
        lastName: dbUser.lastName,
        address: dbUser.address ?? "",
        credentialVersion: dbUser.credentialVersion,
        mustChangePassword: dbUser.mustChangePassword,
        temporaryPasswordExpiresAt: dbUser.mustChangePassword
          ? dbUser.temporaryPasswordExpiresAt
          : undefined,
        emailVerified: dbUser.emailVerified,
        phoneVerified: dbUser.phoneVerified,
      };
      res.json({ token: issueToken(user), user });
      return;
    }
  } catch {
    // Keep WooCommerce login available when the Companion database is
    // temporarily unavailable; provisioning below remains fail-closed.
  }

  try {
    const wcBase = process.env["WC_BASE_URL"] || "https://www.ucfilters.com";
    if (!normalizedEmail) {
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }
    const jwtRes = await fetch(`${wcBase}/wp-json/jwt-auth/v1/token`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: normalizedEmail, password }),
    });
    const jwtData: unknown = await jwtRes.json();
    if (
      !jwtRes.ok
      || !jwtData
      || typeof jwtData !== "object"
      || !("token" in jwtData)
      || typeof (jwtData as Record<string, unknown>)["token"] !== "string"
      || !((jwtData as Record<string, unknown>)["token"] as string).trim()
    ) {
      // Preserve the development-only demo-session path when Woo explicitly
      // rejects credentials or is unavailable. Production still fails closed
      // after the catch below.
      throw new Error("WooCommerce credentials were not verified");
    }
    if (
      typeof (jwtData as Record<string, unknown>)["user_email"] !== "string"
      || !((jwtData as Record<string, unknown>)["user_email"] as string).trim()
    ) {
      // A successful token response must bind the asserted account to a
      // provider-owned email; never downgrade an incomplete success to demo.
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }
    const providerEmail = normalizeEmail((jwtData as Record<string, unknown>)["user_email"] as string);
    if (!providerEmail || providerEmail !== normalizedEmail) {
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }
    if (
      jwtData &&
      typeof jwtData === "object" &&
      "token" in jwtData &&
      typeof (jwtData as Record<string, unknown>)["token"] === "string"
    ) {
      const d = jwtData as Record<string, unknown>;
      const displayName = (d["user_display_name"] as string | undefined) ?? "";
      const wcEmail = providerEmail;
      const firstName = displayName.split(" ")[0] || "Customer";
      const lastName = displayName.split(" ").slice(1).join(" ");

      const wooClient = await pool.connect();
      let provisioned: any = null;
      try {
        await wooClient.query("BEGIN");
        const classification = await resolveCustomerIdentity({ email: wcEmail }, wooClient);
        if (classification.kind === "one_active_candidate") {
          const existing = await wooClient.query<any>(
            "SELECT * FROM uc_users WHERE id=$1", [classification.customerId],
          );
          // Woo credentials were verified above. Existing Companion/password
          // accounts still require their Companion password and are never
          // claimed or modified by this fallback.
          if (existing.rows[0]?.auth_provider === "woocommerce") {
            const row = existing.rows[0];
            provisioned = {
              id: row.id, email: row.email, phone: row.phone,
              firstName: row.first_name, lastName: row.last_name,
              address: row.address, credentialVersion: row.credential_version,
              emailVerified: row.email_verified, phoneVerified: row.phone_verified,
            };
          }
        } else if (classification.kind === "create_allowed") {
          const passwordHash = await bcryptjs.hash(randomUUID(), 10);
          const inserted = await wooClient.query<any>(
            `INSERT INTO uc_users(email,password_hash,first_name,last_name,auth_provider,email_verified)
             VALUES($1,$2,$3,$4,'woocommerce',true) RETURNING *`,
            [wcEmail, passwordHash, firstName, lastName],
          );
          const row = inserted.rows[0];
          if (row) {
            provisioned = {
              id: row.id, email: row.email, phone: row.phone,
              firstName: row.first_name, lastName: row.last_name,
              address: row.address, credentialVersion: row.credential_version,
              emailVerified: row.email_verified, phoneVerified: row.phone_verified,
            };
          }
        }
        await wooClient.query("COMMIT");
      } catch (error) {
        await wooClient.query("ROLLBACK").catch(() => undefined);
        throw error;
      } finally {
        wooClient.release();
      }

      if (!provisioned) {
        res.status(409).json({
          error: "A Companion account already uses this email. Sign in with its Companion password.",
        });
        return;
      }

      const user = {
        id: provisioned.id,
        email: provisioned.email,
        phone: provisioned.phone,
        firstName: provisioned.firstName,
        lastName: provisioned.lastName,
        address: provisioned.address ?? "",
        credentialVersion: provisioned.credentialVersion,
        emailVerified: provisioned.emailVerified,
        phoneVerified: provisioned.phoneVerified,
      };
      res.json({ token: issueToken({ ...user, src: "woo" }), user });
      return;
    }
  } catch { /* fall through to development-only demo session */ }

  // No database or WooCommerce account. Development only: allow an ephemeral
  // demo session so the app can be tried before external credentials exist.
  if (process.env["NODE_ENV"] !== "production" && password.length >= 6) {
    const name = loginIdentifier.split("@")[0] ?? "customer";
    const mockUser = {
      id:        Date.now(),
      email: loginIdentifier,
      phone:     "",
      firstName: name.charAt(0).toUpperCase() + name.slice(1),
      lastName:  "Customer",
    };
    res.json({ token: issueToken(mockUser), user: mockUser });
    return;
  }
  res.status(401).json({ error: "Invalid credentials" });
});

router.post("/uc/auth/register", authLimiter, async (req: Request, res: Response): Promise<void> => {
  const { email, phone, password, firstName, lastName, referralCode } = req.body as {
    email?: string;
    phone?: string;
    password?: string;
    firstName?: string;
    lastName?: string;
    referralCode?: string;
  };
  if (!email || !phone || !password || !firstName) {
    res.status(400).json({ error: "First name, email, phone number and password are required" });
    return;
  }
  if (password.length < 6) {
    res.status(400).json({ error: "Password must be at least 6 characters" });
    return;
  }
  const normalizedEmail = normalizeEmail(email);
  const cleanPhone = normalizePhone(phone);
  if (!cleanPhone) {
    res.status(400).json({ error: phoneValidationMessage() });
    return;
  }
  try {
    // Serialize both identity values before querying. This protects races even
    // when a legacy duplicate prevents the optional partial unique index from
    // being installed.
    const registrationClient = await pool.connect();
    let registration: { kind: string; dbUser?: any; referral?: { status: string } };
    try {
      await registrationClient.query("BEGIN");
      const classification = await resolveCustomerIdentity(
        { email: normalizedEmail, phone: cleanPhone },
        registrationClient,
      );
      if (classification.kind !== "create_allowed") {
        if (classification.kind === "one_active_candidate") {
          const owner = await registrationClient.query<{ email: string }>(
            "SELECT email FROM uc_users WHERE id=$1", [classification.customerId],
          );
          registration = {
            kind: owner.rows[0]?.email === normalizedEmail ? "email-conflict" : "phone-conflict",
          };
        } else {
          // Preserve the historical public conflict distinction where it is
          // unambiguous, while never creating around a deleted/ambiguous owner.
          registration = {
            kind: classification.kind === "email_phone_conflict" || classification.kind === "deleted_only"
              ? "email-conflict" : "phone-conflict",
          };
        }
        await registrationClient.query("COMMIT");
      } else {
          const passwordHash = await bcryptjs.hash(password, 10);
          const inserted = await registrationClient.query(
            `INSERT INTO uc_users(email,password_hash,phone,email_verified,phone_verified,first_name,last_name)
             VALUES($1,$2,$3,false,false,$4,$5) RETURNING *`,
            [normalizedEmail, passwordHash, cleanPhone, firstName.trim(), lastName?.trim() ?? ""],
          );
          const row = inserted.rows[0];
          let referral: { status: string } | undefined;
          if (referralCode?.trim()) {
            referral = { status: await registerReferralAtSignupWithClient(registrationClient, normalizedEmail, referralCode.trim()) };
          }
          await registrationClient.query("COMMIT");
          registration = { kind: "created", dbUser: {
            id: row.id, email: row.email, phone: row.phone, firstName: row.first_name,
            lastName: row.last_name, address: row.address, credentialVersion: row.credential_version,
            emailVerified: row.email_verified, phoneVerified: row.phone_verified, createdAt: row.created_at,
          }, referral };
      }
    } catch (error) {
      await registrationClient.query("ROLLBACK").catch(() => undefined);
      throw error;
    } finally {
      registrationClient.release();
    }

    if (registration.kind === "email-conflict") {
      res.status(409).json({
        error: "An account with this email already exists. If you recently tried to register and hit an error, your account was created — please use 'Forgot password' to set a new password and log in.",
        hint: "forgot_password",
      });
      return;
    }
    if (registration.kind === "phone-conflict") {
      res.status(409).json({
        error: "An active account already uses this phone number. Sign in to that account or use a different number.",
      });
      return;
    }
    const dbUser = registration.dbUser;
    const user = {
      id: dbUser!.id,
      email: dbUser!.email,
      phone: dbUser!.phone,
      firstName: dbUser!.firstName,
      lastName: dbUser!.lastName,
      address: dbUser!.address ?? "",
      credentialVersion: dbUser!.credentialVersion,
      emailVerified: dbUser!.emailVerified,
      phoneVerified: dbUser!.phoneVerified,
    };
    // Durable folder record of the new account (sanitized — never password material).
    recordAccountRegistration({
      id: dbUser!.id, firstName: dbUser!.firstName, lastName: dbUser!.lastName,
      email: dbUser!.email, phone: dbUser!.phone,
      authProvider: "password", createdAt: dbUser!.createdAt,
      source: "registration", dbPersisted: true,
    }).catch(() => {});
    res.json({ token: issueToken(user), user, ...(registration.referral ? { referral: registration.referral } : {}) });
  } catch (err) {
    // DB insert failed. Never silently issue a session with no saved account —
    // write the registration to the durable folder record and tell the caller
    // what happened so they can retry once the database is back.
    logger.error(
      { event: "registration_db_error", errorCode: classifyRegistrationDbError(err) },
      "[register] DB error — writing folder record instead of ephemeral session",
    );
    try {
      await recordAccountRegistration({
        id: null, firstName, lastName: lastName ?? "",
        email: normalizedEmail, phone: cleanPhone,
        authProvider: "password", createdAt: new Date(),
        source: "registration", dbPersisted: false,
      }, { critical: true });
      res.status(503).json({
        error: "We couldn't finish creating your account right now. Your details have been safely recorded — please try registering again in a few minutes.",
      });
    } catch (innerErr) {
      logger.error(
        { event: "registration_backup_write_error", errorCode: classifyRegistrationDbError(innerErr) },
        "[register] dual failure — DB insert failed AND folder write failed; registration details not recorded",
      );
      // Alert the team — the customer's details were NOT saved anywhere.
      // Both calls are fire-and-forget; they must never block or throw here.
      const dualFailEmail = String(email ?? "").toLowerCase().trim();
      const dualFailPhone = String(cleanPhone ?? "");
      sendSlackTeamMessage(
        `⚠️ *Registration lost — dual failure*\nA customer registration could not be saved to the database OR the backup folder.\n*Email:* ${dualFailEmail}\n*Phone:* ${dualFailPhone}\nContact the customer directly to complete their registration.`,
        "DUAL_FAILURE_REGISTRATION",
      ).catch(() => {});
      notifyOffice(
        "⚠️ Registration lost — dual failure (DB + folder both failed)",
        [
          "A customer registration was lost. Both the database insert and the backup folder write failed.",
          "The customer's details were NOT recorded anywhere.",
          "",
          `Email: ${dualFailEmail}`,
          `Phone: ${dualFailPhone}`,
          "",
          "Please contact the customer directly to complete their registration.",
        ],
      ).catch(() => {});
      res.status(503).json({
        error: "We couldn't save your details right now. Please contact us directly to complete your registration — your information was not recorded.",
      });
    }
  }
});

// ─── Password reset ───────────────────────────────────────────────────────────

function hashContact(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}

/**
 * POST /uc/customer/contact-verification/request
 * Sends a credential only to the contact already stored on the authenticated
 * account. The secret is hashed at rest and never returned by this endpoint.
 */
router.post("/uc/customer/contact-verification/request", authLimiter, async (req: Request, res: Response): Promise<void> => {
  const claims = verifyToken(req.headers["authorization"]);
  const userId = Number(claims?.id);
  const channel = req.body?.channel as unknown;
  if (!claims || !Number.isInteger(userId) || userId <= 0) {
    res.status(401).json({ error: "Authentication required." });
    return;
  }
  if (!["email", "whatsapp"].includes(String(channel))) {
    res.status(400).json({ error: "channel must be email or whatsapp." });
    return;
  }
  const [user] = await db.select().from(ucUsersTable)
    .where(and(eq(ucUsersTable.id, userId), isNull(ucUsersTable.deletedAt))).limit(1);
  if (!user) {
    res.status(202).json({ ok: true });
    return;
  }
  const selectedChannel = channel as RecoveryChannel;
  const destination = selectedChannel === "email"
    ? normalizeEmail(user.email)
    : normalizePhone(user.phone);
  if (!destination) {
    res.status(202).json({ ok: true });
    return;
  }

  let baseUrl: string;
  try {
    baseUrl = ucApiBaseUrl();
  } catch {
    logger.error({ event: "contact_verification_request", channel: selectedChannel, result: "delivery_failed" }, "Contact verification unavailable");
    res.status(202).json({ ok: true });
    return;
  }
  const rawToken = randomUUID();
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000);
  const credential = await db.transaction(async (tx) => {
    await tx.update(ucContactVerificationTokensTable)
      .set({ usedAt: new Date() })
      .where(and(
        eq(ucContactVerificationTokensTable.userId, String(user.id)),
        eq(ucContactVerificationTokensTable.channel, selectedChannel),
        isNull(ucContactVerificationTokensTable.usedAt),
      ));
    return tx.insert(ucContactVerificationTokensTable).values({
      userId: String(user.id),
      channel: selectedChannel,
      contactHash: hashContact(destination),
      tokenHash: hashResetToken(rawToken),
      expiresAt,
    }).returning({ id: ucContactVerificationTokensTable.id });
  });
  const verificationUrl = `${baseUrl}/uc/auth/verify-contact?token=${encodeURIComponent(rawToken)}`;
  let sent = false;
  if (selectedChannel === "email") {
    sent = await sendViaResend({
      from: "Ultra Clear App <noreply@contacts.ucfilters.com>",
      to: destination,
      subject: "Verify your Ultra-Clear email",
      text: `Verify this email for account recovery (valid for 30 minutes):\n${verificationUrl}`,
      html: `<p>Verify this email for account recovery (valid for 30 minutes):</p><p><a href="${verificationUrl}">Verify email</a></p>`,
      meta: { template: "uc-contact-verification" },
      logBody: "Contact verification email dispatched (credential redacted)",
    });
  } else {
    try {
      await sendWhatsAppMessage(destination, `Verify this WhatsApp number for Ultra-Clear account recovery (valid for 30 minutes): ${verificationUrl}`);
      sent = true;
    } catch {
      sent = false;
    }
  }
  if (!sent && credential[0]) {
    await db.update(ucContactVerificationTokensTable).set({ usedAt: new Date() })
      .where(eq(ucContactVerificationTokensTable.id, credential[0].id));
  }
  logger[sent ? "info" : "warn"](
    { event: "contact_verification_request", channel: selectedChannel, result: sent ? "issued" : "delivery_failed" },
    "Contact verification request processed",
  );
  res.status(202).json({ ok: true });
});

async function consumeContactVerification(rawToken: string): Promise<boolean> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const claimed = await client.query<{ user_id: string; channel: RecoveryChannel; contact_hash: string }>(
      `UPDATE uc_contact_verification_tokens
          SET used_at = now()
        WHERE token_hash = $1 AND used_at IS NULL AND expires_at > now()
      RETURNING user_id, channel, contact_hash`,
      [hashResetToken(rawToken)],
    );
    if ((claimed.rowCount ?? 0) !== 1) {
      await client.query("ROLLBACK");
      return false;
    }
    const credential = claimed.rows[0]!;
    const account = await client.query<{ email: string; phone: string }>(
      "SELECT email, phone FROM uc_users WHERE id = $1 AND deleted_at IS NULL FOR UPDATE",
      [Number(credential.user_id)],
    );
    const user = account.rows[0];
    const destination = credential.channel === "email"
      ? user && normalizeEmail(user.email)
      : user && normalizePhone(user.phone);
    if (!destination || hashContact(destination) !== credential.contact_hash) {
      // Contact changed since issuance: consume the stale credential but do not
      // verify the replacement contact.
      await client.query("COMMIT");
      return false;
    }
    const column = credential.channel === "email" ? "email_verified" : "phone_verified";
    await client.query(`UPDATE uc_users SET ${column} = true WHERE id = $1`, [Number(credential.user_id)]);
    await client.query(
      "UPDATE uc_contact_verification_tokens SET verified_at = now() WHERE token_hash = $1",
      [hashResetToken(rawToken)],
    );
    await client.query("COMMIT");
    logger.info({ event: "contact_verification_completed", channel: credential.channel, result: "completed" }, "Contact verified");
    return true;
  } catch (err) {
    await client.query("ROLLBACK").catch(() => undefined);
    throw err;
  } finally {
    client.release();
  }
}

/** Browser-friendly verification link. Invalid/expired/used tokens share one response. */
router.get("/uc/auth/verify-contact", authLimiter, async (req: Request, res: Response): Promise<void> => {
  const token = typeof req.query["token"] === "string" ? req.query["token"] : "";
  const verified = token ? await consumeContactVerification(token) : false;
  res.status(verified ? 200 : 400).type("html").send(
    verified
      ? "<!doctype html><html><body><h1>Contact verified</h1><p>You can return to the Ultra-Clear app.</p></body></html>"
      : "<!doctype html><html><body><h1>Link unavailable</h1><p>This verification link is invalid, expired, or already used.</p></body></html>",
  );
});

/**
 * SHA-256 hash of a reset token for at-rest storage.
 * Only the hash is persisted; the raw token travels over email/HTTPS only.
 * High-entropy random tokens (UUID v4) don't need bcrypt's key-stretching —
 * a fast digest is sufficient and keeps lookups cheap.
 */
function hashResetToken(raw: string): string {
  return createHash("sha256").update(raw).digest("hex");
}

type RecoveryChannel = "email" | "whatsapp";

const genericRecoveryResponse = { ok: true };

async function recordPasswordResetAudit(input: {
  actorType: "self" | "team";
  actorId?: string;
  targetUserId?: string;
  channel?: RecoveryChannel;
  result: "issued" | "completed" | "delivery_failed" | "rejected";
}): Promise<void> {
  // Audits must not become an availability dependency for authentication.
  await db.insert(ucPasswordResetAuditTable).values({
    actorType: input.actorType,
    actorId: input.actorId,
    targetUserId: input.targetUserId,
    channel: input.channel,
    result: input.result,
  }).catch((err) => logger.warn({ err, event: "password_reset_audit_write_failed" }, "Operational event failed"));
}

function preferredRecoveryChannel(
  user: { emailVerified: boolean; phoneVerified: boolean; phone: string; email?: string },
  requested: unknown,
): RecoveryChannel | null {
  if (requested === "email") return user.emailVerified && Boolean(user.email?.trim()) ? "email" : null;
  if (requested === "whatsapp") return user.phoneVerified && Boolean(normalizePhone(user.phone)) ? "whatsapp" : null;
  if (user.emailVerified && Boolean(user.email?.trim())) return "email";
  return user.phoneVerified && normalizePhone(user.phone) ? "whatsapp" : null;
}

/** Generate a credential with enough entropy to be used as a one-time,
 * operator-issued password. It is intentionally never persisted or logged. */
function generateTemporaryPassword(): string {
  return randomBytes(24).toString("base64url");
}

type TemporaryPasswordTarget = {
  id: number;
  email: string;
  phone: string;
  firstName: string;
  emailVerified: boolean;
  phoneVerified: boolean;
  authProvider: string;
};

async function deliverTemporaryPassword(
  user: TemporaryPasswordTarget,
  channel: RecoveryChannel,
  temporaryPassword: string,
  expiresAt: Date,
): Promise<{ sent: boolean; reason?: "whatsapp_disconnected" | "delivery_provider_failure" }> {
  const expiry = expiresAt.toISOString();
  if (channel === "email") {
    const sent = await sendViaResend({
      from: "Ultra Clear App <noreply@contacts.ucfilters.com>",
      to: user.email,
      subject: "Your temporary Ultra-Clear password",
      text: [
        `Hello ${user.firstName},`,
        "",
        "An authorized Ultra-Clear team member issued a temporary password for your Companion account.",
        `Temporary password: ${temporaryPassword}`,
        "Sign in within 24 hours and choose a permanent password before using Companion.",
        `This credential expires at ${expiry}.`,
      ].join("\n"),
      html: `<p>Hello ${user.firstName},</p><p>An authorized Ultra-Clear team member issued a temporary password for your Companion account.</p><p><strong>Temporary password:</strong> ${temporaryPassword}</p><p>Sign in within 24 hours and choose a permanent password before using Companion.</p><p>This credential expires at ${expiry}.</p>`,
      meta: { template: "uc-temporary-password", auditMode: "metadata-only" },
      logBody: "Temporary password email dispatched (credential redacted)",
    });
    return sent ? { sent: true } : { sent: false, reason: "delivery_provider_failure" };
  }
  const phone = normalizePhone(user.phone);
  if (!phone) return { sent: false, reason: "delivery_provider_failure" };
  if (getWhatsAppStatus().state !== "connected") {
    return { sent: false, reason: "whatsapp_disconnected" };
  }
  try {
    await sendWhatsAppMessage(
      phone,
      `Ultra-Clear temporary password: ${temporaryPassword}. Sign in within 24 hours and choose a permanent password before using Companion.`,
    );
    return { sent: true };
  } catch {
    return { sent: false, reason: "delivery_provider_failure" };
  }
}

async function issueTemporaryPassword(
  user: TemporaryPasswordTarget,
  channel: RecoveryChannel,
  actorId: string,
): Promise<
  | { password: string; expiresAt: Date }
  | { failure: "account_ineligible" | "unavailable_unverified_destination" | "whatsapp_disconnected" | "delivery_provider_failure" }
  | null
> {
  if (user.authProvider !== "password") return { failure: "account_ineligible" };

  // Keep a per-customer advisory lock on one pool connection across both the
  // credential installation and external delivery. A transaction-scoped lock
  // would be released before delivery and permit two issuances to race.
  const client = await pool.connect();
  let password = "";
  let passwordHash = "";
  let expiresAt: Date;
  let issuedVersion = 0;
  let previous: {
    passwordHash: string;
    mustChangePassword: boolean;
    temporaryPasswordExpiresAt: Date | null;
    credentialVersion: number;
  } | undefined;
  let deliveryUser: TemporaryPasswordTarget = user;
  try {
    await client.query("SELECT pg_advisory_lock(hashtext($1))", [`uc-temporary-password:${user.id}`]);
    await client.query("BEGIN");
    const current = await client.query<{
      password_hash: string;
      must_change_password: boolean;
      temporary_password_expires_at: Date | null;
      credential_version: number;
      email: string;
      phone: string;
      first_name: string;
      email_verified: boolean;
      phone_verified: boolean;
      auth_provider: string;
    }>(
      `SELECT password_hash, must_change_password, temporary_password_expires_at,
              credential_version, email, phone, first_name,
              email_verified, phone_verified, auth_provider
         FROM uc_users
        WHERE id = $1 AND deleted_at IS NULL
        FOR UPDATE`,
      [user.id],
    );
    const row = current.rows[0];
    if (!row || row.auth_provider !== "password") {
      await client.query("ROLLBACK");
      return { failure: "account_ineligible" };
    }
    deliveryUser = {
      id: user.id,
      email: row.email,
      phone: row.phone,
      firstName: row.first_name,
      emailVerified: row.email_verified,
      phoneVerified: row.phone_verified,
      authProvider: row.auth_provider,
    };
    if (
      (channel === "email" && (!row.email_verified || !row.email.trim()))
      || (channel === "whatsapp" && (!row.phone_verified || !normalizePhone(row.phone)))
    ) {
      await client.query("ROLLBACK");
      return { failure: "unavailable_unverified_destination" };
    }
    previous = {
      passwordHash: row.password_hash,
      mustChangePassword: row.must_change_password,
      temporaryPasswordExpiresAt: row.temporary_password_expires_at,
      credentialVersion: row.credential_version,
    };
    password = generateTemporaryPassword();
    expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
    passwordHash = await bcryptjs.hash(password, 12);
    issuedVersion = previous.credentialVersion + 1;
    await client.query(
      `UPDATE uc_users
          SET password_hash = $1, credential_version = $2,
              temporary_password_expires_at = $3, must_change_password = true
        WHERE id = $4`,
      [passwordHash, issuedVersion, expiresAt, user.id],
    );
    await client.query("COMMIT");

    let sent = false;
    let failureReason: "whatsapp_disconnected" | "delivery_provider_failure" | undefined;
    try {
      const delivery = await deliverTemporaryPassword(deliveryUser, channel, password, expiresAt);
      sent = delivery.sent;
      failureReason = delivery.reason;
    } catch {
      logger.warn({ event: "temporary_password_delivery_failed", channel }, "Temporary password delivery failed");
    }
    if (sent) {
      // Do not consume recovery links until the operator credential has
      // actually been accepted by the selected provider. This transaction is
      // intentionally after delivery; a failed delivery must leave an
      // existing self-service link usable.
      try {
        await client.query("BEGIN");
        await client.query(
          `UPDATE password_reset_tokens
              SET used_at = now()
            WHERE user_id = $1 AND used_at IS NULL`,
          [String(user.id)],
        );
        await client.query("COMMIT");
      } catch (error) {
        try { await client.query("ROLLBACK"); } catch { /* transaction already closed */ }
        // The temporary credential was delivered, so keep it active. A
        // transient audit-token failure should not make the operator retry and
        // issue another credential; the active links remain safe to use.
        logger.error({ err: error, userId: user.id }, "Could not invalidate prior password-reset links after delivery");
      }
    }
    await recordPasswordResetAudit({
      actorType: "team",
      actorId,
      targetUserId: String(user.id),
      channel,
      result: sent ? "issued" : "delivery_failed",
    });
    if (!sent) {
      // Restore every prior credential field only if this issuance still owns
      // the row. In particular, do not replace a permanent password that won
      // a concurrent change while delivery was in flight.
      await client.query("BEGIN");
      await client.query(
        `UPDATE uc_users
            SET password_hash = $1, must_change_password = $2,
                temporary_password_expires_at = $3, credential_version = $4
          WHERE id = $5 AND credential_version = $6 AND password_hash = $7`,
        [
          previous.passwordHash,
          previous.mustChangePassword,
          previous.temporaryPasswordExpiresAt,
          previous.credentialVersion,
          user.id,
          issuedVersion,
          passwordHash,
        ],
      );
      await client.query("COMMIT");
      return {
        failure: failureReason === "whatsapp_disconnected"
          ? "whatsapp_disconnected"
          : "delivery_provider_failure",
      };
    }
    return { password, expiresAt };
  } catch (error) {
    try { await client.query("ROLLBACK"); } catch { /* transaction already closed */ }
    logger.warn({ err: error, event: "temporary_password_issue_failed" }, "Temporary password issuance failed");
    return { failure: "delivery_provider_failure" };
  } finally {
    try { await client.query("SELECT pg_advisory_unlock(hashtext($1))", [`uc-temporary-password:${user.id}`]); } catch { /* connection cleanup */ }
    client.release();
  }
}

async function issueCompanionReset(
  user: { id: number; email: string; phone: string; firstName: string; emailVerified: boolean; phoneVerified: boolean },
  channel: RecoveryChannel,
  actor: { type: "self" | "team"; id?: string },
): Promise<boolean> {
  let resetBaseUrl: string;
  try {
    resetBaseUrl = ucApiBaseUrl();
  } catch {
    await recordPasswordResetAudit({ actorType: actor.type, actorId: actor.id, targetUserId: String(user.id), channel, result: "delivery_failed" });
    logger.error({ event: "password_reset_request", result: "delivery_failed", channel }, "Companion password reset delivery unavailable");
    return false;
  }
  const rawToken = randomUUID();
  const tokenHash = hashResetToken(rawToken);
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
  // A newly-issued reset supersedes every previous outstanding link.
  await db.transaction(async (tx) => {
    await tx.update(passwordResetTokensTable)
      .set({ usedAt: new Date() })
      .where(and(eq(passwordResetTokensTable.userId, String(user.id)), isNull(passwordResetTokensTable.usedAt)));
    await tx.insert(passwordResetTokensTable).values({ userId: String(user.id), token: tokenHash, expiresAt });
  });

  const webResetUrl = `${resetBaseUrl}/uc/auth/reset-password?token=${rawToken}`;
  const companionBase = (process.env["UC_COMPANION_RESET_URL"] ?? "uc-companion://auth/forgot-password").replace(/\/$/, "");
  const companionResetUrl = `${companionBase}?resetToken=${encodeURIComponent(rawToken)}`;
  let sent = false;
  if (channel === "email") {
    sent = await sendViaResend({
      from: "Ultra Clear App <noreply@contacts.ucfilters.com>",
      to: user.email,
      subject: "Reset your Ultra-Clear password",
      text: `Use this one-time link to choose a new password (valid for 24 hours):\n${companionResetUrl}\n\nWeb alternative:\n${webResetUrl}`,
      html: `<p>Use this one-time link to choose a new password (valid for 24 hours).</p><p><a href="${companionResetUrl}">Reset in the Ultra-Clear app</a></p><p><a href="${webResetUrl}">Reset on the web</a></p>`,
      meta: { template: "uc-password-reset" },
      logBody: "Password reset email dispatched (reset URL redacted)",
    });
  } else {
    const phone = normalizePhone(user.phone);
    if (phone) {
      try {
        await sendWhatsAppMessage(phone, `Ultra-Clear password reset (valid for 24 hours): ${companionResetUrl}`);
        sent = true;
      } catch {
        sent = false;
      }
    }
  }
  await recordPasswordResetAudit({
    actorType: actor.type, actorId: actor.id, targetUserId: String(user.id), channel,
    result: sent ? "issued" : "delivery_failed",
  });
  logger[sent ? "info" : "warn"](
    { event: "password_reset_request", result: sent ? "issued" : "delivery_failed", channel },
    "Companion password reset request processed",
  );
  return sent;
}

/** POST /uc/auth/forgot-password — always 200 to prevent account enumeration */
router.post("/uc/auth/forgot-password", authLimiter, async (req: Request, res: Response): Promise<void> => {
  const { email, phone, identifier, channel } = req.body ?? {};
  const supplied = typeof identifier === "string" ? identifier : typeof email === "string" ? email : phone;
  if (!supplied || typeof supplied !== "string") {
    res.status(400).json({ error: "email or phone is required." });
    return;
  }
  try {
    const normalizedPhone = normalizePhone(supplied);
    const normalizedEmail = normalizeEmail(supplied);
    const user = await db.query.ucUsersTable.findFirst({
      where: and(
        isNull(ucUsersTable.deletedAt),
        normalizedPhone
          ? or(eq(ucUsersTable.phone, normalizedPhone), eq(ucUsersTable.email, normalizedEmail))
          : eq(ucUsersTable.email, normalizedEmail),
      ),
    });
    // The response and event deliberately do not distinguish missing accounts,
    // unavailable channels, or delivery configuration.
    const selectedChannel = user && user.authProvider === "password"
      ? preferredRecoveryChannel(user, channel)
      : null;
    if (user && selectedChannel) await issueCompanionReset(user, selectedChannel, { type: "self" });
    else await recordPasswordResetAudit({ actorType: "self", result: "rejected" });
  } catch (err) {
    logger.error({ err, event: "password_reset_request", result: "failed" }, "Companion password reset request failed");
  }
  res.json(genericRecoveryResponse);
});

/**
 * POST /uc/admin/users/:id/reset-password
 *
 * ProjectHub staff must authenticate with a durable, active team_users row;
 * the role embedded in a stale JWT is never sufficient. The response contains
 * delivery metadata only — never a credential, URL, password, or contact.
 */
router.post("/uc/admin/users/:id/reset-password", async (req: Request, res: Response): Promise<void> => {
  const claims = verifyToken(req.headers["authorization"]);
  if (!claims || claims.type !== "team-session") {
    res.status(401).json({ error: "Authentication required." });
    return;
  }
  const [actor] = await db.select().from(teamUsersTable).where(eq(teamUsersTable.id, String(claims.id))).limit(1);
  const permissions = (actor?.permissions ?? {}) as Record<string, string>;
  const canReset = actor?.isActive && (
    actor.role === "admin"
    || ["admin", "manage", "write"].includes(permissions["companionUsers"] ?? "")
    || ["admin", "manage", "write"].includes(permissions["customers"] ?? "")
  );
  if (!canReset) {
    res.status(403).json({ error: "Permission to reset Companion passwords is required." });
    return;
  }
  const targetId = Number(req.params["id"]);
  const requestedChannel = req.body?.channel;
  if (!Number.isInteger(targetId) || targetId <= 0 || !["email", "whatsapp"].includes(requestedChannel)) {
    res.status(400).json({ error: "A valid user id and delivery channel are required." });
    return;
  }
  const [target] = await db.select().from(ucUsersTable)
    .where(and(eq(ucUsersTable.id, targetId), isNull(ucUsersTable.deletedAt))).limit(1);
  if (!target) {
    await recordPasswordResetAudit({ actorType: "team", actorId: actor!.id, result: "rejected" });
    res.status(202).json({ ok: true });
    return;
  }
  const channel = target.authProvider === "password"
    ? preferredRecoveryChannel(target, requestedChannel)
    : null;
  if (!channel) {
    await recordPasswordResetAudit({ actorType: "team", actorId: actor!.id, targetUserId: String(target.id), result: "rejected" });
    res.status(202).json({ ok: true });
    return;
  }
  await issueCompanionReset(target, channel, { type: "team", id: actor!.id });
  // Do not reveal a destination/contact or raw credential to Back Office.
  res.status(202).json({ ok: true });
});

/**
 * POST /uc/admin/users/:id/temporary-password
 *
 * This is intentionally separate from the self-service reset-link endpoint:
 * the operator receives the generated plaintext exactly once, while only its
 * bcrypt hash and expiry are retained. Password/social/WooCommerce identities
 * cannot be converted into Companion password accounts through this route.
 */
router.post("/uc/admin/users/:id/temporary-password", async (req: Request, res: Response): Promise<void> => {
  const claims = verifyToken(req.headers["authorization"]);
  if (!claims || claims.type !== "team-session") {
    res.status(401).json({ code: "AUTHENTICATION_REQUIRED", error: "Authentication required." });
    return;
  }
  const [actor] = await db.select().from(teamUsersTable)
    .where(eq(teamUsersTable.id, String(claims.id))).limit(1);
  const permissions = (actor?.permissions ?? {}) as Record<string, string>;
  const canReset = actor?.isActive && (
    actor.role === "admin"
    || ["admin", "manage", "write"].includes(permissions["companionUsers"] ?? "")
    || ["admin", "manage", "write"].includes(permissions["customers"] ?? "")
  );
  if (!canReset) {
    res.status(403).json({
      code: "INSUFFICIENT_PERMISSION",
      error: "Permission to issue Companion temporary passwords is required.",
    });
    return;
  }

  const targetId = Number(req.params["id"]);
  const requestedChannel = req.body?.channel;
  if (!Number.isInteger(targetId) || targetId <= 0 || !["email", "whatsapp"].includes(requestedChannel)) {
    await recordPasswordResetAudit({ actorType: "team", actorId: actor!.id, result: "rejected" });
    res.status(400).json({ code: "TEMPORARY_PASSWORD_INPUT_INVALID", error: "A valid user id and delivery channel are required." });
    return;
  }
  const [target] = await db.select({
    id: ucUsersTable.id,
    email: ucUsersTable.email,
    phone: ucUsersTable.phone,
    firstName: ucUsersTable.firstName,
    emailVerified: ucUsersTable.emailVerified,
    phoneVerified: ucUsersTable.phoneVerified,
    authProvider: ucUsersTable.authProvider,
  }).from(ucUsersTable).where(and(
    eq(ucUsersTable.id, targetId),
    isNull(ucUsersTable.deletedAt),
  )).limit(1);
  const channel = target && preferredRecoveryChannel(target, requestedChannel);
  let eligibility: "account_ineligible" | "unavailable_unverified_destination" | "whatsapp_disconnected" | undefined;
  if (!target || target.authProvider !== "password") {
    eligibility = "account_ineligible";
  } else if (!channel) {
    eligibility = "unavailable_unverified_destination";
  } else if (channel === "whatsapp" && getWhatsAppStatus().state !== "connected") {
    eligibility = "whatsapp_disconnected";
  }
  if (eligibility) {
    await recordPasswordResetAudit({
      actorType: "team",
      actorId: actor!.id,
      targetUserId: target ? String(target.id) : undefined,
      channel: channel ?? undefined,
      result: "rejected",
    });
    res.status(422).json({
      code: eligibility.toUpperCase(),
      error: eligibility === "account_ineligible"
        ? "This account is not eligible for a temporary password."
        : eligibility === "unavailable_unverified_destination"
          ? "The selected destination is unavailable or unverified."
          : "WhatsApp is disconnected. Connect WhatsApp and try again.",
    });
    return;
  }

  if (!target || !channel) {
    res.status(422).json({ code: "ACCOUNT_INELIGIBLE", error: "This account is not eligible for a temporary password." });
    return;
  }
  const issued = await issueTemporaryPassword(target, channel, actor!.id);
  if (!issued || "failure" in issued) {
    const failure = !issued ? "delivery_provider_failure" : issued.failure;
    res.status(failure === "whatsapp_disconnected" ? 503 : 502).json({
      code: failure.toUpperCase(),
      error: failure === "whatsapp_disconnected"
        ? "WhatsApp is disconnected. Connect WhatsApp and try again."
        : "The delivery provider failed. No active temporary credential was retained; try again.",
    });
    return;
  }
  res.status(200).json({
    ok: true,
    temporaryPassword: issued.password,
    expiresAt: issued.expiresAt,
    delivery: { channel, delivered: true },
  });
});

/** GET /uc/auth/reset-password — serve a simple HTML form the email link points to */
router.get("/uc/auth/reset-password", async (req: Request, res: Response): Promise<void> => {
  const { token } = req.query;
  if (!token || typeof token !== "string") {
    res.status(400).send("<h2>Invalid reset link</h2><p>This link is missing a reset token. Please request a new one.</p>");
    return;
  }

  // Hash the incoming raw token before looking it up — only the hash is stored.
  const tokenHash = hashResetToken(token);
  const [resetToken] = await db.select().from(passwordResetTokensTable)
    .where(and(
      eq(passwordResetTokensTable.token, tokenHash),
      isNull(passwordResetTokensTable.usedAt),
      gt(passwordResetTokensTable.expiresAt, new Date()),
    ))
    .limit(1);

  if (!resetToken) {
    res.status(400).send(`
      <!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Reset link expired</title>
      <meta name="viewport" content="width=device-width,initial-scale=1">
      <style>body{font-family:system-ui,sans-serif;max-width:420px;margin:60px auto;padding:0 24px;color:#1a1a1a}
      h2{color:#EF4444}a{color:#005d8f}</style></head>
      <body><h2>Link expired or already used</h2>
      <p>This password-reset link is no longer valid. Links expire after 24 hours and can only be used once.</p>
      <p>Please open the Ultra-Clear app and request a new reset link.</p></body></html>
    `);
    return;
  }

  res.send(`
    <!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Reset your password — Ultra-Clear</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style>
      *{box-sizing:border-box}
      body{font-family:system-ui,sans-serif;background:#f5f5f5;min-height:100vh;display:flex;align-items:center;justify-content:center;margin:0;padding:24px}
      .card{background:#fff;border-radius:16px;padding:32px;max-width:420px;width:100%;box-shadow:0 2px 16px rgba(0,0,0,.08)}
      h1{font-size:22px;margin:0 0 8px;color:#005d8f}
      p{color:#555;font-size:14px;margin:0 0 20px}
      label{display:block;font-size:13px;font-weight:600;color:#333;margin-bottom:6px}
      input{width:100%;border:1.5px solid #ddd;border-radius:10px;padding:12px 14px;font-size:16px;outline:none;transition:border-color .15s}
      input:focus{border-color:#005d8f}
      .field{margin-bottom:16px}
      button{width:100%;background:#005d8f;color:#fff;border:none;border-radius:10px;padding:14px;font-size:16px;font-weight:700;cursor:pointer;margin-top:4px}
      button:hover{background:#004a75}
      .error{color:#EF4444;font-size:13px;margin-top:8px;display:none}
      .success{text-align:center}
      .success h1{color:#22C55E}
    </style></head>
    <body>
      <div class="card" id="formCard">
        <h1>Set a new password</h1>
        <p>Choose a strong password for your Ultra-Clear account. You'll use it to sign in on the app.</p>
        <form id="resetForm">
          <div class="field">
            <label for="pw">New password</label>
            <input type="password" id="pw" placeholder="Min. 6 characters" autocomplete="new-password">
          </div>
          <div class="field">
            <label for="pw2">Confirm password</label>
            <input type="password" id="pw2" placeholder="Repeat your password" autocomplete="new-password">
          </div>
          <p class="error" id="err"></p>
          <button type="submit" id="submitBtn">Save new password</button>
        </form>
      </div>
      <div class="card success" id="successCard" style="display:none">
        <h1>✓ Password updated</h1>
        <p style="text-align:center">Your password has been changed. Open the Ultra-Clear app and sign in with your new password.</p>
      </div>
      <script>
        const form = document.getElementById('resetForm');
        const errEl = document.getElementById('err');
        const btn = document.getElementById('submitBtn');
        form.addEventListener('submit', async e => {
          e.preventDefault();
          const pw = document.getElementById('pw').value;
          const pw2 = document.getElementById('pw2').value;
          errEl.style.display = 'none';
          if (pw.length < 6) { errEl.textContent = 'Password must be at least 6 characters.'; errEl.style.display='block'; return; }
          if (pw !== pw2) { errEl.textContent = 'Passwords do not match.'; errEl.style.display='block'; return; }
          btn.disabled = true; btn.textContent = 'Saving…';
          try {
            const r = await fetch(window.location.pathname, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ token: '${token}', newPassword: pw }),
            });
            const data = await r.json();
            if (r.ok && data.ok) {
              document.getElementById('formCard').style.display='none';
              document.getElementById('successCard').style.display='block';
            } else {
              errEl.textContent = data.error || 'Something went wrong. Please try again.';
              errEl.style.display = 'block';
              btn.disabled = false; btn.textContent = 'Save new password';
            }
          } catch { errEl.textContent = 'Network error. Please check your connection.'; errEl.style.display='block'; btn.disabled=false; btn.textContent='Save new password'; }
        });
      </script>
    </body></html>
  `);
});

/** POST /uc/auth/reset-password — atomically consume token and update UC user password.
 *
 * The token is marked used_at in the same transaction as the password change so
 * concurrent requests with the same link cannot both succeed (classic TOCTOU race).
 * The conditional UPDATE returns 0 rows if the token was already consumed or has
 * expired, making the entire operation idempotent and race-free.
 */
router.post("/uc/auth/reset-password", authLimiter, async (req: Request, res: Response): Promise<void> => {
  const { token, newPassword } = req.body ?? {};
  if (!token || typeof token !== "string" || !newPassword) {
    res.status(400).json({ error: "token and newPassword are required." });
    return;
  }
  if (typeof newPassword !== "string" || newPassword.length < 6) {
    res.status(400).json({ error: "Password must be at least 6 characters." });
    return;
  }

  // Reject arbitrary/expired tokens before spending bcrypt CPU. This is only a
  // precheck: the conditional update inside the transaction remains the atomic
  // source of truth, so a concurrent reset cannot win a TOCTOU race.
  const tokenHash = hashResetToken(token);
  const [validToken] = await db.select({
    id: passwordResetTokensTable.id,
    userId: passwordResetTokensTable.userId,
  })
    .from(passwordResetTokensTable)
    .where(and(
      eq(passwordResetTokensTable.token, tokenHash),
      isNull(passwordResetTokensTable.usedAt),
      gt(passwordResetTokensTable.expiresAt, new Date()),
    ))
    .limit(1);
  if (!validToken) {
    res.status(400).json({ error: "Invalid or expired reset link. Please request a new one." });
    return;
  }
  const lockedUserId = Number(validToken.userId);
  if (!Number.isInteger(lockedUserId) || lockedUserId <= 0) {
    res.status(400).json({ error: "Invalid or expired reset link. Please request a new one." });
    return;
  }

  // Hash after the inexpensive token precheck. bcrypt is CPU-bound; no DB
  // connection is held while hashing.
  const passwordHash = await bcryptjs.hash(newPassword, 10);

  const client = await pool.connect();
  try {
    // issueTemporaryPassword holds this same session-level advisory lock while
    // its provider delivery is in flight. Waiting here prevents a reset link
    // from replacing a just-issued temporary credential before delivery has
    // either succeeded (and invalidated the link) or failed (and restored the
    // prior credential).
    await client.query(
      "SELECT pg_advisory_lock(hashtext($1))",
      [`uc-temporary-password:${lockedUserId}`],
    );
    await client.query("BEGIN");

    // Atomically claim the token by hash. The conditional WHERE (used_at IS NULL
    // AND expires_at > now()) means exactly one concurrent request can succeed;
    // all others get 0 rows and are rejected before touching uc_users.
    const claimed = await client.query<{ user_id: string }>(
      `UPDATE password_reset_tokens
         SET used_at = now()
       WHERE token = $1
         AND used_at IS NULL
         AND expires_at > now()
       RETURNING user_id`,
      [tokenHash],
    );

    if ((claimed.rowCount ?? 0) === 0) {
      await client.query("ROLLBACK");
      res.status(400).json({ error: "Invalid or expired reset link. Please request a new one." });
      return;
    }

    const userId = Number(claimed.rows[0]!.user_id);
    if (isNaN(userId) || userId <= 0) {
      await client.query("ROLLBACK");
      res.status(500).json({ error: "Invalid reset token state." });
      return;
    }

    // Update password and bump credential_version in the same transaction so
    // a crash between these two statements never leaves a partially-reset state.
    const updated = await client.query(
      `UPDATE uc_users
          SET password_hash = $1,
              credential_version = credential_version + 1,
              must_change_password = false,
              temporary_password_expires_at = NULL
        WHERE id = $2 AND auth_provider = 'password' AND deleted_at IS NULL`,
      [passwordHash, userId],
    );
    if ((updated.rowCount ?? 0) !== 1) {
      await client.query("ROLLBACK");
      res.status(400).json({ error: "This account cannot use Companion password recovery." });
      return;
    }
    // A successful reset also invalidates any other still-active recovery link.
    await client.query(
      `UPDATE password_reset_tokens SET used_at = now()
       WHERE user_id = $1 AND used_at IS NULL`,
      [String(userId)],
    );

    await client.query("COMMIT");
    await recordPasswordResetAudit({ actorType: "self", targetUserId: String(userId), result: "completed" });
    logger.info({ event: "password_reset_completed", result: "completed" }, "Companion password reset completed");
    res.json({ ok: true });
  } catch (err) {
    await client.query("ROLLBACK").catch(() => {});
    throw err;
  } finally {
    await client.query(
      "SELECT pg_advisory_unlock(hashtext($1))",
      [`uc-temporary-password:${lockedUserId}`],
    ).catch(() => {});
    client.release();
  }
});

/**
 * Complete an operator-issued temporary-password session. The temporary
 * bearer is intentionally accepted only here; uc-deleted-guard rejects it
 * from every customer route until this transaction succeeds.
 */
async function completeTemporaryPasswordChange(req: Request, res: Response): Promise<void> {
  res.set("Cache-Control", "no-store");
  const claims = verifyToken(req.headers["authorization"]);
  const userId = Number(claims?.id);
  if (!claims || claims.mustChangePassword !== true || !Number.isInteger(userId) || userId <= 0) {
    res.status(401).json({ error: "A temporary Companion password session is required." });
    return;
  }
  const newPassword = req.body?.newPassword ?? req.body?.password;
  const currentPassword = req.body?.currentPassword;
  if (typeof newPassword !== "string" || newPassword.length < 8) {
    res.status(400).json({ error: "newPassword must be at least 8 characters." });
    return;
  }
  if (currentPassword !== undefined && typeof currentPassword !== "string") {
    res.status(400).json({ error: "currentPassword must be a string when supplied." });
    return;
  }

  const [account] = await db.select().from(ucUsersTable).where(and(
    eq(ucUsersTable.id, userId),
    isNull(ucUsersTable.deletedAt),
  )).limit(1);
  if (
    !account
    || account.authProvider !== "password"
    || !account.mustChangePassword
    || !account.temporaryPasswordExpiresAt
    || account.temporaryPasswordExpiresAt.getTime() <= Date.now()
  ) {
    res.status(401).json({ error: "Temporary password expired. Request a new one." });
    return;
  }
  if (typeof currentPassword === "string" && !(await bcryptjs.compare(currentPassword, account.passwordHash))) {
    res.status(401).json({ error: "Temporary password is incorrect." });
    return;
  }
  const passwordHash = await bcryptjs.hash(newPassword, 12);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const updated = await client.query<{
      id: number; email: string; phone: string; first_name: string;
      last_name: string; address: string; credential_version: number;
    }>(
      `UPDATE uc_users
          SET password_hash = $1,
              credential_version = credential_version + 1,
              must_change_password = false,
              temporary_password_expires_at = NULL
        WHERE id = $2
          AND deleted_at IS NULL
          AND auth_provider = 'password'
          AND must_change_password = true
          AND temporary_password_expires_at > now()
        RETURNING id,email,phone,first_name,last_name,address,credential_version`,
      [passwordHash, userId],
    );
    if ((updated.rowCount ?? 0) !== 1) {
      await client.query("ROLLBACK");
      res.status(401).json({ error: "Temporary password expired. Request a new one." });
      return;
    }
    await client.query("COMMIT");
    const saved = updated.rows[0]!;
    await recordPasswordResetAudit({
      actorType: "self",
      targetUserId: String(userId),
      result: "completed",
    });
    const user = {
      id: saved.id,
      email: publicCompanionEmail(saved.email),
      phone: saved.phone,
      firstName: saved.first_name,
      lastName: saved.last_name,
      address: saved.address ?? "",
      credentialVersion: saved.credential_version,
      mustChangePassword: false,
    };
    res.json({ ok: true, token: issueToken(user), user });
  } catch (err) {
    await client.query("ROLLBACK").catch(() => undefined);
    throw err;
  } finally {
    client.release();
  }
}

router.post("/uc/auth/change-password", authLimiter, completeTemporaryPasswordChange);
router.post("/uc/auth/complete-password-change", authLimiter, completeTemporaryPasswordChange);

// ─── Customer ─────────────────────────────────────────────────────────────────
router.get("/uc/customer/profile", async (req: Request, res: Response): Promise<void> => {
  const claims = verifyToken(req.headers["authorization"]);
  if (!claims) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  // Try to look up the real user record from the DB
  try {
    const numericId = Number(claims.id);
    if (!isNaN(numericId) && numericId > 0 && numericId < 1_000_000_000) {
      // Looks like a real serial DB id (not a timestamp)
      const dbUser = await db.query.ucUsersTable.findFirst({ where: eq(ucUsersTable.id, numericId) });
      if (dbUser) {
        // Reject requests from deleted accounts — their JWT is still cryptographically
        // valid but the account has exercised its right to erasure.
        if (dbUser.deletedAt) {
          res.status(401).json({ error: "This account has been deleted" });
          return;
        }
        res.json({
          id: dbUser.id,
          email: publicCompanionEmail(dbUser.email),
          phone: dbUser.phone,
          firstName: dbUser.firstName,
          lastName: dbUser.lastName,
          address: dbUser.address ?? "",
          isAdmin: dbUser.isAdmin || adminEmailList().includes(dbUser.email.toLowerCase()),
          emailVerified: dbUser.emailVerified,
          phoneVerified: dbUser.phoneVerified,
          billing:  { firstName: dbUser.firstName, lastName: dbUser.lastName, city: "Nairobi", country: "KE", phone: dbUser.phone },
          shipping: { firstName: dbUser.firstName, lastName: dbUser.lastName, city: "Nairobi", country: "KE", phone: dbUser.phone },
        });
        return;
      }
    }
  } catch { /* fall through */ }
  // Fallback: return whatever the JWT carries (for mock/legacy logins)
  res.json({
    id:        claims.id,
    email:     claims.email,
    firstName: claims.firstName ?? "",
    lastName:  claims.lastName  ?? "",
    phone:     "",
    // Fallback identities are not DB-anchored, so they can never be admin
    // (the email in the JWT is client-chosen in dev mode).
    isAdmin:   false,
    billing:   { firstName: claims.firstName ?? "", lastName: claims.lastName ?? "", city: "Nairobi", country: "KE", phone: "" },
    shipping:  { firstName: claims.firstName ?? "", lastName: claims.lastName ?? "", city: "Nairobi", country: "KE", phone: "" },
  });
});

router.patch("/uc/customer/profile", async (req: Request, res: Response): Promise<void> => {
  const claims = verifyToken(req.headers["authorization"]);
  if (!claims) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const { firstName, lastName, phone, address } = req.body as {
    firstName?: string;
    lastName?:  string;
    phone?:     string;
    address?:   string;
  };

  if (firstName !== undefined && !firstName.trim()) {
    res.status(400).json({ error: "First name cannot be empty" });
    return;
  }
  if (phone !== undefined && phone !== "") {
    if (!normalizePhone(phone)) {
      res.status(400).json({ error: phoneValidationMessage() });
      return;
    }
  }
  if (address !== undefined && address.length > 500) {
    res.status(400).json({ error: "Address must be 500 characters or fewer" });
    return;
  }

  const numericId = Number(claims.id);
  if (isNaN(numericId) || numericId <= 0 || numericId >= 1_000_000_000) {
    res.status(403).json({ error: "Profile update is only available for registered accounts" });
    return;
  }

  if (await guardDeletedAccount(numericId, res)) return;

  const updates: Record<string, string | boolean> = {};
  if (firstName !== undefined) updates["firstName"] = firstName.trim();
  if (lastName  !== undefined) updates["lastName"]  = lastName.trim();
  const normalizedPhone = phone === undefined || phone === "" ? phone : normalizePhone(phone);
  if (phone     !== undefined) {
    updates["phone"] = normalizedPhone ?? "";
    // Even replacing with the same value requires re-verification; no profile
    // edit may accidentally carry verification proof to a different number.
    updates["phoneVerified"] = false;
  }
  if (address   !== undefined) updates["address"]   = address.trim();

  if (Object.keys(updates).length === 0) {
    res.status(400).json({ error: "No fields to update" });
    return;
  }

  try {
    const updated = await db.transaction(async (tx) => {
      if (normalizedPhone) {
        await tx.execute(sql`select pg_advisory_xact_lock(hashtext(${"uc-phone:" + normalizedPhone}))`);
        const [owner] = await tx.select({ id: ucUsersTable.id })
          .from(ucUsersTable)
          .where(and(
            eq(ucUsersTable.phone, normalizedPhone),
            isNull(ucUsersTable.deletedAt),
            ne(ucUsersTable.id, numericId),
          ))
          .limit(1);
        if (owner) return null;
      }
      const [row] = await tx
        .update(ucUsersTable)
        .set(updates)
        .where(eq(ucUsersTable.id, numericId))
        .returning();
      return row ?? undefined;
    });

    if (!updated) {
      const [user] = await db.select({ id: ucUsersTable.id }).from(ucUsersTable)
        .where(eq(ucUsersTable.id, numericId)).limit(1);
      res.status(user ? 409 : 404).json({
        error: user
          ? "An active account already uses this phone number. Use a different number."
          : "User not found",
      });
      return;
    }

    res.json({
      id:        updated.id,
      email:     updated.email,
      phone:     updated.phone,
      firstName: updated.firstName,
      lastName:  updated.lastName,
      address:   updated.address ?? "",
      emailVerified: updated.emailVerified,
      phoneVerified: updated.phoneVerified,
    });
  } catch (err) {
    logger.error({ err, userId: numericId }, "[profile patch] error");
    res.status(500).json({ error: "Failed to update profile. Please try again." });
  }
});

// ─── Data export (GDPR Art. 20 / PDPA right to data portability) ─────────────
// Returns a machine-readable JSON copy of every category of personal data the
// system holds for the authenticated customer: profile, orders (with line
// items), maintenance tickets, water tests, and product enquiries. Served as a
// downloadable attachment so the Companion app can save/share the file.
router.get("/uc/customer/data-export", async (req: Request, res: Response): Promise<void> => {
  const claims = verifyToken(req.headers["authorization"]);
  if (!claims) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const numericId = Number(claims.id);
  if (isNaN(numericId) || numericId <= 0 || numericId >= 1_000_000_000) {
    res.status(403).json({ error: "Data export is only available for registered accounts" });
    return;
  }
  if (await guardDeletedAccount(numericId, res)) return;

  try {
    const user = await db.query.ucUsersTable.findFirst({ where: eq(ucUsersTable.id, numericId) });
    if (!user) {
      res.status(404).json({ error: "Account not found" });
      return;
    }

    const userId = String(numericId);

    // Orders: WooCommerce is the authoritative order system when credentials
    // are configured — the DB tables only back the dev/offline path. Fetch the
    // customer's orders from Woo, scoped strictly to their account email.
    let wooOrders: Record<string, unknown>[] | null = null;
    if (hasWCCredentials()) {
      // Paginate through ALL matching pages — a data-portability export must
      // be complete, so we keep fetching until Woo returns a short page.
      const emailLc = user.email.toLowerCase();
      const PER_PAGE = 100;
      const MAX_PAGES = 200; // hard safety cap (20k orders)
      const collected: Record<string, unknown>[] = [];
      let complete = false;
      for (let page = 1; page <= MAX_PAGES; page++) {
        const fetched = await wcFetchArray("/orders", {
          search:    user.email,
          per_page:  String(PER_PAGE),
          page:      String(page),
          orderby:   "date",
          order:     "desc",
        });
        if (fetched === null) {
          // Explicit failure: don't silently ship an export missing the
          // customer's authoritative order history.
          res.status(502).json({ error: "Order system temporarily unavailable — please try the export again shortly." });
          return;
        }
        collected.push(...fetched.filter(o => {
          const billing = o["billing"] as Record<string, unknown> | undefined;
          return String(billing?.["email"] ?? "").toLowerCase() === emailLc;
        }));
        if (fetched.length < PER_PAGE) { complete = true; break; } // last page reached
      }
      if (!complete) {
        // Never silently ship a truncated order history — a portability
        // export must be complete or fail explicitly.
        res.status(502).json({ error: "Order history too large to export in one pass — please contact support." });
        return;
      }
      wooOrders = collected;
    }

    const [orders, tickets, waterTests, enquiries, reviews, notifPrefRows, pushTokenRows] = await Promise.all([
      db.select().from(ucOrdersTable)
        .where(eq(ucOrdersTable.userId, userId))
        .orderBy(desc(ucOrdersTable.dateCreated)),
      db.select().from(ucTicketsTable)
        .where(eq(ucTicketsTable.userId, userId))
        .orderBy(desc(ucTicketsTable.createdAt)),
      db.select().from(ucWaterTestsTable)
        .where(eq(ucWaterTestsTable.userId, userId))
        .orderBy(desc(ucWaterTestsTable.createdAt)),
      db.select().from(ucEnquiriesTable)
        .where(eq(ucEnquiriesTable.userId, userId))
        .orderBy(desc(ucEnquiriesTable.createdAt)),
      db.select().from(ucReviewsTable)
        .where(eq(ucReviewsTable.userId, userId))
        .orderBy(desc(ucReviewsTable.createdAt)),
      db.select().from(ucNotifPrefsTable)
        .where(eq(ucNotifPrefsTable.userId, userId)),
      db.select().from(ucPushTokensTable)
        .where(eq(ucPushTokensTable.userId, userId)),
    ]);

    const orderIds = orders.map(o => o.id);
    const items = orderIds.length > 0
      ? await db.select().from(ucOrderItemsTable).where(inArray(ucOrderItemsTable.orderId, orderIds))
      : [];
    const itemsByOrder = items.reduce<Record<number, typeof items>>((acc, item) => {
      (acc[item.orderId] ??= []).push(item);
      return acc;
    }, {});

    const exportPayload = {
      exportedAt: new Date().toISOString(),
      format:     "Ultra Clear customer data export v2 (GDPR Art. 20 / PDPA data portability)",
      profile: {
        id:        user.id,
        email:     user.email,
        firstName: user.firstName,
        lastName:  user.lastName,
        phone:     user.phone,
        address:   user.address ?? "",
        createdAt: user.createdAt,
      },
      orders: wooOrders !== null
        ? wooOrders.map(normalizeOrder)
        : orders.map(o => ({
            id:              o.id,
            status:          o.status,
            dateCreated:     o.dateCreated,
            total:           o.total,
            currency:        o.currency,
            paymentMethod:   o.paymentMethod,
            shippingAddress: o.shippingAddress ?? {},
            promoCode:       o.promoCode ?? "",
            lineItems:       (itemsByOrder[o.id] ?? []).map(i => ({
              productId: i.productId,
              name:      i.name,
              quantity:  i.quantity,
              total:     i.total,
            })),
          })),
      tickets: tickets.map(t => ({
        id:                   t.id,
        productModel:         t.productModel,
        issueDescription:     t.issueDescription,
        preferredContactTime: t.preferredContactTime,
        photos:               t.photos ?? [],
        videos:               t.videos ?? [],
        status:               t.status,
        createdAt:            t.createdAt,
      })),
      waterTests: waterTests.map(w => ({
        id:          w.id,
        name:        w.name,
        address:     w.address,
        phone:       w.phone,
        waterSource: w.waterSource,
        concerns:    w.concerns,
        photos:      w.photos ?? [],
        videos:      w.videos ?? [],
        status:      w.status,
        createdAt:   w.createdAt,
      })),
      reviews: reviews.map(r => ({
        id:         r.id,
        productId:  r.productId,
        authorName: r.authorName,
        rating:     r.rating,
        title:      r.title,
        body:       r.body,
        media:      r.media ?? [],
        createdAt:  r.createdAt,
        editedAt:   r.editedAt,
        automatedTextAssessment: {
          status: r.analysis.status,
          category: r.analysis.category ?? null,
          explanation: r.analysis.explanation ?? null,
          themes: r.analysis.themes ?? [],
          analyzedAt: r.analysis.analyzedAt ?? null,
          version: r.analysis.version,
        },
      })),
      notificationPreferences: notifPrefRows.map(p => ({
        optOutOrderUpdates: p.optOutOrders,
        updatedAt:          p.updatedAt,
      })),
      // Push registration metadata. The raw Expo push token is the user's own
      // device credential — included since this is their personal data export.
      pushRegistrations: pushTokenRows.map(t => ({
        pushToken:          t.pushToken,
        optOutOrderUpdates: t.optOutOrders,
        updatedAt:          t.updatedAt,
      })),
      // Referral programme data: the customer's own code and aggregate stats.
      // Referred users are reported as a count only — their emails are other
      // people's personal data and must not appear in this export.
      referrals: await getReferralExportData(user.email),
      enquiries: enquiries.map(e => ({
        id:          e.id,
        productId:   e.productId,
        productName: e.productName,
        name:        e.name,
        email:       e.email,
        phone:       e.phone,
        message:     e.message,
        createdAt:   e.createdAt,
      })),
    };

    const dateStamp = new Date().toISOString().slice(0, 10);
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="ultra-clear-data-export-${dateStamp}.json"`);
    res.send(JSON.stringify(exportPayload, null, 2));
  } catch (err) {
    logger.error({ err, userId: numericId }, "Failed to generate customer data export");
    res.status(500).json({ error: "Failed to generate your data export. Please try again." });
  }
});

// ─── Delete account (GDPR / PDPA right to erasure) ───────────────────────────
// Anonymises all PII in place rather than hard-deleting rows so that order
// history and ticket records remain intact for the team (foreign-key integrity
// and business audit trail). Linked personal fields are replaced with the
// "[deleted customer]" sentinel so the team can see a record existed without
// any personal data being visible.
//
// Full erasure inventory:
//   uc_users        — email, passwordHash, firstName, lastName, phone
//   uc_orders       — shippingAddress (customer's delivery/contact info)
//   uc_enquiries    — name, email, phone, message
//   uc_tickets      — issueDescription, photos[], videos[]
//   uc_water_tests  — name, phone, address, concerns, photos[], videos[]
//   uc_push_tokens  — hard-deleted (token itself is PII)
//   Object storage  — all media blobs attached to tickets and water tests
//   JSONL backups   — tickets.jsonl / water-tests.jsonl entries scrubbed by ID
//   In-memory stores — fallback arrays cleared of this user's entries

/** Check whether the uc_users row for numericId has a non-null deleted_at.
 *  Sends an appropriate HTTP error response and returns true when the route
 *  should abort immediately.  Fails CLOSED: when the DB is unavailable it
 *  returns 503 rather than passing the request through, so an erased identity
 *  can never be reactivated by a transient outage. */
async function guardDeletedAccount(numericId: number, res: Response): Promise<boolean> {
  // Non-DB-anchored identities (anonymous, legacy timestamp IDs) are not in
  // the deleted-account table — skip the check entirely.
  if (isNaN(numericId) || numericId <= 0 || numericId >= 1_000_000_000) return false;
  try {
    const result = await pool.query<{ deleted_at: string | null }>(
      "SELECT deleted_at FROM uc_users WHERE id = $1 LIMIT 1",
      [numericId]
    );
    if (result.rows[0]?.deleted_at) {
      res.status(401).json({ error: "This account has been deleted" });
      return true;
    }
    return false;
  } catch {
    // DB unavailable — fail closed to prevent erased identities from slipping through.
    res.status(503).json({ error: "Service temporarily unavailable. Please try again." });
    return true;
  }
}

/** Best-effort delete a single media blob from object storage. Silently ignored if
 *  the URL doesn't point to an internal upload or if the file no longer exists. */
async function deleteStorageBlob(url: string): Promise<void> {
  // Only internal uploads have the /api/storage/objects/ prefix
  if (!url.startsWith(UPLOADED_MEDIA_PREFIX)) return;
  const objectPath = url.slice("/api/storage".length); // "/objects/uploads/<uuid>"
  if (!objectPath.startsWith("/objects/uploads/")) return;
  try {
    const file = await objectStorage.getObjectEntityFile(objectPath);
    await file.delete();
  } catch {
    // ObjectNotFoundError or any other failure — already gone or inaccessible, skip
  }
}

/** Overwrite entries matching `predicate` in a JSONL file with the result of
 *  `scrub(line)`. Writes atomically via a temp file; silently skips on any I/O error. */
async function scrubJsonlFile(
  filename: string,
  predicate: (rec: Record<string, unknown>) => boolean,
  scrub: (rec: Record<string, unknown>) => Record<string, unknown>,
): Promise<void> {
  const filePath = join(UC_DATA_DIR, filename);
  const tmpPath  = `${filePath}.tmp`;
  try {
    const raw    = await readFile(filePath, "utf8").catch(() => "");
    const lines  = raw.split("\n");
    const output = lines.map(line => {
      if (!line.trim()) return line;
      try {
        const rec = JSON.parse(line) as Record<string, unknown>;
        return predicate(rec) ? JSON.stringify(scrub(rec)) : line;
      } catch {
        return line; // malformed line — leave unchanged
      }
    });
    await writeFile(tmpPath, output.join("\n"), "utf8");
    await rename(tmpPath, filePath);
  } catch (err) {
    logger.warn({ err, filename }, "JSONL scrub failed — continuing deletion");
  }
}

router.delete("/uc/customer", async (req: Request, res: Response): Promise<void> => {
  const claims = verifyToken(req.headers["authorization"]);
  if (!claims) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const numericId = Number(claims.id);
  if (isNaN(numericId) || numericId <= 0 || numericId >= 1_000_000_000) {
    res.status(403).json({ error: "Account deletion is only available for registered accounts" });
    return;
  }

  try {
    // 1. Verify the user exists
    const existing = await db.query.ucUsersTable.findFirst({
      where: eq(ucUsersTable.id, numericId),
    });
    if (!existing) {
      res.status(404).json({ error: "Account not found" });
      return;
    }

    // Idempotency: if the account was already anonymised (deletedAt set), a
    // duplicate deletion request (network retry / race before logout) succeeds
    // with 200 instead of re-running the redaction pipeline or returning 404.
    if (existing.deletedAt) {
      res.json({ ok: true, alreadyDeleted: true, message: "Account already deleted" });
      return;
    }

    // Guard: admin accounts cannot be self-deleted through the customer route.
    // Checks both the DB flag AND the UC_ADMIN_EMAILS env list — identical to
    // how isAdminRequest() works — so environment-designated admins are also
    // protected regardless of whether their DB is_admin flag is set.
    if (existing.isAdmin || adminEmailList().includes(existing.email.toLowerCase())) {
      res.status(403).json({ error: "Admin accounts cannot be deleted through the customer deletion flow. Contact the team to remove your account." });
      return;
    }

    const DELETED = "[deleted customer]";
    const userId  = String(numericId);
    // Capture pre-deletion email for enquiry-fallback scrubbing (those records
    // have no userId, so we must match by the email they were submitted with).
    const preDeletionEmail = existing.email;

    // 2. Collect media URLs from tickets, water-tests, and reviews BEFORE
    //    redacting, so we can delete blobs from object storage.
    const [ticketRows, waterTestRows, reviewRows] = await Promise.all([
      db.select({ id: ucTicketsTable.id, photos: ucTicketsTable.photos, videos: ucTicketsTable.videos })
        .from(ucTicketsTable).where(eq(ucTicketsTable.userId, userId)),
      db.select({ id: ucWaterTestsTable.id, photos: ucWaterTestsTable.photos, videos: ucWaterTestsTable.videos })
        .from(ucWaterTestsTable).where(eq(ucWaterTestsTable.userId, userId)),
      db.select({ id: ucReviewsTable.id, media: ucReviewsTable.media })
        .from(ucReviewsTable).where(eq(ucReviewsTable.userId, userId)),
    ]);

    const ticketIds    = ticketRows.map(t => t.id);
    const waterTestIds = waterTestRows.map(w => w.id);

    // Collect linked order IDs for notification-log scrubbing
    const orderRows = await db
      .select({ id: ucOrdersTable.id })
      .from(ucOrdersTable)
      .where(eq(ucOrdersTable.userId, userId));
    const orderIds = orderRows.map(o => o.id);

    const allMediaUrls: string[] = [
      ...ticketRows.flatMap(t => [...(t.photos ?? []), ...(t.videos ?? [])]),
      ...waterTestRows.flatMap(w => [...(w.photos ?? []), ...(w.videos ?? [])]),
      ...reviewRows.flatMap(r => (r.media ?? []).map((m: ReviewMediaItem) => m.url)),
    ];

    // 3. Delete object-storage blobs (best-effort, in parallel)
    await Promise.allSettled(allMediaUrls.map(deleteStorageBlob));

    // 4. Anonymise the user row — keep id, createdAt for audit trail.
    //    isAdmin is cleared so any still-valid bearer tokens lose DB-level privilege.
    //    deletedAt is set so all DB-anchored customer routes reject further requests
    //    with this token (token revocation without a token blacklist).
    const erasedPassword = await bcryptjs.hash(Math.random().toString(36), 10);
    await db.transaction(async (tx) => {
      await tx.update(ucUsersTable).set({
        email: `deleted-${numericId}@deleted.invalid`, passwordHash: erasedPassword,
        firstName: DELETED, lastName: "", phone: "", address: "",
        isAdmin: false, deletedAt: new Date(),
      }).where(eq(ucUsersTable.id, numericId));
      // Erasure and review invalidation commit atomically. A later failure in
      // another deletion step cannot leave retained AI-derived personal text
      // behind an already-deleted identity. The trigger clears all job data.
      await tx.update(ucReviewsTable)
        .set({ authorName: DELETED, title: "", body: DELETED, media: [] })
        .where(eq(ucReviewsTable.userId, userId));
    });

    // 5. Redact personal fields on linked orders (shipping address carries name/phone)
    await db
      .update(ucOrdersTable)
      .set({ shippingAddress: { name: DELETED, address: "", city: "", country: "" } })
      .where(eq(ucOrdersTable.userId, userId));

    // 6. Redact ALL personal fields on enquiries (including free-text message)
    await db
      .update(ucEnquiriesTable)
      .set({ name: DELETED, email: DELETED, phone: "", message: DELETED })
      .where(eq(ucEnquiriesTable.userId, userId));

    // 7. Redact ALL personal fields on maintenance tickets (free text + media refs)
    await db
      .update(ucTicketsTable)
      .set({ issueDescription: DELETED, photos: [], videos: [] })
      .where(eq(ucTicketsTable.userId, userId));

    // 8. Redact ALL personal fields on water tests (free text + media refs)
    await db
      .update(ucWaterTestsTable)
      .set({ name: DELETED, phone: "", address: "", concerns: "", photos: [], videos: [] })
      .where(eq(ucWaterTestsTable.userId, userId));

    // 9. Public review content and derived analysis were redacted atomically
    //    with the account in step 4; do not invalidate their revision twice.

    // 10. Redact notification-log rows whose recipient/body carry PII.
    //     Redact recipient (email/phone) and messageBody for every log entry
    //     linked to this user's orders, tickets, or water-test IDs.
    const notifConditions = [
      ...(orderIds.length > 0    ? [inArray(ucNotificationLogTable.orderId,  orderIds)]   : []),
      ...(ticketIds.length > 0   ? [inArray(ucNotificationLogTable.ticketId,  ticketIds)]  : []),
      ...(waterTestIds.length > 0 ? [inArray(ucNotificationLogTable.testId,   waterTestIds)] : []),
    ];
    if (notifConditions.length > 0) {
      await db
        .update(ucNotificationLogTable)
        .set({ recipient: DELETED, messageBody: "" })
        .where(or(...notifConditions));
    }
    // Also redact by recipient = customer email/phone (covers SMS logs and any
    // direct sendViaResend call where the customer's contact info IS the recipient).
    const recipientConditions = [
      ...(preDeletionEmail ? [eq(ucNotificationLogTable.recipient, preDeletionEmail)] : []),
      ...(existing.phone   ? [eq(ucNotificationLogTable.recipient, existing.phone)]  : []),
    ];
    if (recipientConditions.length > 0) {
      await db
        .update(ucNotificationLogTable)
        .set({ recipient: DELETED, messageBody: "" })
        .where(or(...recipientConditions));
    }
    // Enquiry/return-request emails go to the team mailbox (info@ucfilters.com /
    // support@ucfilters.co.ke), so the recipient column is NOT the customer's
    // address.  The customer's name, email, phone, and message appear in
    // messageBody (both Resend and SendGrid/SMTP fallback paths log the full
    // plain-text body).  Use a content search to find and scrub those rows.
    if (preDeletionEmail) {
      await pool.query(
        "UPDATE uc_notification_log SET recipient = $1, message_body = '' WHERE message_body LIKE $2",
        [DELETED, `%${preDeletionEmail}%`]
      );
    }
    if (existing.phone) {
      await pool.query(
        "UPDATE uc_notification_log SET recipient = $1, message_body = '' WHERE message_body LIKE $2",
        [DELETED, `%${existing.phone}%`]
      );
    }

    // 11. Redact uc_return_requests (raw SQL — table predates Drizzle schema)
    await pool.query(
      "UPDATE uc_return_requests SET details = $1 WHERE user_id = $2",
      [DELETED, numericId]
    );

    // 12. Redact M-Pesa STK initiations — phone is the only PII stored.
    //     The record is retained for payment audit; only the phone is erased.
    if (existing.phone) {
      await db
        .update(mpesaStkInitiationsTable)
        .set({ phone: "" })
        .where(eq(mpesaStkInitiationsTable.phone, existing.phone));
    }

    // 13. Hard-delete push tokens (token string is PII) and notification prefs.
    //     uc_notif_prefs contains the stable user ID; deleting the row removes
    //     the linkage (no personal data beyond the ID itself).
    await db
      .delete(ucPushTokensTable)
      .where(eq(ucPushTokensTable.userId, userId));
    await db
      .delete(ucNotifPrefsTable)
      .where(eq(ucNotifPrefsTable.userId, userId));

    // 13. Scrub JSONL backups.
    //     tickets.jsonl  — matched by userId (always written alongside userId)
    //     water-tests.jsonl — matched by water-test ID (from DB) OR by userId
    //       for entries written after this fix, which now include a userId field.
    await Promise.allSettled([
      scrubJsonlFile("tickets.jsonl",
        rec => rec["userId"] === userId,
        rec => ({ ...rec, userId: "", issueDescription: DELETED, photos: [], videos: [] }),
      ),
      scrubJsonlFile("water-tests.jsonl",
        rec => waterTestIds.includes(String(rec["id"])) || rec["userId"] === userId,
        rec => ({ ...rec, userId: "", name: DELETED, phone: "", email: null, address: "", concerns: "", photos: [], videos: [] }),
      ),
    ]);

    // 14. Scrub in-memory fallback stores (best-effort mutation in place)
    for (const o of orderStoreFallback) {
      const r = o as Record<string, unknown>;
      if (r["userId"] === userId) {
        r["shippingAddress"] = { name: DELETED, address: "", city: "", country: "" };
      }
    }
    for (const t of ticketStoreFallback) {
      const r = t as Record<string, unknown>;
      if (r["userId"] === userId) {
        r["issueDescription"] = DELETED;
        r["photos"] = [];
        r["videos"] = [];
      }
    }
    for (const w of waterTestStoreFallback) {
      const r = w as Record<string, unknown>;
      if (r["userId"] === userId || waterTestIds.includes(String(r["id"]))) {
        r["name"]     = DELETED;
        r["phone"]    = "";
        r["address"]  = "";
        r["concerns"] = "";
        r["photos"]   = [];
        r["videos"]   = [];
      }
    }
    // Enquiry fallback: no userId stored, match by the pre-deletion email address
    for (const e of enquiryStoreFallback) {
      const r = e as Record<string, unknown>;
      if (r["email"] === preDeletionEmail) {
        r["name"]    = DELETED;
        r["email"]   = DELETED;
        r["phone"]   = "";
        r["message"] = DELETED;
      }
    }

    logger.info({ userId: numericId }, "Customer account anonymised on deletion request");

    // 15. Notify the team — best-effort, never blocks the deletion response.
    //     No PII is included: only the numeric user ID and the UTC timestamp.
    //     Recipient is configurable via TEAM_ALERT_EMAIL (e.g. a dedicated
    //     privacy@ mailbox); falls back to the team inbox when unset.
    const deletedAt = new Date().toUTCString();
    const deletionAlertTo = await accountDeletionAlertRecipient();
    void notifyTeamAccountDeletion(numericId, deletedAt, deletionAlertTo);

    res.json({ ok: true });
  } catch (err) {
    logger.error({ err, userId: numericId }, "Failed to delete customer account");
    res.status(500).json({ error: "Failed to delete account. Please try again or contact support." });
  }
});

// ─── Payment verification helpers (server-side; called before order creation) ─
async function verifyPaymentOnServer(
  method: string,
  reference: string
): Promise<{ ok: boolean; reason?: string; retryable?: boolean }> {
  // COD requires no pre-payment
  if (method === "cod") return { ok: true };

  if (!reference) return { ok: false, reason: "No payment reference provided" };

  // ── M-Pesa ──
  if (method === "mpesa") {
    const shortcode = process.env["MPESA_SHORTCODE"];
    const passkey = process.env["MPESA_PASSKEY"];
    const key = process.env["MPESA_CONSUMER_KEY"];
    const secret = process.env["MPESA_CONSUMER_SECRET"];
    if (!key || !secret || !shortcode || !passkey) {
      // Mock mode: accept any reference
      return { ok: true };
    }
    try {
      const creds = Buffer.from(`${key}:${secret}`).toString("base64");
      const env = process.env["MPESA_ENV"] === "production" ? "api" : "sandbox";
      const tokenRes = await fetch(
        `https://${env}.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials`,
        { headers: { Authorization: `Basic ${creds}` } }
      );
      const tokenData = (await tokenRes.json()) as { access_token?: string };
      const token = tokenData.access_token;
      if (!token) return { ok: false, reason: "Failed to get M-Pesa token" };
      const timestamp = new Date().toISOString().replace(/[^0-9]/g, "").slice(0, 14);
      const password = Buffer.from(`${shortcode}${passkey}${timestamp}`).toString("base64");
      const qRes = await fetch(`https://${env}.safaricom.co.ke/mpesa/stkpushquery/v1/query`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ BusinessShortCode: shortcode, Password: password, Timestamp: timestamp, CheckoutRequestID: reference }),
      });
      const qData = (await qRes.json()) as Record<string, string>;
      const ok = qData["ResultCode"] === "0";
      return ok ? { ok: true } : { ok: false, reason: qData["ResultDesc"] ?? "M-Pesa not confirmed" };
    } catch {
      return { ok: false, reason: "M-Pesa verification request failed" };
    }
  }

  // ── Stripe ──
  if (method === "stripe") {
    const stripeKey = process.env["STRIPE_SECRET_KEY"];
    if (!stripeKey) {
      // Mock mode: accept any session ID
      return { ok: true };
    }
    try {
      const StripeSDK = await import("stripe");
      const stripe = new StripeSDK.default(stripeKey);
      const session = await stripe.checkout.sessions.retrieve(reference);
      const ok = session.payment_status === "paid";
      return ok ? { ok: true } : { ok: false, reason: `Stripe session status: ${session.payment_status}` };
    } catch (e: unknown) {
      return { ok: false, reason: (e as Error).message };
    }
  }

  // ── Paystack ──
  if (method === "paystack") {
    const secretKey = process.env["PAYSTACK_SECRET_KEY"];
    if (!secretKey) {
      // Mock mode: accept any reference
      return { ok: true };
    }
    try {
      const vRes = await fetch(
        `https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,
        { headers: { Authorization: `Bearer ${secretKey}` } }
      );
      // Treat upstream 5xx / 429 as a transient outage — Paystack blips commonly
      // manifest as a non-2xx HTTP response rather than a thrown exception.
      if (!vRes.ok) {
        const isTransient = vRes.status >= 500 || vRes.status === 429;
        return {
          ok: false,
          reason: "Paystack verification request failed",
          ...(isTransient ? { retryable: true } : {}),
        };
      }
      const vData = (await vRes.json()) as { status: boolean; data?: { status: string } };
      const ok = vData.status && vData.data?.status === "success";
      return ok ? { ok: true } : { ok: false, reason: `Paystack status: ${vData.data?.status ?? "unknown"}` };
    } catch {
      // Network or timeout — transient; caller should offer a retry path.
      return { ok: false, reason: "Paystack verification request failed", retryable: true };
    }
  }

  return { ok: false, reason: `Unknown payment method: ${method}` };
}

// ─── Orders ───────────────────────────────────────────────────────────────────
router.get("/uc/orders", async (req: Request, res: Response): Promise<void> => {
  const claims = verifyToken(req.headers["authorization"]);
  const userId = userIdFromBearer(req.headers["authorization"]);
  if (!claims || !Number.isInteger(Number(claims.id)) || Number(claims.id) <= 0) {
    // Preserve the endpoint's non-enumerating contract: an anonymous caller
    // receives no account data rather than an authentication oracle.
    res.json([]);
    return;
  }
  try {
    if (hasWCCredentials()) {
      // Woo is store-wide — orders MUST be scoped to the authenticated user's
      // email. Woo's `search` narrows the fetch; the strict billing-email
      // filter below is the authorization boundary (search is fuzzy).
      const emailLc = String(claims?.email ?? "").trim().toLowerCase();
      if (!emailLc) {
        // No verified identity — never expose store-wide orders.
        res.json([]);
        return;
      }
      // Woo's search endpoint is fuzzy and a single page silently hid older
      // purchases. Fetch every bounded page, then apply the exact account
      // boundary locally before returning it.
      const PER_PAGE = 100;
      const MAX_PAGES = 200; // 20,000 orders is a deliberate safety ceiling
      const orders: Record<string, unknown>[] = [];
      let complete = false;
      for (let page = 1; page <= MAX_PAGES; page++) {
        const fetched = await wcFetchArray("/orders", {
          search: emailLc, per_page: String(PER_PAGE), page: String(page), orderby: "date", order: "desc",
        });
        if (!fetched) break;
        orders.push(...fetched);
        if (fetched.length < PER_PAGE) { complete = true; break; }
      }
      if (complete) {
        // Staff-confirmed guest COD orders are authorized by the durable
        // assignment, not by fuzzy Woo billing-email search.
        const assignedOrders = (await pool.query<{ wc_order_id: number | null; id: number }>(
          `SELECT DISTINCT o.id,o.wc_order_id FROM uc_orders o
           JOIN uc_customer_assignments a ON a.order_id=o.id
           WHERE a.linked_account_id=$1 AND a.status='linked' AND o.user_id=$2`,
          [Number(claims.id), userId])).rows;
        const assignedWooIds = new Set(assignedOrders.flatMap(o => o.wc_order_id ? [o.wc_order_id] : []));
        const missing = [...assignedWooIds].filter(id => !orders.some(o => Number(o["id"]) === id));
        for (let offset = 0; offset < missing.length; offset += 100) {
          const fetched = await wcFetchArray("/orders", { include: missing.slice(offset, offset + 100).join(","), per_page: "100" }, AbortSignal.timeout(15000));
          if (!fetched || missing.slice(offset, offset + 100).some(id => !fetched.some(o => Number(o["id"]) === id))) {
            res.status(502).json({ error: "Assigned order history is temporarily unavailable.", retryable: true }); return;
          }
          orders.push(...fetched);
        }
        // The local cash ledger wins over a stale Woo mirror once staff has
        // confirmed collection. This only overlays COD payment truth; all
        // other Woo order data remains authoritative.
        const localOrders = await db.select().from(ucOrdersTable).where(eq(ucOrdersTable.userId, userId));
        const collectedByWcId = new Map(localOrders
          .filter(local => local.codCollectionStatus === "collected" && local.wcOrderId != null)
          .map(local => [local.wcOrderId!, local]));
        const unsynchronized = await db.select().from(ucOrdersTable).where(and(eq(ucOrdersTable.userId, userId), isNull(ucOrdersTable.wcOrderId)));
        const assignedLocalIds = unsynchronized.map(o => o.id);
        const localAssigned = assignedLocalIds.length ? await db.select().from(ucOrdersTable)
          .where(and(inArray(ucOrdersTable.id, assignedLocalIds), eq(ucOrdersTable.userId, userId))) : [];
        const assignedItems = assignedLocalIds.length ? await db.select().from(ucOrderItemsTable)
          .where(inArray(ucOrderItemsTable.orderId, assignedLocalIds)) : [];
        const visibleOrders = orders
          .filter(o => {
            const billing = o["billing"] as Record<string, unknown> | undefined;
            return String(billing?.["email"] ?? "").toLowerCase() === emailLc || assignedWooIds.has(Number(o["id"]));
          })
          .sort((a, b) => String(b["date_created"] ?? "").localeCompare(String(a["date_created"] ?? "")))
          .map(order => {
            const normalized = normalizeOrder(order);
            const local = collectedByWcId.get(Number(order["id"]));
            const projection = localOrders.find(candidate => candidate.wcOrderId === Number(order["id"]));
            return projection
              ? {
                ...normalized,
                ...orderEvidence({ ...projection, status: String(normalized.status) }),
                // A lagging local COD collection ledger must not overwrite
                // Woo's explicit date_paid evidence with awaiting_collection.
                ...(normalized.paymentStatus === "paid" ? { paymentStatus: "paid" } : {}),
                shippingAddress: projection.shippingAddress ?? normalized.shippingAddress,
                ...(projection.customerStage ? {
                  customerStage: projection.customerStage,
                  customerStageUpdatedAt: projection.customerStageUpdatedAt,
                } : {}),
                ...(local ? { status: local.status, paymentStatus: "paid", codCollectionStatus: "collected" } : {}),
              }
              : normalized;
          });
        res.json([...visibleOrders, ...localAssigned.map(o => ({
          id: o.id, status: o.status, dateCreated: o.dateCreated,
          total: o.total, currency: o.currency, paymentMethod: o.paymentMethod,
          paymentReference: o.paymentReference ?? "", codCollectionStatus: o.codCollectionStatus,
          ...orderEvidence(o),
          shippingAddress: o.shippingAddress ?? {},
          lineItems: assignedItems.filter(i => i.orderId === o.id).map(i => ({
            productId: i.productId, name: i.name, quantity: i.quantity, total: i.total,
          })),
        }))]);
        return;
      }
      // The local mirror may not include historic store purchases. Never claim
      // it is a complete history when the authoritative fetch failed or hit
      // its safety bound.
      logger.warn({ userId, reason: "authoritative_history_incomplete" }, "[orders] Woo history unavailable");
      res.status(502).json({
        error: "Order history is temporarily unavailable. Please try again shortly.",
        retryable: true,
      });
      return;
    }
    // DB path: fetch this user's orders with their line items
    const orders = await db.select().from(ucOrdersTable)
      .where(eq(ucOrdersTable.userId, userId))
      .orderBy(desc(ucOrdersTable.dateCreated));
    if (orders.length === 0) {
      res.json([]);
      return;
    }
    const orderIds = orders.map(o => o.id);
    const items = await db.select().from(ucOrderItemsTable)
      .where(inArray(ucOrderItemsTable.orderId, orderIds));
    const itemsByOrder = items.reduce<Record<number, typeof items>>((acc, item) => {
      (acc[item.orderId] ??= []).push(item);
      return acc;
    }, {});
    const eventRows = await pool.query(
      `SELECT resource_id,stage,status,actor,idempotency_key AS "eventKey",created_at
       FROM uc_customer_stage_events
       WHERE resource_type='order' AND resource_id = ANY($1::text[])
       ORDER BY created_at DESC`,
      [orderIds.map(String)],
    );
    const eventsByOrder = eventRows.rows.reduce<Record<string, unknown[]>>((acc, event) => {
      (acc[String(event.resource_id)] ??= []).push(event);
      return acc;
    }, {});
    res.json(orders.map(o => ({
      id:              o.id,
      orderNumber:     o.wcOrderId ?? o.id,
      status:          o.status,
      customerStage:   o.customerStage ?? null,
      customerStageUpdatedAt: o.customerStageUpdatedAt ?? null,
      statusEvents:     (eventsByOrder[String(o.id)] ?? []).slice(0, 20),
      fulfillmentStatus: o.status,
      ...orderEvidence(o),
      dateCreated:     o.dateCreated,
      total:           o.total,
      currency:        o.currency,
      paymentMethod:   o.paymentMethod,
      shippingAddress: o.shippingAddress ?? {},
      delivery:        { method: "", trackingNumber: null },
      discountPercent: o.discountPercent,
      discountAmount:  o.discountAmount,
      promoCode:       o.promoCode ?? "",
      webhookRecovery: o.webhookRecovery ?? false,
      codCollectionStatus: o.codCollectionStatus ?? null,
      lineItems:       (itemsByOrder[o.id] ?? []).map(i => ({
        productId: i.productId,
        name:      i.name,
        quantity:  i.quantity,
        total:     i.total,
      })),
    })));
  } catch {
    res.json(orderStoreFallback.filter(o => (o as Record<string,unknown>)["userId"] === userId));
  }
});

// ─── Return Requests ──────────────────────────────────────────────────────────
const RETURN_WINDOW_DAYS = 30;
const RETURN_ELIGIBLE_STATUSES = ["completed", "shipped"];
const RETURN_REASONS = [
  "Defective or faulty product",
  "Wrong item delivered",
  "Product not as described",
  "Changed my mind",
];

/** GET /uc/orders/:orderId/return-request — fetch existing return request for this order/user */
router.get("/uc/orders/:orderId/return-request", async (req: Request, res: Response): Promise<void> => {
  const userId = userIdFromBearer(req.headers["authorization"]);
  const orderId = parseInt(String(req.params["orderId"] ?? ""), 10);
  if (isNaN(orderId)) { res.status(400).json({ error: "Invalid order ID." }); return; }
  try {
    const result = await pool.query(
      "SELECT id, reason, details, status, created_at FROM uc_return_requests WHERE order_id = $1 AND user_id = $2 LIMIT 1",
      [orderId, userId]
    );
    if (result.rows.length === 0) { res.json({ request: null }); return; }
    const r = result.rows[0] as { id: number; reason: string; details: string; status: string; created_at: string };
    res.json({ request: { id: r.id, reason: r.reason, details: r.details, status: r.status, createdAt: r.created_at } });
  } catch (err) {
    logger.error({ err }, "Return request fetch error");
    res.status(500).json({ error: "Failed to fetch return request." });
  }
});

/** POST /uc/orders/:orderId/return-request — submit a return request */
router.post("/uc/orders/:orderId/return-request", async (req: Request, res: Response): Promise<void> => {
  const userId = userIdFromBearer(req.headers["authorization"]);
  const retNumericId = Number(userId);
  if (await guardDeletedAccount(retNumericId, res)) return;
  const orderId = parseInt(String(req.params["orderId"] ?? ""), 10);
  if (isNaN(orderId)) { res.status(400).json({ error: "Invalid order ID." }); return; }

  const { reason, details } = req.body ?? {};
  if (!reason || typeof reason !== "string") { res.status(400).json({ error: "reason is required." }); return; }
  if (!RETURN_REASONS.includes(reason)) { res.status(400).json({ error: "Invalid reason. Please select a valid return reason." }); return; }

  try {
    const [order] = await db.select().from(ucOrdersTable)
      .where(and(eq(ucOrdersTable.id, orderId), eq(ucOrdersTable.userId, userId)))
      .limit(1);
    if (!order) { res.status(404).json({ error: "Order not found." }); return; }

    if (!RETURN_ELIGIBLE_STATUSES.includes(order.status)) {
      res.status(422).json({ error: "Returns can only be requested for delivered or shipped orders. If you have a concern about a pending order, please contact our support team." }); return;
    }

    const daysSince = (Date.now() - new Date(order.dateCreated).getTime()) / (1000 * 60 * 60 * 24);
    if (daysSince > RETURN_WINDOW_DAYS) {
      res.status(422).json({ error: `Our return window is ${RETURN_WINDOW_DAYS} days from the order date. This order is outside that window — but please reach out to support@ucfilters.co.ke or call 0717774049. Our team reviews every case personally.` }); return;
    }

    const existing = await pool.query(
      "SELECT id FROM uc_return_requests WHERE order_id = $1 AND user_id = $2 LIMIT 1",
      [orderId, userId]
    );
    if (existing.rows.length > 0) { res.status(409).json({ error: "A return request has already been submitted for this order." }); return; }

    const insert = await pool.query(
      "INSERT INTO uc_return_requests (order_id, user_id, reason, details) VALUES ($1, $2, $3, $4) RETURNING id, status, created_at",
      [orderId, userId, reason, (details ?? "").toString().trim()]
    );
    const row = insert.rows[0] as { id: number; status: string; created_at: string };

    // Notify the support team by email (non-blocking)
    const numericUserId = Number(userId);
    const [customer] = !isNaN(numericUserId)
      ? await db.select({ email: ucUsersTable.email })
          .from(ucUsersTable).where(eq(ucUsersTable.id, numericUserId)).limit(1)
      : [undefined];
    const detailsText = (details ?? "").toString().trim();
    sendViaResend({
      from: "Ultra-Clear Returns <noreply@contacts.ucfilters.com>",
      to: "support@ucfilters.co.ke",
      subject: `Return Request #${row.id} — Order #${orderId}`,
      text: [
        `A new return request has been submitted.`,
        `Request ID : ${row.id}`,
        `Order ID   : ${orderId}`,
        `Customer   : ${customer?.email ?? "unknown"}`,
        `Reason     : ${reason}`,
        detailsText ? `Details    : ${detailsText}` : "",
        ``,
        `Please review and contact the customer within 2 business days.`,
      ].filter(Boolean).join("\n"),
      html: `<p><strong>New Return Request #${row.id}</strong></p><ul><li><strong>Order:</strong> #${orderId}</li><li><strong>Customer:</strong> ${customer?.email ?? "unknown"}</li><li><strong>Reason:</strong> ${reason}</li>${detailsText ? `<li><strong>Details:</strong> ${detailsText}</li>` : ""}</ul><p>Please review and contact the customer within 2 business days.</p>`,
    }).catch(err => logger.warn({ err }, "Return request team email not sent"));

    res.status(201).json({
      ok: true,
      requestId: row.id,
      status: row.status,
      message: "Your return request has been received. Our team will be in touch within 2 business days. You can also reach us at support@ucfilters.co.ke or call 0717774049.",
    });
  } catch (err) {
    logger.error({ err }, "Return request submission error");
    res.status(500).json({ error: "Failed to submit return request. Please try again or contact support@ucfilters.co.ke." });
  }
});

/** Authenticated account projection for one order.  This is intentionally
 * local/mirror data: it remains available when Woo or Expo is unavailable. */
router.get("/uc/orders/:orderId", async (req: Request, res: Response): Promise<void> => {
  const claims = verifyToken(req.headers["authorization"]);
  const userId = userIdFromBearer(req.headers["authorization"]);
  const orderId = Number(req.params["orderId"]);
  if (!claims || !userId || !Number.isInteger(orderId) || orderId <= 0) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  try {
    const [order] = await db.select().from(ucOrdersTable).where(
      and(eq(ucOrdersTable.userId, userId), or(eq(ucOrdersTable.id, orderId), eq(ucOrdersTable.wcOrderId, orderId))),
    ).limit(1);
    if (!order) {
      res.status(404).json({ error: "Order not found" });
      return;
    }
    const [items, events] = await Promise.all([
      db.select().from(ucOrderItemsTable).where(eq(ucOrderItemsTable.orderId, order.id)),
      pool.query(
        `SELECT id,stage,status,actor,idempotency_key AS "eventKey",created_at
         FROM uc_customer_stage_events
         WHERE resource_type='order' AND resource_id=$1
         ORDER BY created_at DESC,id DESC LIMIT 20`,
        [String(order.id)],
      ),
    ]);
    const fulfillmentStatus = order.customerStage ?? order.status;
    res.json({
      id: order.id,
      orderNumber: order.wcOrderId ?? order.id,
      status: order.status,
      customerStage: order.customerStage,
      customerStageUpdatedAt: order.customerStageUpdatedAt,
      fulfillmentStatus,
      ...orderEvidence(order),
      receiptSerial: orderReceiptSerial(order.wcOrderId ?? order.id, order.dateCreated),
      paymentReference: order.paymentMethod === "cod" ? "" : order.mpesaReceipt || order.paymentReference || "",
      total: order.total,
      currency: order.currency,
      paymentMethod: order.paymentMethod,
      dateCreated: order.dateCreated,
      shippingAddress: order.shippingAddress ?? {},
      delivery: { method: "", trackingNumber: null },
      discountPercent: order.discountPercent,
      discountAmount: order.discountAmount,
      promoCode: order.promoCode ?? "",
      webhookRecovery: order.webhookRecovery ?? false,
      codCollectionStatus: order.codCollectionStatus ?? null,
      lineItems: items.map(i => ({
        productId: i.productId,
        name: i.name,
        quantity: i.quantity,
        total: i.total,
      })),
      statusEvents: events.rows.slice(0, 20),
    });
  } catch (error) {
    logger.error({ err: error, orderId }, "Failed to load customer order detail");
    res.status(500).json({ error: "Failed to load order detail" });
  }
});

// ─── Admin: all orders (team view) ───────────────────────────────────────────
// Returns every order in the database regardless of userId.
// Requires admin auth (DB-anchored: caller must be a registered admin user).
const WATER_TEST_CUSTOMER_STAGES = ["accepted", "conducted", "result_sent"] as const;

async function auditCustomerStagePush(input: {
  resourceType: "order" | "water_test"; resourceId: string; userId: string;
  stage: string; optOut: boolean;
}): Promise<{ status: "sent" | "failed" | "skipped"; deliveryEvent: string }> {
  const template = `${input.resourceType}-customer-stage`;
  const audit = async (status: "sent" | "failed" | "skipped", deliveryEvent: string, errorMessage?: string) => {
    await db.insert(ucNotificationLogTable).values({
      channel: "push", provider: "expo", recipient: input.userId, template,
      messageBody: `${input.resourceType} ${input.resourceId}: ${input.stage}`,
      ...(input.resourceType === "order" ? { orderId: Number(input.resourceId) } : { testId: input.resourceId }),
      status, deliveryEvent, deliveryEventAt: new Date(), errorMessage: errorMessage ?? null,
    }).catch((err) => logger.warn({ err, ...input }, "Customer-stage push audit write failed"));
  };
  if (input.optOut) { await audit("skipped", "opted_out"); return { status: "skipped", deliveryEvent: "opted_out" }; }
  const push = await getPushTokenRow(input.userId);
  if (!push) { await audit("skipped", "no_push_token"); return { status: "skipped", deliveryEvent: "no_push_token" }; }
  const noun = input.resourceType === "order" ? "order" : "water test";
  const result = await callExpoPushApi(push.pushToken, `Your ${noun} update`, `Your ${noun} is ${input.stage.replace("_", " ")}.`, {
    screen: input.resourceType === "order" ? "order-detail" : "water-test", id: input.resourceId, stage: input.stage,
  });
  if (result.staleToken) await removePushToken(input.userId);
  if (!result.accepted) {
    const event = result.staleToken ? "stale_token" : "provider_failure";
    await audit("failed", event, result.error);
    return { status: "failed", deliveryEvent: event };
  }
  await audit("sent", "accepted");
  return { status: "sent", deliveryEvent: "accepted" };
}

async function saveCustomerStage(input: {
  resourceType: "order" | "water_test"; resourceId: string; stage: string; userId: string;
  currentStage: string | null; idempotencyKey: string; actor: string; resultDeliveryReference?: string;
}): Promise<{ repeated: boolean }> {
  const stages = input.resourceType === "order" ? ORDER_CUSTOMER_STAGES : WATER_TEST_CUSTOMER_STAGES;
  const targetIndex = stages.indexOf(input.stage as never);
  const currentIndex = input.currentStage ? stages.indexOf(input.currentStage as never) : -1;
  if (targetIndex < 0 || targetIndex < currentIndex || targetIndex > currentIndex + 1) {
    const error = new Error("Customer stages may only move forward one stage at a time") as Error & { code?: string };
    error.code = "INVALID_STAGE_TRANSITION"; throw error;
  }
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query("SELECT pg_advisory_xact_lock(hashtext($1))", [`${input.resourceType}:${input.resourceId}`]);
    const existing = await client.query(
      `SELECT stage FROM uc_customer_stage_events WHERE resource_type=$1 AND resource_id=$2 AND (stage=$3 OR idempotency_key=$4) LIMIT 1`,
      [input.resourceType, input.resourceId, input.stage, input.idempotencyKey],
    );
    if (existing.rows[0]) { await client.query("COMMIT"); return { repeated: true }; }
    // Re-read after lock so stale callers cannot bypass forward-only semantics.
    const table = input.resourceType === "order" ? "uc_orders" : "uc_water_tests";
    const row = await client.query(`SELECT customer_stage FROM ${table} WHERE id=$1 FOR UPDATE`, [input.resourceId]);
    if (!row.rows[0]) { const e = new Error("Record not found") as Error & { code?: string }; e.code = "NOT_FOUND"; throw e; }
    const lockedCurrent = row.rows[0].customer_stage as string | null;
    const lockedIndex = lockedCurrent ? stages.indexOf(lockedCurrent as never) : -1;
    if (targetIndex < lockedIndex || targetIndex > lockedIndex + 1) {
      const e = new Error("Customer stages may only move forward one stage at a time") as Error & { code?: string }; e.code = "INVALID_STAGE_TRANSITION"; throw e;
    }
    if (input.resourceType === "water_test" && input.stage === "result_sent") {
      await client.query(`UPDATE uc_water_tests SET customer_stage=$2, customer_stage_updated_at=now(), result_delivery_reference=$3 WHERE id=$1`,
        [input.resourceId, input.stage, input.resultDeliveryReference]);
    } else {
      await client.query(`UPDATE ${table} SET customer_stage=$2, customer_stage_updated_at=now() WHERE id=$1`, [input.resourceId, input.stage]);
    }
    await client.query(`INSERT INTO uc_customer_stage_events (resource_type, resource_id, stage, idempotency_key, actor) VALUES ($1,$2,$3,$4,$5)`,
      [input.resourceType, input.resourceId, input.stage, input.idempotencyKey, input.actor]);
    await client.query("COMMIT");
    return { repeated: false };
  } catch (err) { await client.query("ROLLBACK").catch(() => undefined); throw err; } finally { client.release(); }
}

router.get("/uc/admin/orders", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) {
    // Unauthenticated or non-admin callers get a 403; recovery orders must
    // not be readable by arbitrary users.
    res.status(403).json({ error: "Admin access required" });
    return;
  }

  const dateRange = parseDateRange(req, res);
  if (!dateRange) return;

  try {
    const statusFilter = typeof req.query["status"] === "string" && req.query["status"].trim()
      ? req.query["status"].trim()
      : null;

    const orders = await db
      .select()
      .from(ucOrdersTable)
      .where(and(
        statusFilter ? eq(ucOrdersTable.status, statusFilter) : undefined,
        dateRange.from ? sql`${ucOrdersTable.dateCreated}::date >= ${dateRange.from}::date` : undefined,
        dateRange.to   ? sql`${ucOrdersTable.dateCreated}::date <= ${dateRange.to}::date`   : undefined,
      ))
      .orderBy(desc(ucOrdersTable.dateCreated));

    if (orders.length === 0) {
      res.json([]);
      return;
    }

    const orderIds = orders.map(o => o.id);
    const items = await db.select().from(ucOrderItemsTable)
      .where(inArray(ucOrderItemsTable.orderId, orderIds));
    const itemsByOrder = items.reduce<Record<number, typeof items>>((acc, item) => {
      (acc[item.orderId] ??= []).push(item);
      return acc;
    }, {});

    res.json(orders.map(o => ({
      id:               o.id,
      userId:           o.userId,
      status:           o.status,
      dateCreated:      o.dateCreated,
      total:            o.total,
      currency:         o.currency,
      paymentMethod:    o.paymentMethod,
      paymentReference: o.paymentReference ?? "",
      promoCode:        o.promoCode ?? "",
      discountPercent:  o.discountPercent,
      discountAmount:   o.discountAmount,
      shippingAddress:  o.shippingAddress ?? {},
      // True only for orders inserted by the webhook recovery path —
      // persisted at insert time, never derived from userId heuristics.
      webhookRecovery:  o.webhookRecovery ?? false,
      codCollectionStatus: o.codCollectionStatus ?? null,
      codCollectedBy: o.codCollectedBy ?? null,
      codCollectedAt: o.codCollectedAt ?? null,
      codWcSyncStatus: o.codWcSyncStatus ?? null,
      codWcSyncError: o.codWcSyncError ?? null,
      codWcSyncAttemptedAt: o.codWcSyncAttemptedAt ?? null,
      codWcSyncAttemptCount: o.codWcSyncAttemptCount ?? 0,
      customerStage:    o.customerStage ?? null,
      customerStageUpdatedAt: o.customerStageUpdatedAt ?? null,
      lineItems: (itemsByOrder[o.id] ?? []).map(i => ({
        productId: i.productId,
        name:      i.name,
        quantity:  i.quantity,
        total:     i.total,
      })),
    })));
  } catch (err) {
    logger.error({ err }, "Failed to load admin orders");
    res.status(500).json({ error: "Failed to load orders" });
  }
});

// ─── Admin order actions (admin-only mutations) ──────────────────────────────
// Statuses the team may set directly. "refunded" is deliberately excluded —
// it is only reachable through the refund endpoint so a real Paystack refund
// can never be skipped by a plain status change.
const ADMIN_SETTABLE_STATUSES = new Set([
  "pending", "processing", "paid", "declined", "completed", "cancelled",
]);

// PATCH /api/uc/admin/orders/:id/status — categorize an order (paid, declined, …)
router.patch("/uc/admin/orders/:id/status", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) { res.status(403).json({ error: "Admin access required" }); return; }

  const id = Number(req.params["id"]);
  if (!Number.isInteger(id) || id <= 0) { res.status(400).json({ error: "Invalid order id" }); return; }

  const status = typeof req.body?.status === "string" ? req.body.status.trim().toLowerCase() : "";
  if (!ADMIN_SETTABLE_STATUSES.has(status)) {
    res.status(400).json({ error: `Invalid status. Allowed: ${[...ADMIN_SETTABLE_STATUSES].join(", ")}` });
    return;
  }

  try {
    const [order] = await db.select().from(ucOrdersTable).where(eq(ucOrdersTable.id, id)).limit(1);
    if (!order) { res.status(404).json({ error: "Order not found" }); return; }
    if (order.status === "refunded") {
      res.status(409).json({ error: "Refunded orders cannot be re-categorized" });
      return;
    }
    await db.update(ucOrdersTable).set({ status }).where(eq(ucOrdersTable.id, id));
    logger.info({ orderId: id, from: order.status, to: status }, "Admin order status change");
    res.json({ ok: true, id, status });
  } catch (err) {
    logger.error({ err, orderId: id }, "Failed to update order status");
    res.status(500).json({ error: "Failed to update order status" });
  }
});

type CodWcSync = { status: string; error: string | null; attemptedAt: string | null; attemptCount: number } | null;

/**
 * Mirror already-committed cash collection to WooCommerce. A mirror failure is
 * recorded for staff reconciliation but can never undo the local cash ledger.
 */
async function syncCodCollectionToWoo(orderId: number): Promise<CodWcSync> {
  const found = await pool.query(
    "SELECT wc_order_id, cod_wc_sync_status, cod_wc_sync_error, cod_wc_sync_attempted_at, cod_wc_sync_attempt_count FROM uc_orders WHERE id=$1",
    [orderId],
  );
  const order = found.rows[0];
  if (!order?.wc_order_id) return null;
  if (!hasWCCredentials()) {
    await pool.query(
      `UPDATE uc_orders SET cod_wc_sync_status='failed',
        cod_wc_sync_error='WooCommerce credentials are not configured',
        cod_wc_sync_attempted_at=now(), cod_wc_sync_attempt_count=cod_wc_sync_attempt_count + 1 WHERE id=$1`,
      [orderId],
    );
    return {
      status: "failed",
      error: "WooCommerce credentials are not configured",
      attemptedAt: new Date().toISOString(),
      attemptCount: Number(order.cod_wc_sync_attempt_count ?? 0) + 1,
    };
  }
  await pool.query(
    `UPDATE uc_orders SET cod_wc_sync_status='pending', cod_wc_sync_error=NULL,
      cod_wc_sync_attempted_at=now(), cod_wc_sync_attempt_count=cod_wc_sync_attempt_count + 1 WHERE id=$1`,
    [orderId],
  );
  try {
    const response = await fetch(wcUrl(`/orders/${Number(order.wc_order_id)}`), {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: "processing", set_paid: true }),
    });
    const remote = await response.json().catch(() => null) as Record<string, unknown> | null;
    const normalized = remote ? normalizeOrder(remote) : null;
    if (!response.ok || Number(remote?.["id"]) !== Number(order.wc_order_id) || normalized?.["paymentStatus"] !== "paid") {
      throw new Error(`WooCommerce did not confirm paid processing status (HTTP ${response.status})`);
    }
    await pool.query("UPDATE uc_orders SET cod_wc_sync_status='succeeded', cod_wc_sync_error=NULL WHERE id=$1", [orderId]);
  } catch (err) {
    const message = err instanceof Error ? err.message : "WooCommerce status update failed";
    await pool.query("UPDATE uc_orders SET cod_wc_sync_status='failed', cod_wc_sync_error=$2 WHERE id=$1", [orderId, message.slice(0, 1000)])
      .catch((writeErr) => logger.error({ err: writeErr, orderId }, "Failed to persist COD Woo sync failure"));
  }
  const result = await pool.query(
    "SELECT cod_wc_sync_status, cod_wc_sync_error, cod_wc_sync_attempted_at, cod_wc_sync_attempt_count FROM uc_orders WHERE id=$1",
    [orderId],
  );
  const current = result.rows[0];
  return current ? {
    status: String(current.cod_wc_sync_status ?? "failed"),
    error: current.cod_wc_sync_error ? String(current.cod_wc_sync_error) : null,
    attemptedAt: current.cod_wc_sync_attempted_at ? new Date(current.cod_wc_sync_attempted_at).toISOString() : null,
    attemptCount: Number(current.cod_wc_sync_attempt_count ?? 0),
  } : null;
}

// POST /api/uc/admin/orders/:id/cod-collection — confirm that staff collected
// cash for a COD order. This is intentionally not a generic status change.
router.post("/uc/admin/orders/:id/cod-collection", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) { res.status(403).json({ error: "Admin access required" }); return; }
  const id = Number(req.params["id"]);
  const idempotencyKey = typeof req.body?.idempotencyKey === "string"
    ? req.body.idempotencyKey.trim().slice(0, 200) : "";
  if (!Number.isInteger(id) || id <= 0 || !idempotencyKey) {
    res.status(400).json({ error: "A valid order id and idempotencyKey are required" }); return;
  }

  const actor = String(verifyToken(req.headers["authorization"])?.email ?? "admin");
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    // Serialise confirmations per order and retain an immutable audit event.
    await client.query("SELECT pg_advisory_xact_lock(hashtext($1))", [`cod-collection:${id}`]);
    const prior = await client.query(
      "SELECT actor, collected_at FROM uc_cod_collection_events WHERE order_id=$1 AND idempotency_key=$2 LIMIT 1",
      [id, idempotencyKey],
    );
    if (prior.rows[0]) {
      await client.query("COMMIT");
      const event = prior.rows[0];
      const wcSync = await syncCodCollectionToWoo(id).catch((err) => {
        logger.error({ err, orderId: id }, "COD Woo sync lookup failed after committed collection");
        return null;
      });
      res.json({ ok: true, id, status: "paid", codCollectionStatus: "collected", codCollectedBy: event.actor, codCollectedAt: event.collected_at, repeated: true, wcSync });
      return;
    }
    const orderResult = await client.query(
      "SELECT payment_method, cod_collection_status FROM uc_orders WHERE id=$1 FOR UPDATE", [id],
    );
    const order = orderResult.rows[0];
    if (!order) { await client.query("ROLLBACK"); res.status(404).json({ error: "Order not found" }); return; }
    if (order.payment_method !== "cod") {
      await client.query("ROLLBACK"); res.status(409).json({ error: "Only COD orders can be confirmed as cash collected" }); return;
    }
    if (order.cod_collection_status === "collected") {
      await client.query("ROLLBACK"); res.status(409).json({ error: "COD collection has already been confirmed" }); return;
    }
    const inserted = await client.query(
      "INSERT INTO uc_cod_collection_events (order_id, idempotency_key, actor) VALUES ($1,$2,$3) RETURNING actor, collected_at",
      [id, idempotencyKey, actor],
    );
    const event = inserted.rows[0];
    await client.query(
      "UPDATE uc_orders SET status='paid', cod_collection_status='collected', cod_collected_by=$2, cod_collected_at=$3 WHERE id=$1",
      [id, event.actor, event.collected_at],
    );
    await client.query("COMMIT");
    logger.info({ orderId: id, actor, collectedAt: event.collected_at }, "COD cash collection confirmed");
    const wcSync = await syncCodCollectionToWoo(id).catch((err) => {
      logger.error({ err, orderId: id }, "COD Woo sync lookup failed after committed collection");
      return null;
    });
    res.json({ ok: true, id, status: "paid", codCollectionStatus: "collected", codCollectedBy: event.actor, codCollectedAt: event.collected_at, repeated: false, wcSync });
  } catch (err) {
    await client.query("ROLLBACK").catch(() => undefined);
    logger.error({ err, orderId: id }, "Failed to confirm COD collection");
    res.status(500).json({ error: "Failed to confirm COD collection" });
  } finally {
    client.release();
  }
});

router.patch("/uc/admin/orders/:id/customer-stage", async (req: Request, res: Response): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) { res.status(403).json({ error: "Admin access required" }); return; }
  const id = Number(req.params["id"]);
  const stage = typeof req.body?.stage === "string" ? req.body.stage.trim().toLowerCase() : "";
  const idempotencyKey = typeof req.body?.idempotencyKey === "string" ? req.body.idempotencyKey.trim().slice(0, 200) : "";
  if (!Number.isInteger(id) || id <= 0 || !(ORDER_CUSTOMER_STAGES as readonly string[]).includes(stage) || !idempotencyKey) {
    res.status(400).json({ error: "A valid order id, stage (accepted, shipped, delivered), and idempotencyKey are required" }); return;
  }
  const [order] = await db.select().from(ucOrdersTable).where(eq(ucOrdersTable.id, id)).limit(1);
  if (!order) { res.status(404).json({ error: "Order not found" }); return; }
  try {
    const saved = await transitionOrderStatus({
      orderId: id,
      status: order.status,
      customerStage: stage as typeof ORDER_CUSTOMER_STAGES[number],
      eventKey: `staff:${id}:${idempotencyKey}`,
      actor: String(verifyToken(req.headers["authorization"])?.email ?? "admin"),
      source: "staff",
    });
    res.json({
      ok: true,
      id,
      customerStage: saved.customerStage,
      repeated: saved.repeated,
      notification: saved.outboxCreated
        ? { status: "queued", deliveryEvent: "outbox" }
        : { status: "skipped", deliveryEvent: saved.repeated ? "already_processed" : "no_account" },
    });
  } catch (err) {
    const e = err as Error & { code?: string };
    if (e.code === "INVALID_STAGE_TRANSITION") res.status(409).json({ error: e.message });
    else { logger.error({ err, orderId: id }, "Failed to update order customer stage"); res.status(500).json({ error: "Failed to update order customer stage" }); }
  }
});

// POST /api/uc/admin/orders/:id/refund — refund an order.
// Paystack payments trigger a REAL refund through the Paystack API before the
// order is marked refunded; if Paystack rejects the refund the order status is
// left untouched. M-Pesa/COD orders are marked refunded for record-keeping
// only (M-Pesa reversals are handled manually by the team).
router.post("/uc/admin/orders/:id/refund", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) { res.status(403).json({ error: "Admin access required" }); return; }

  const id = Number(req.params["id"]);
  if (!Number.isInteger(id) || id <= 0) { res.status(400).json({ error: "Invalid order id" }); return; }

  try {
    const [order] = await db.select().from(ucOrdersTable).where(eq(ucOrdersTable.id, id)).limit(1);
    if (!order) { res.status(404).json({ error: "Order not found" }); return; }
    if (order.status === "refunded") { res.status(409).json({ error: "Order is already refunded" }); return; }

    let paystackRefunded = false;
    if (order.paymentMethod === "paystack" && order.paymentReference) {
      const secretKey = process.env["PAYSTACK_SECRET_KEY"];
      if (!secretKey) {
        res.status(500).json({ error: "PAYSTACK_SECRET_KEY is not configured — cannot send a real refund" });
        return;
      }
      const psRes = await fetch("https://api.paystack.co/refund", {
        method:  "POST",
        headers: { Authorization: `Bearer ${secretKey}`, "Content-Type": "application/json" },
        body:    JSON.stringify({ transaction: order.paymentReference }),
      });
      const data = (await psRes.json().catch(() => null)) as { status?: boolean; message?: string } | null;
      if (!psRes.ok || !data?.status) {
        // Do NOT mark the order refunded — money did not move.
        logger.error({ orderId: id, psStatus: psRes.status, message: data?.message }, "Paystack refund failed");
        res.status(502).json({ error: `Paystack refund failed: ${data?.message ?? `HTTP ${psRes.status}`}` });
        return;
      }
      paystackRefunded = true;
      logger.info({ orderId: id, reference: order.paymentReference }, "Paystack refund submitted");
    }

    await db.update(ucOrdersTable).set({ status: "refunded" }).where(eq(ucOrdersTable.id, id));
    res.json({ ok: true, id, status: "refunded", paystackRefunded, manual: !paystackRefunded });
  } catch (err) {
    logger.error({ err, orderId: id }, "Failed to refund order");
    res.status(500).json({ error: "Failed to refund order" });
  }
});

// DELETE /api/uc/admin/orders/:id — permanently remove an order + line items.
router.delete("/uc/admin/orders/:id", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) { res.status(403).json({ error: "Admin access required" }); return; }

  const id = Number(req.params["id"]);
  if (!Number.isInteger(id) || id <= 0) { res.status(400).json({ error: "Invalid order id" }); return; }

  try {
    const [order] = await db.select().from(ucOrdersTable).where(eq(ucOrdersTable.id, id)).limit(1);
    if (!order) { res.status(404).json({ error: "Order not found" }); return; }
    await db.delete(ucOrderItemsTable).where(eq(ucOrderItemsTable.orderId, id));
    await db.delete(ucOrdersTable).where(eq(ucOrdersTable.id, id));
    logger.info({ orderId: id, status: order.status }, "Admin deleted order");
    res.json({ ok: true, id });
  } catch (err) {
    logger.error({ err, orderId: id }, "Failed to delete order");
    res.status(500).json({ error: "Failed to delete order" });
  }
});

// GET /api/uc/admin/orders/recovery-count — count of unresolved webhook recovery
// orders (not completed and not cancelled). Used by the nav badge so the team
// can see pending recovery orders without navigating to the orders page.
// Requires admin auth. Intentionally lightweight — no line-item joins.
router.get("/uc/admin/orders/recovery-count", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }

  try {
    const rows = await db
      .select({ id: ucOrdersTable.id })
      .from(ucOrdersTable)
      .where(
        and(
          eq(ucOrdersTable.webhookRecovery, true),
          ne(ucOrdersTable.status, "completed"),
          ne(ucOrdersTable.status, "cancelled"),
        )
      );

    res.json({ count: rows.length });
  } catch (err) {
    logger.error({ err }, "Failed to count recovery orders");
    res.status(500).json({ error: "Failed to count recovery orders" });
  }
});

// ─── Reminder gaps ────────────────────────────────────────────────────────────
// Replacement reminders are driven by the product's lifespanDays (from the
// `filter_lifespan_days` meta). An order whose products all lack a lifespan
// silently produces NO replacement reminder for that customer. This report
// gives the team visibility into those orders so gaps are caught early.

/**
 * Classify a purchased product against the catalogue:
 *   - "missing-lifespan": product exists, needs a lifespan, but has none
 *     (per auditProductLifespans — exemptions for enquiry/accessory apply)
 *   - "unknown-product": product id not found in the catalogue at all, so no
 *     lifespan can ever be resolved for it
 *   - null: product is trackable or legitimately exempt — no gap
 * Exported for tests.
 */
export function classifyReminderGap(
  productId: number,
  catalogueIds: Set<number>,
  flaggedIds: Set<number>,
): "missing-lifespan" | "unknown-product" | null {
  if (!catalogueIds.has(productId)) return "unknown-product";
  return flaggedIds.has(productId) ? "missing-lifespan" : null;
}

// Order statuses that no longer need a reminder — the sale never went through.
const REMINDER_GAP_EXCLUDED_STATUSES = ["cancelled", "refunded", "declined"];

// GET /api/uc/admin/orders/reminder-gaps — admin-only report of orders whose
// line items include a product with no lifespan set (→ no replacement
// reminder will ever be scheduled for that purchase). ProjectHub surfaces
// this in the Orders view as a warning badge per affected order.
router.get("/uc/admin/orders/reminder-gaps", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  try {
    // Resolve the catalogue exactly like the lifespan audit does: live store
    // when credentials exist, otherwise the mock catalogue. A partially
    // unreachable store must fail loudly, never report a false all-clear.
    let source = "mock";
    let normalized: Record<string, unknown>[] | null = null;
    if (hasWCCredentials()) {
      const products = await fetchAllPublishedProducts();
      if (products) {
        normalized = products.map(normalizeProduct);
        source = "woocommerce";
      } else {
        res.status(502).json({ error: "Could not reach the WooCommerce store to check product lifespans" });
        return;
      }
    }
    if (!normalized) normalized = MOCK_PRODUCTS.map(normalizeProduct);

    const catalogueIds = new Set(normalized.map((p) => Number(p["id"])));
    const flaggedIds = new Set(auditProductLifespans(normalized).map((p) => Number(p["id"])));

    const orders = await db
      .select()
      .from(ucOrdersTable)
      .where(notInArray(ucOrdersTable.status, REMINDER_GAP_EXCLUDED_STATUSES))
      .orderBy(desc(ucOrdersTable.dateCreated));

    let gapOrders: {
      id: number;
      userId: string;
      status: string;
      dateCreated: Date | string;
      gapItems: { productId: number; name: string; quantity: number; reason: string }[];
    }[] = [];

    if (orders.length > 0) {
      const items = await db.select().from(ucOrderItemsTable)
        .where(inArray(ucOrderItemsTable.orderId, orders.map(o => o.id)));
      const itemsByOrder = items.reduce<Record<number, typeof items>>((acc, item) => {
        (acc[item.orderId] ??= []).push(item);
        return acc;
      }, {});

      gapOrders = orders.flatMap((o) => {
        const gapItems = (itemsByOrder[o.id] ?? []).flatMap((i) => {
          const reason = classifyReminderGap(i.productId, catalogueIds, flaggedIds);
          return reason
            ? [{ productId: i.productId, name: i.name, quantity: i.quantity, reason }]
            : [];
        });
        return gapItems.length > 0
          ? [{ id: o.id, userId: o.userId, status: o.status, dateCreated: o.dateCreated, gapItems }]
          : [];
      });
    }

    res.json({
      source,
      checkedAt: new Date().toISOString(),
      checkedOrders: orders.length,
      orders: gapOrders,
    });
  } catch (err) {
    logger.error({ err }, "Reminder-gap report failed");
    res.status(500).json({ error: "Reminder-gap report failed" });
  }
});

// GET /api/uc/admin/tickets — all maintenance tickets, most-recent first.
// Accepts optional ?status= filter. Protected by admin auth.
router.get("/uc/admin/tickets", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }

  const dateRange = parseDateRange(req, res);
  if (!dateRange) return;

  try {
    const statusFilter = typeof req.query["status"] === "string" && req.query["status"].trim()
      ? req.query["status"].trim()
      : null;

    const tickets = await db
      .select()
      .from(ucTicketsTable)
      .where(and(
        statusFilter ? eq(ucTicketsTable.status, statusFilter) : undefined,
        dateRange.from ? sql`${ucTicketsTable.createdAt}::date >= ${dateRange.from}::date` : undefined,
        dateRange.to   ? sql`${ucTicketsTable.createdAt}::date <= ${dateRange.to}::date`   : undefined,
      ))
      .orderBy(desc(ucTicketsTable.createdAt));

    res.json(tickets.map(t => ({
      id:                   t.id,
      userId:               t.userId,
      productModel:         t.productModel,
      issueDescription:     t.issueDescription,
      preferredContactTime: t.preferredContactTime,
      photos:               t.photos ?? [],
      videos:               t.videos ?? [],
      status:               t.status,
      createdAt:            t.createdAt,
    })));
  } catch (err) {
    logger.error({ err }, "Failed to load admin tickets");
    res.status(500).json({ error: "Failed to load tickets" });
  }
});

// PATCH /api/uc/admin/tickets/:id — update ticket status. Protected by admin auth.
const TICKET_STATUSES = ["submitted", "in_progress", "resolved"] as const;

router.patch("/uc/admin/tickets/:id", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }

  const id = String(req.params["id"]);
  const { status } = req.body as Record<string, unknown>;

  if (!status || typeof status !== "string" || !status.trim()) {
    res.status(400).json({ error: "status is required" });
    return;
  }

  const normalizedStatus = status.trim();
  if (!(TICKET_STATUSES as readonly string[]).includes(normalizedStatus)) {
    res.status(400).json({
      error: `Invalid status. Allowed values: ${TICKET_STATUSES.join(", ")}`,
    });
    return;
  }

  try {
    const [updated] = await db
      .update(ucTicketsTable)
      .set({ status: normalizedStatus })
      .where(eq(ucTicketsTable.id, id))
      .returning();

    if (!updated) {
      res.status(404).json({ error: "Ticket not found" });
      return;
    }

    res.json({
      id:                   updated.id,
      userId:               updated.userId,
      productModel:         updated.productModel,
      issueDescription:     updated.issueDescription,
      preferredContactTime: updated.preferredContactTime,
      photos:               updated.photos ?? [],
      videos:               updated.videos ?? [],
      status:               updated.status,
      createdAt:            updated.createdAt,
    });
  } catch (err) {
    logger.error({ err }, "Failed to update ticket status");
    res.status(500).json({ error: "Failed to update ticket" });
  }
});

// GET /api/uc/admin/water-tests — all water test bookings, most-recent first.
// Accepts optional ?status= filter. Protected by admin auth.
router.get("/uc/admin/water-tests", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }

  const dateRange = parseDateRange(req, res);
  if (!dateRange) return;

  try {
    const statusFilter = typeof req.query["status"] === "string" && req.query["status"].trim()
      ? req.query["status"].trim()
      : null;

    const waterTests = await db
      .select()
      .from(ucWaterTestsTable)
      .where(and(
        statusFilter ? eq(ucWaterTestsTable.status, statusFilter) : undefined,
        dateRange.from ? sql`${ucWaterTestsTable.createdAt}::date >= ${dateRange.from}::date` : undefined,
        dateRange.to   ? sql`${ucWaterTestsTable.createdAt}::date <= ${dateRange.to}::date`   : undefined,
      ))
      .orderBy(desc(ucWaterTestsTable.createdAt));

    res.json(waterTests.map(w => ({
      id:          w.id,
      userId:      w.userId,
      name:        w.name,
      address:     w.address,
      phone:       w.phone,
      waterSource: w.waterSource,
      concerns:    w.concerns,
      photos:      w.photos ?? [],
      videos:      w.videos ?? [],
      status:      w.status,
      customerStage: w.customerStage ?? null,
      customerStageUpdatedAt: w.customerStageUpdatedAt ?? null,
      resultDeliveryReference: w.resultDeliveryReference ?? null,
      createdAt:   w.createdAt,
    })));
  } catch (err) {
    logger.error({ err }, "Failed to load admin water tests");
    res.status(500).json({ error: "Failed to load water tests" });
  }
});

router.patch("/uc/admin/water-tests/:id/customer-stage", async (req: Request, res: Response): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) { res.status(403).json({ error: "Admin access required" }); return; }
  const id = String(req.params["id"] ?? "").trim();
  const stage = typeof req.body?.stage === "string" ? req.body.stage.trim().toLowerCase() : "";
  const idempotencyKey = typeof req.body?.idempotencyKey === "string" ? req.body.idempotencyKey.trim().slice(0, 200) : "";
  const resultDeliveryReference = typeof req.body?.resultDeliveryReference === "string" ? req.body.resultDeliveryReference.trim().slice(0, 500) : "";
  if (!id || !(WATER_TEST_CUSTOMER_STAGES as readonly string[]).includes(stage) || !idempotencyKey) {
    res.status(400).json({ error: "A water test id, stage (accepted, conducted, result_sent), and idempotencyKey are required" }); return;
  }
  if (stage === "result_sent" && !resultDeliveryReference) {
    res.status(400).json({ error: "resultDeliveryReference is required before marking a water test result sent" }); return;
  }
  const [test] = await db.select().from(ucWaterTestsTable).where(eq(ucWaterTestsTable.id, id)).limit(1);
  if (!test) { res.status(404).json({ error: "Water test not found" }); return; }
  try {
    const saved = await saveCustomerStage({ resourceType: "water_test", resourceId: id, stage, userId: test.userId,
      currentStage: test.customerStage, idempotencyKey, resultDeliveryReference: resultDeliveryReference || undefined,
      actor: String(verifyToken(req.headers["authorization"])?.email ?? "admin") });
    if (saved.repeated) { res.json({ ok: true, id, customerStage: stage, repeated: true, notification: { status: "skipped", deliveryEvent: "already_processed" } }); return; }
    const numericUserId = Number(test.userId);
    const [activeUsers, prefs] = await Promise.all([
      Number.isInteger(numericUserId) ? db.select({ id: ucUsersTable.id }).from(ucUsersTable).where(and(eq(ucUsersTable.id, numericUserId), isNull(ucUsersTable.deletedAt))).limit(1) : Promise.resolve([]),
      db.select().from(ucNotifPrefsTable).where(eq(ucNotifPrefsTable.userId, test.userId)).limit(1),
    ]);
    if (!activeUsers[0]) {
      await db.insert(ucNotificationLogTable).values({ channel: "push", provider: "expo", recipient: test.userId, template: "water_test-customer-stage", messageBody: `water_test ${id}: ${stage}`, testId: id, status: "skipped", deliveryEvent: "no_active_account", deliveryEventAt: new Date() });
      res.json({ ok: true, id, customerStage: stage, notification: { status: "skipped", deliveryEvent: "no_active_account" }, warning: "No active Companion account is linked to this water test" }); return;
    }
    res.json({ ok: true, id, customerStage: stage, notification: await auditCustomerStagePush({ resourceType: "water_test", resourceId: id, userId: test.userId, stage, optOut: prefs[0]?.optOutWaterTests ?? false }) });
  } catch (err) {
    const e = err as Error & { code?: string };
    if (e.code === "INVALID_STAGE_TRANSITION") res.status(409).json({ error: e.message });
    else { logger.error({ err, waterTestId: id }, "Failed to update water-test customer stage"); res.status(500).json({ error: "Failed to update water-test customer stage" }); }
  }
});

// ─── Date-range helper ────────────────────────────────────────────────────────
// Parses optional ?from=YYYY-MM-DD and ?to=YYYY-MM-DD query params.
// Returns { from, to } (each nullable) on success, or null after sending a 400.
const ISO_DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

/**
 * Returns true only for a string that is both syntactically YYYY-MM-DD and
 * represents a real calendar date.  Date.parse() alone is not sufficient because
 * V8 silently rolls over invalid days (e.g. "2024-02-30" becomes March 1) instead
 * of returning NaN, so we do a component round-trip check via Date.UTC().
 */
function isValidIsoDate(s: string): boolean {
  if (!ISO_DATE_RE.test(s)) return false;
  const [yearStr, monthStr, dayStr] = s.split("-");
  const year  = Number(yearStr);
  const month = Number(monthStr);
  const day   = Number(dayStr);
  const d = new Date(Date.UTC(year, month - 1, day));
  return (
    d.getUTCFullYear() === year &&
    d.getUTCMonth()    === month - 1 &&
    d.getUTCDate()     === day
  );
}

function parseDateRange(
  req: Request,
  res: Response,
): { from: string | null; to: string | null } | null {
  const rawFrom = typeof req.query["from"] === "string" ? req.query["from"].trim() : "";
  const rawTo   = typeof req.query["to"]   === "string" ? req.query["to"].trim()   : "";

  if (rawFrom && !isValidIsoDate(rawFrom)) {
    res.status(400).json({ error: "Invalid ?from= — expected YYYY-MM-DD" });
    return null;
  }
  if (rawTo && !isValidIsoDate(rawTo)) {
    res.status(400).json({ error: "Invalid ?to= — expected YYYY-MM-DD" });
    return null;
  }

  return { from: rawFrom || null, to: rawTo || null };
}

// ─── CSV export helpers ───────────────────────────────────────────────────────
// All cell values go through sanitiseCsvCell (RFC 4180 + formula-injection
// defence: values starting with =, +, -, @ are apostrophe-prefixed).
function csvRow(cells: unknown[]): string {
  return cells.map(v => sanitiseCsvCell(v === null || v === undefined ? "" : String(v))).join(",");
}
function csvTimestamp(): string {
  return new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
}

// GET /api/uc/admin/orders.csv — CSV download of all orders with line items expanded.
// Accepts optional ?status= and ?webhookRecovery=true filters. Protected by admin auth.
router.get("/uc/admin/orders.csv", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) { res.status(403).json({ error: "Admin access required" }); return; }

  const dateRange = parseDateRange(req, res);
  if (!dateRange) return;

  try {
    const statusFilter = typeof req.query["status"] === "string" && req.query["status"].trim()
      ? req.query["status"].trim() : null;
    const webhookRecoveryOnly = req.query["webhookRecovery"] === "true";

    const orders = await db
      .select()
      .from(ucOrdersTable)
      .where(and(
        statusFilter ? eq(ucOrdersTable.status, statusFilter) : undefined,
        webhookRecoveryOnly ? eq(ucOrdersTable.webhookRecovery, true) : undefined,
        dateRange.from ? sql`${ucOrdersTable.dateCreated}::date >= ${dateRange.from}::date` : undefined,
        dateRange.to   ? sql`${ucOrdersTable.dateCreated}::date <= ${dateRange.to}::date`   : undefined,
      ))
      .orderBy(desc(ucOrdersTable.dateCreated));

    let items: (typeof ucOrderItemsTable.$inferSelect)[] = [];
    const itemsByOrder: Record<number, typeof items> = {};
    if (orders.length > 0) {
      const orderIds = orders.map(o => o.id);
      items = await db.select().from(ucOrderItemsTable).where(inArray(ucOrderItemsTable.orderId, orderIds));
      for (const item of items) {
        (itemsByOrder[item.orderId] ??= []).push(item);
      }
    }

    // Determine the maximum number of line items across all orders for column expansion.
    const maxItems = Math.max(0, ...orders.map(o => (itemsByOrder[o.id] ?? []).length));

    // Build header row.
    const itemHeaders: string[] = [];
    for (let i = 1; i <= maxItems; i++) {
      itemHeaders.push(
        `item_${i}_productId`, `item_${i}_name`, `item_${i}_qty`, `item_${i}_total`,
      );
    }
    // Column order note: the original static columns keep their historical
    // positions so spreadsheet/import mappings built against older exports
    // stay valid; newer bookkeeping/marketing columns (mpesaReceipt,
    // receiptSerial, utm) are appended after them, before the item columns.
    const header = csvRow([
      "id", "userId", "status", "dateCreated", "total", "currency",
      "paymentMethod", "paymentReference", "promoCode",
      "discountPercent", "discountAmount", "webhookRecovery",
      "shippingName", "shippingPhone", "shippingAddress", "shippingCity", "shippingCountry",
      "mpesaReceipt", "receiptSerial", "utm",
      ...itemHeaders,
    ]);

    const dataRows = orders.map(o => {
      const addr = (o.shippingAddress ?? {}) as Record<string, unknown>;
      // Checkout persists firstName/lastName/address1; fall back to legacy name/address keys.
      const shippingName = [addr["firstName"], addr["lastName"]].filter(Boolean).join(" ")
        || String(addr["name"] ?? "");
      const shippingAddr = String(addr["address1"] ?? addr["address"] ?? "");
      const lineItems = itemsByOrder[o.id] ?? [];
      const itemCells: unknown[] = [];
      for (let i = 0; i < maxItems; i++) {
        const li = lineItems[i];
        itemCells.push(li?.productId ?? "", li?.name ?? "", li?.quantity ?? "", li?.total ?? "");
      }
      return csvRow([
        o.id, o.userId, o.status, new Date(o.dateCreated).toISOString(), o.total, o.currency,
        o.paymentMethod, o.paymentReference ?? "", o.promoCode ?? "",
        o.discountPercent, o.discountAmount, o.webhookRecovery ?? false,
        shippingName, addr["phone"] ?? "", shippingAddr, addr["city"] ?? "", addr["country"] ?? "",
        o.mpesaReceipt ?? "", orderReceiptSerial(o.id, o.dateCreated), promoUtmQuery(o.promoCode),
        ...itemCells,
      ]);
    });

    const csv = [header, ...dataRows].join("\r\n") + "\r\n";
    const filename = `orders_${csvTimestamp()}.csv`;
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.send(csv);
  } catch (err) {
    logger.error({ err }, "Failed to export orders CSV");
    res.status(500).json({ error: "Failed to export orders" });
  }
});

// GET /api/uc/admin/orders/:id/receipt.json — structured, machine-readable
// receipt for one order, sectioned for direct import into bookkeeping,
// inventory, and CRM systems. Protected by admin auth.
router.get("/uc/admin/orders/:id/receipt.json", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) { res.status(403).json({ error: "Admin access required" }); return; }

  const orderId = Number(req.params["id"]);
  if (!Number.isInteger(orderId) || orderId <= 0) {
    res.status(400).json({ error: "Invalid order id" });
    return;
  }

  try {
    const [order] = await db
      .select()
      .from(ucOrdersTable)
      .where(eq(ucOrdersTable.id, orderId))
      .limit(1);
    if (!order) { res.status(404).json({ error: "Order not found" }); return; }

    const lineItems = await db
      .select()
      .from(ucOrderItemsTable)
      .where(eq(ucOrderItemsTable.orderId, orderId));

    // CRM enrichment: app accounts live in uc_users (numeric ids below the
    // WooCommerce principal range); look up the email when available.
    let customerEmail: string | null = null;
    const numericUserId = Number(order.userId);
    if (Number.isInteger(numericUserId) && numericUserId > 0 && numericUserId < 1e9) {
      const [account] = await db
        .select({ email: ucUsersTable.email })
        .from(ucUsersTable)
        .where(eq(ucUsersTable.id, numericUserId))
        .limit(1);
      customerEmail = account?.email ?? null;
    }

    const addr = (order.shippingAddress ?? {}) as Record<string, unknown>;
    const customerName = [addr["firstName"], addr["lastName"]].filter(Boolean).join(" ")
      || String(addr["name"] ?? "");

    const totalNum = Number(order.total);
    const utm = promoUtmParams(order.promoCode);

    res.json({
      format: "uc-receipt/v1",
      receipt: {
        serial:    orderReceiptSerial(order.id, order.dateCreated),
        orderId:   order.id,
        orderDate: new Date(order.dateCreated).toISOString(),
        status:    order.status,
      },
      bookkeeping: {
        currency:         order.currency,
        // Pre-discount goods value; null when the stored total is not numeric.
        subtotal:         Number.isFinite(totalNum) ? totalNum + order.discountAmount : null,
        discountPercent:  order.discountPercent,
        discountAmount:   order.discountAmount,
        total:            order.total,
        paymentMethod:    order.paymentMethod,
        paymentReference: order.paymentReference ?? "",
        mpesaReceipt:     order.mpesaReceipt ?? "",
        webhookRecovery:  order.webhookRecovery ?? false,
      },
      inventory: {
        lineItems: lineItems.map(li => ({
          productId: li.productId,
          name:      li.name,
          quantity:  li.quantity,
          lineTotal: li.total,
        })),
      },
      crm: {
        userId:       order.userId,
        customerName,
        email:        customerEmail,
        phone:        String(addr["phone"] ?? ""),
        shippingAddress: order.shippingAddress ?? null,
        promoCode:    order.promoCode ?? "",
      },
      marketing: {
        promoCode: order.promoCode ?? "",
        utm,                                    // null when no promo code
        utmQuery:  promoUtmQuery(order.promoCode),
      },
    });
  } catch (err) {
    logger.error({ err, orderId }, "Failed to build receipt JSON");
    res.status(500).json({ error: "Failed to build receipt" });
  }
});

// GET /api/uc/admin/tickets.csv — CSV download of all maintenance tickets.
// Accepts optional ?status= filter. Protected by admin auth.
router.get("/uc/admin/tickets.csv", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) { res.status(403).json({ error: "Admin access required" }); return; }

  const dateRange = parseDateRange(req, res);
  if (!dateRange) return;

  try {
    const statusFilter = typeof req.query["status"] === "string" && req.query["status"].trim()
      ? req.query["status"].trim() : null;

    const tickets = await db
      .select()
      .from(ucTicketsTable)
      .where(and(
        statusFilter ? eq(ucTicketsTable.status, statusFilter) : undefined,
        dateRange.from ? sql`${ucTicketsTable.createdAt}::date >= ${dateRange.from}::date` : undefined,
        dateRange.to   ? sql`${ucTicketsTable.createdAt}::date <= ${dateRange.to}::date`   : undefined,
      ))
      .orderBy(desc(ucTicketsTable.createdAt));

    const header = csvRow([
      "id", "userId", "productModel", "issueDescription",
      "preferredContactTime", "photoCount", "videoCount", "status", "createdAt",
    ]);
    const dataRows = tickets.map(t => csvRow([
      t.id, t.userId, t.productModel, t.issueDescription,
      t.preferredContactTime, (t.photos ?? []).length, (t.videos ?? []).length,
      t.status, t.createdAt,
    ]));

    const csv = [header, ...dataRows].join("\r\n") + "\r\n";
    const filename = `tickets_${csvTimestamp()}.csv`;
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.send(csv);
  } catch (err) {
    logger.error({ err }, "Failed to export tickets CSV");
    res.status(500).json({ error: "Failed to export tickets" });
  }
});

// GET /api/uc/admin/water-tests.csv — CSV download of all water test bookings.
// Accepts optional ?status= filter. Protected by admin auth.
router.get("/uc/admin/water-tests.csv", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) { res.status(403).json({ error: "Admin access required" }); return; }

  const dateRange = parseDateRange(req, res);
  if (!dateRange) return;

  try {
    const statusFilter = typeof req.query["status"] === "string" && req.query["status"].trim()
      ? req.query["status"].trim() : null;

    const waterTests = await db
      .select()
      .from(ucWaterTestsTable)
      .where(and(
        statusFilter ? eq(ucWaterTestsTable.status, statusFilter) : undefined,
        dateRange.from ? sql`${ucWaterTestsTable.createdAt}::date >= ${dateRange.from}::date` : undefined,
        dateRange.to   ? sql`${ucWaterTestsTable.createdAt}::date <= ${dateRange.to}::date`   : undefined,
      ))
      .orderBy(desc(ucWaterTestsTable.createdAt));

    const header = csvRow([
      "id", "userId", "name", "address", "phone",
      "waterSource", "concerns", "photoCount", "videoCount", "status", "createdAt",
    ]);
    const dataRows = waterTests.map(w => csvRow([
      w.id, w.userId, w.name, w.address, w.phone,
      w.waterSource, w.concerns, (w.photos ?? []).length, (w.videos ?? []).length,
      w.status, w.createdAt,
    ]));

    const csv = [header, ...dataRows].join("\r\n") + "\r\n";
    const filename = `water-tests_${csvTimestamp()}.csv`;
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.send(csv);
  } catch (err) {
    logger.error({ err }, "Failed to export water tests CSV");
    res.status(500).json({ error: "Failed to export water tests" });
  }
});

// PATCH /api/uc/admin/water-tests/:id — update water test booking status. Protected by admin auth.
const WATER_TEST_STATUSES = ["pending", "scheduled", "completed"] as const;

router.patch("/uc/admin/water-tests/:id", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }

  const id = String(req.params["id"]);
  const { status } = req.body as Record<string, unknown>;

  if (!status || typeof status !== "string" || !status.trim()) {
    res.status(400).json({ error: "status is required" });
    return;
  }

  const normalizedStatus = status.trim();
  if (!(WATER_TEST_STATUSES as readonly string[]).includes(normalizedStatus)) {
    res.status(400).json({
      error: `Invalid status. Allowed values: ${WATER_TEST_STATUSES.join(", ")}`,
    });
    return;
  }

  try {
    const [updated] = await db
      .update(ucWaterTestsTable)
      .set({ status: normalizedStatus })
      .where(eq(ucWaterTestsTable.id, id))
      .returning();

    if (!updated) {
      res.status(404).json({ error: "Water test not found" });
      return;
    }

    res.json({
      id:          updated.id,
      userId:      updated.userId,
      name:        updated.name,
      address:     updated.address,
      phone:       updated.phone,
      waterSource: updated.waterSource,
      concerns:    updated.concerns,
      photos:      updated.photos ?? [],
      videos:      updated.videos ?? [],
      status:      updated.status,
      createdAt:   updated.createdAt,
    });
  } catch (err) {
    logger.error({ err }, "Failed to update water test status");
    res.status(500).json({ error: "Failed to update water test" });
  }
});

// ─── Admin notification log endpoints ────────────────────────────────────────

const PROJECTHUB_RECOVERY_EMAIL_TEMPLATES = new Set([
  "projecthub_invitation",
  "projecthub_password_reset",
]);

function isProjecthubRecoveryEmail(template: string): boolean {
  return PROJECTHUB_RECOVERY_EMAIL_TEMPLATES.has(template);
}

/**
 * GET /api/uc/admin/notification-logs
 * Returns recent SMS/email send attempts from uc_notification_log.
 * Accepts optional ?status=failed|sent and ?limit=N (default 100).
 * Protected by admin auth.
 */
router.get("/uc/admin/notification-logs", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }

  try {
    const statusFilter = typeof req.query["status"] === "string" && req.query["status"].trim()
      ? req.query["status"].trim()
      : null;
    const limit = Math.min(
      Number(req.query["limit"]) > 0 ? Number(req.query["limit"]) : 100,
      500,
    );

    const rows = await db
      .select()
      .from(ucNotificationLogTable)
      .where(statusFilter ? eq(ucNotificationLogTable.status, statusFilter) : undefined)
      .orderBy(desc(ucNotificationLogTable.sentAt))
      .limit(limit);

    // ProjectHub recovery entries must never disclose stale reset/invitation
    // links via this older, general-purpose log endpoint. New recovery sends
    // are metadata-only; this redaction also protects rows recorded before
    // that policy existed. Provider IDs are internal lookup keys, not UI data.
    res.json(rows.map(({ resendMessageId: _resendMessageId, ...row }) => (
      isProjecthubRecoveryEmail(row.template)
        ? { ...row, messageBody: "" }
        : row
    )));
  } catch (err) {
    logger.error({ err }, "Failed to load notification logs");
    res.status(500).json({ error: "Failed to load notification logs" });
  }
});

/**
 * GET /api/uc/admin/notification-logs/prune-preview
 * Counts rows currently eligible for pruning without deleting them.
 * Protected by admin auth.
 */
router.get("/uc/admin/notification-logs/prune-preview", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }

  try {
    const { getNotificationLogPrunePreview } = await import("../lib/scheduler.js");
    const { eligibleSuccess, eligibleFailure } = await getNotificationLogPrunePreview();
    res.json({
      eligibleSuccess,
      eligibleFailure,
      eligibleTotal: eligibleSuccess + eligibleFailure,
    });
  } catch (err) {
    logger.error({ err }, "Notification log prune preview failed");
    res.status(500).json({ error: "Failed to preview notification log pruning" });
  }
});

/**
 * POST /api/uc/admin/notification-logs/prune
 * Immediately runs the same pruning pass as the nightly 03:00 UTC job,
 * deleting sent/failed rows past their retention windows.
 * Returns the number of rows deleted. Protected by admin auth.
 */
router.post("/uc/admin/notification-logs/prune", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }

  try {
    // Lazy import to avoid a module cycle (scheduler.ts imports from this file).
    const { runNotificationLogPruning } = await import("../lib/scheduler.js");
    const { deletedSuccess, deletedFailure } = await runNotificationLogPruning();
    res.json({
      ok: true,
      deletedSuccess,
      deletedFailure,
      deletedTotal: deletedSuccess + deletedFailure,
    });
  } catch (err) {
    logger.error({ err }, "Manual notification log pruning failed");
    res.status(500).json({ error: "Failed to prune notification logs" });
  }
});

/**
 * POST /api/uc/admin/notification-logs/:id/retry
 * Re-sends the notification described by a FAILED log row.
 * - SMS: re-sends the stored messageBody (full SMS text) to the stored recipient.
 * - Email: re-sends the stored plain-text body with a human-readable subject
 *   derived from the template name. The stored messageBody is the full
 *   plain-text version of the original email (populated by sms.ts / email.ts).
 * Only rows with status='failed' may be retried.
 * Protected by admin auth.
 */
router.post("/uc/admin/notification-logs/:id/retry", async (req: Request, res: Response): Promise<void> => {
  const admin = await isAdminRequest(req.headers["authorization"]);
  if (!admin) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }

  const logId = Number(req.params["id"]);
  if (!logId) {
    res.status(400).json({ error: "Invalid log id" });
    return;
  }

  try {
    const [row] = await db
      .select()
      .from(ucNotificationLogTable)
      .where(eq(ucNotificationLogTable.id, logId))
      .limit(1);

    if (!row) {
      res.status(404).json({ error: "Log entry not found" });
      return;
    }

    // Only failed notifications make sense to retry.
    if (row.status !== "failed") {
      res.status(400).json({ error: "Only failed notifications can be retried" });
      return;
    }

    if (isProjecthubRecoveryEmail(row.template)) {
      res.status(409).json({
        error: "ProjectHub recovery emails must be reissued from User Management so a fresh secure link is created",
      });
      return;
    }

    // Guard against retrying a failure already superseded by a later successful
    // delivery (e.g. Resend fails → sendEmail fallback succeeds).
    // Use the most specific identity available: entity ID (orderId / ticketId /
    // testId) when present, or template when not, so an unrelated later message
    // to the same recipient on a different entity does NOT block the retry.
    let supersessionWhere;
    if (row.orderId != null) {
      supersessionWhere = and(
        eq(ucNotificationLogTable.channel,   row.channel),
        eq(ucNotificationLogTable.recipient, row.recipient),
        eq(ucNotificationLogTable.orderId,   row.orderId),
        eq(ucNotificationLogTable.status,    "sent"),
        gt(ucNotificationLogTable.sentAt,    row.sentAt),
      );
    } else if (row.ticketId) {
      supersessionWhere = and(
        eq(ucNotificationLogTable.channel,   row.channel),
        eq(ucNotificationLogTable.recipient, row.recipient),
        eq(ucNotificationLogTable.ticketId,  row.ticketId),
        eq(ucNotificationLogTable.status,    "sent"),
        gt(ucNotificationLogTable.sentAt,    row.sentAt),
      );
    } else if (row.testId) {
      supersessionWhere = and(
        eq(ucNotificationLogTable.channel,   row.channel),
        eq(ucNotificationLogTable.recipient, row.recipient),
        eq(ucNotificationLogTable.testId,    row.testId),
        eq(ucNotificationLogTable.status,    "sent"),
        gt(ucNotificationLogTable.sentAt,    row.sentAt),
      );
    } else if (row.template) {
      supersessionWhere = and(
        eq(ucNotificationLogTable.channel,   row.channel),
        eq(ucNotificationLogTable.recipient, row.recipient),
        eq(ucNotificationLogTable.template,  row.template),
        eq(ucNotificationLogTable.status,    "sent"),
        gt(ucNotificationLogTable.sentAt,    row.sentAt),
      );
    }
    // If no identity anchor is available, skip the supersession check.

    if (supersessionWhere) {
      const [laterSuccess] = await db
        .select({ id: ucNotificationLogTable.id })
        .from(ucNotificationLogTable)
        .where(supersessionWhere)
        .limit(1);

      if (laterSuccess) {
        res.status(409).json({
          error: "A later successful delivery already exists for this notification — retry is not needed",
        });
        return;
      }
    }

    if (row.channel === "sms") {
      // messageBody stores the full SMS text — re-send as-is.
      sendSms(row.recipient, row.messageBody, {
        template: row.template || undefined,
        orderId:  row.orderId ?? undefined,
        ticketId: row.ticketId ?? undefined,
        testId:   row.testId ?? undefined,
      });
    } else if (row.channel === "email") {
      // messageBody stores the full plain-text body of the original email.
      // Derive a human-readable subject from the template name.
      // Always HTML-escape the body before interpolation to prevent injection.
      const retrySubject = row.template
        ? `Ultra Clear — ${row.template.replace(/_/g, " ")} (re-sent)`
        : "Your Ultra Clear notification (re-sent)";
      const safeBody    = row.messageBody || "(original message unavailable — please contact support)";
      const escapedBody = escapeHtml(safeBody);
      sendEmail({
        to:       row.recipient,
        subject:  retrySubject,
        html:     `<pre style="font-family:Arial,sans-serif;white-space:pre-wrap">${escapedBody}</pre>`,
        text:     safeBody,
        template: row.template || undefined,
        orderId:  row.orderId ?? undefined,
        ticketId: row.ticketId ?? undefined,
        testId:   row.testId ?? undefined,
      });
    } else {
      res.status(400).json({ error: `Unknown channel: ${row.channel}` });
      return;
    }

    res.json({ ok: true, message: `Retry queued for ${row.channel} to ${row.recipient}` });
  } catch (err) {
    logger.error({ err, logId }, "Failed to retry notification");
    res.status(500).json({ error: "Failed to retry notification" });
  }
});

// ─── Push notifications infrastructure ──────────────────────────────────────

/**
 * Verify the Bearer JWT and return a stable user-identity string.
 * Returns "anonymous" when the token is absent, invalid, or unchanged.
 */
function userIdFromBearer(authHeader: string | undefined): string {
  const claims = verifyToken(authHeader);
  if (!claims) return "anonymous";
  return String(claims.id ?? claims.email ?? "anonymous");
}

// sendPushToUser is imported from ../lib/push.js

// ─── Contact lookup helper ────────────────────────────────────────────────────
/** Look up phone, email, and firstName for a registered DB user. Returns null
 *  for mock/legacy string ids (timestamps) or when the DB is unavailable. */
async function getUserContact(
  userId: string,
): Promise<{ phone: string; email: string; firstName: string } | null> {
  const numericId = Number(userId);
  if (isNaN(numericId) || numericId <= 0 || numericId >= 1_000_000_000) return null;
  try {
    const row = await db.query.ucUsersTable.findFirst({
      where: eq(ucUsersTable.id, numericId),
    });
    if (!row) return null;
    return { phone: row.phone, email: row.email, firstName: row.firstName };
  } catch {
    return null;
  }
}

// ─── Order confirmation email helper ─────────────────────────────────────────
/**
 * Fire-and-forget: look up the user's contact details from the DB and send an
 * order-confirmation email via Resend (falling back to the legacy SMTP provider
 * when Resend fails).  Exported so integration tests can call it directly.
 *
 * Never throws — all errors are logged and swallowed so a notification failure
 * can never prevent an order response from reaching the client.
 */
export function sendOrderConfirmationEmail(
  ownerUserId: string,
  order: {
    orderId:         string | number;
    lineItems:       Array<{ name?: string; quantity?: number; total?: string }>;
    total:           string;
    currency:        string;
    paymentMethod:   string;
    paymentStatus?:  string;
    shippingAddress?: Record<string, string>;
    discountAmount?:  number;
    promoCode?:       string;
    /** When the order was created — used for the receipt serial number. */
    dateCreated?:     string | Date;
    /** Payment trace for the receipt (M-Pesa code or gateway reference). */
    paymentReference?: string;
  },
): void {
  getUserContact(ownerUserId).then(contact => {
    if (contact?.phone) {
      sendSms(contact.phone, orderConfirmationSms({
        orderId:   order.orderId,
        total:     order.total,
        firstName: contact.firstName,
      }), { template: "order_confirmation", orderId: order.orderId });
    }
    if (contact?.email) {
      const receipt = buildOrderReceiptEmail({
        orderId:         order.orderId,
        firstName:       contact.firstName,
        email:           contact.email,
        lineItems:       order.lineItems,
        total:           order.total,
        currency:        order.currency,
        paymentMethod:   order.paymentMethod,
        paymentStatus:   order.paymentStatus,
        shippingAddress: order.shippingAddress,
        discountAmount:  order.discountAmount,
        promoCode:       order.promoCode,
        dateCreated:     order.dateCreated,
        paymentReference: order.paymentReference,
      });
      sendViaResend({
        from:    "orders@contacts.ucfilters.com",
        to:      contact.email,
        subject: receipt.subject,
        text:    receipt.text,
        html:    receipt.html,
        meta:    { template: "order_receipt", orderId: order.orderId },
      }).then(ok => {
        if (!ok) {
          logger.warn(`[resend] order confirmation not delivered to ${contact.email}; trying legacy email provider`);
          sendSlackTeamMessage(
            `⚠️ *Order confirmation email failed*\nResend could not deliver the receipt for order *#${order.orderId}* to ${contact.email}.\nThe legacy email provider is being attempted.`,
            "ORDER_CONFIRMATION_RESEND_FAILURE",
          ).catch(() => {});
          sendEmail({ to: contact.email, ...receipt, template: "order_receipt", orderId: order.orderId }).catch(() => {});
        }
      });
    }
  }).catch((err: unknown) => {
    logger.error({ err, orderId: order.orderId }, "Order receipt preparation failed");
  });
}

// ─── Filter registration from purchase record ────────────────────────────────
// POST /api/uc/filters/register-purchase
//
// A customer registers their installed filter with the receipt/order number
// plus the phone number used at checkout. Deliberately NO new table: the
// lookup runs against existing purchase records — app DB orders first, then
// the live WooCommerce store — so repeat purchases and multi-filter receipts
// reuse the same data. The response carries only what the mobile tracker
// needs (products + purchase date), never names or addresses.
//
// Anti-enumeration: rate-limited per IP, and the 404 message is identical for
// "no such order" and "phone doesn't match" so receipts can't be fished.

/** Compare phone numbers by their last 9 digits (Kenyan mobile significant
 *  digits) so 07XX…, +2547XX… and 2547XX… all match each other. */
function phonesMatch(a: unknown, b: unknown): boolean {
  const digits = (v: unknown) => String(v ?? "").replace(/\D/g, "").slice(-9);
  const da = digits(a);
  return da.length === 9 && da === digits(b);
}

// Statuses whose purchase records may be used for registration. Cancelled,
// refunded, failed and in-flight anchor ("pending-wc") orders are excluded.
const REGISTRABLE_STATUSES = new Set([
  "completed", "processing", "on-hold", "shipped", "delivered",
]);

const REGISTER_NOT_FOUND_MSG =
  "No purchase found matching that receipt number and phone number.";

router.post(
  "/uc/filters/register-purchase",
  lookupLimiter,
  async (req: Request, res: Response): Promise<void> => {
    const claims = verifyToken(req.headers["authorization"]);
    const accountId = claims ? Number(claims.id) : 0;
    if (!Number.isInteger(accountId) || accountId <= 0 || accountId >= 1_000_000_000) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }
    const [account] = await db.select({ id: ucUsersTable.id, email: ucUsersTable.email })
      .from(ucUsersTable)
      .where(and(eq(ucUsersTable.id, accountId), isNull(ucUsersTable.deletedAt)))
      .limit(1);
    if (!account) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }

    const { receipt, phone, productId: commitProductId, activatedAt: commitActivatedAt } = req.body as {
      receipt?: unknown;
      phone?: unknown;
      productId?: unknown;
      activatedAt?: unknown;
    };
    const receiptDigits = String(receipt ?? "").trim().replace(/^#/, "");
    const phoneDigits = String(phone ?? "").replace(/\D/g, "");
    if (!/^\d{1,10}$/.test(receiptDigits) || phoneDigits.length < 9) {
      logger.warn({ accountId, reason: "invalid_required_fields" }, "[register-purchase] rejected");
      res.status(400).json({
        error: "Enter your receipt number and the phone number used at purchase.",
      });
      return;
    }
    const orderId = Number(receiptDigits);

    type RegisterItem = {
      productId: number; name: string; quantity: number; lifespanDays: number; capacityLitres: number;
    };
    const respond = async (
      source: "app" | "store",
      status: string,
      dateCreated: unknown,
      rawItems: { productId: number; name: string; quantity: number }[],
    ): Promise<void> => {
      if (!REGISTRABLE_STATUSES.has(status)) {
        res.status(409).json({
          error: "This purchase is not active (cancelled or refunded), so it can't be used for registration.",
        });
        return;
      }
      const lifespans = await getProductLifespanMap();
      if (!lifespans) {
        res.status(503).json({
          error: "Product catalogue temporarily unreachable — please try again shortly.",
          retryable: true,
        });
        return;
      }
      const capacities = await getProductCapacityMap();
      if (!capacities) {
        res.status(503).json({
          error: "Product capacity data temporarily unreachable — please try again shortly.",
          retryable: true,
        });
        return;
      }
      const items: RegisterItem[] = rawItems.map((i) => ({
        ...i,
        lifespanDays: lifespans.get(i.productId) ?? 0, // 0 = not trackable, never guessed
        capacityLitres: capacities.get(i.productId) ?? 0,
      }));
      if (commitProductId !== undefined || commitActivatedAt !== undefined) {
        const productId = Number(commitProductId);
        const item = items.find((candidate) => candidate.productId === productId);
        const activatedAt = new Date(String(commitActivatedAt ?? dateCreated ?? ""));
        if (!item || item.lifespanDays <= 0) {
          logger.warn({ accountId, orderId, reason: "ineligible_product" }, "[register-purchase] rejected");
          res.status(400).json({ error: "Select an eligible filter from this purchase." });
          return;
        }
        if (!item.capacityLitres || !Number.isInteger(item.capacityLitres)) {
          res.status(422).json({ error: "This filter does not have a rated litre capacity yet. Contact Ultra-Clear support." });
          return;
        }
        if (Number.isNaN(activatedAt.getTime()) || activatedAt.getTime() > Date.now() + 60 * 60 * 1000) {
          logger.warn({ accountId, orderId, reason: "invalid_activation_date" }, "[register-purchase] rejected");
          res.status(400).json({ error: "Invalid activation date." });
          return;
        }
        const inserted = await db.insert(ucRegisteredFiltersTable)
          .values({
            userId: accountId,
            productId,
            productName: item.name,
            ratedCapacityLitres: item.capacityLitres,
            activatedAt,
            sourceOrderId: orderId,
            source,
          } as typeof ucRegisteredFiltersTable.$inferInsert)
          .onConflictDoNothing()
          .returning();
        if (inserted.length === 0) {
          logger.warn({ accountId, orderId, productId, source, reason: "duplicate_registration" }, "[register-purchase] rejected");
          res.status(409).json({ error: "This filter from this receipt is already registered to your account." });
          return;
        }
        res.status(201).json({ source, orderId, status, dateCreated, items, registration: inserted[0] });
        return;
      }
      res.json({ source, orderId, status, dateCreated, items });
    };

    // 1) App DB purchase record
    let dbFailed = false;
    try {
      const [row] = await db
        .select()
        .from(ucOrdersTable)
        .where(eq(ucOrdersTable.id, orderId))
        .limit(1);
      if (row) {
        const addr = (row.shippingAddress ?? {}) as Record<string, string>;
        if (appPurchaseOwnedBy(accountId, row.userId, addr["phone"], phone, phonesMatch)) {
          const items = await db
            .select()
            .from(ucOrderItemsTable)
            .where(eq(ucOrderItemsTable.orderId, row.id));
          await respond(
            "app",
            row.status,
            row.dateCreated,
            items.map((i) => ({ productId: i.productId, name: i.name, quantity: i.quantity })),
          );
          return;
        }
        // Phone mismatch → fall through to the generic 404 (no enumeration).
      }
    } catch (err) {
      dbFailed = true;
      logger.error({ err }, "[register-purchase] app DB lookup failed");
    }

    // 2) Live store purchase record (store receipts / orders placed on the site)
    if (hasWCCredentials()) {
      const o = await wcFetchOne(`/orders/${orderId}`);
      if (o && Number(o["id"]) === orderId) {
        const billing = (o["billing"] ?? {}) as Record<string, unknown>;
        const shipping = (o["shipping"] ?? {}) as Record<string, unknown>;
        // Store purchases require both the receipt phone and the authenticated
        // account email; phone possession alone must never establish ownership.
        if (storePurchaseOwnedBy(account.email, billing["email"], billing["phone"], shipping["phone"], phone, normalizeEmail, phonesMatch)) {
          const rawItems = Array.isArray(o["line_items"])
            ? (o["line_items"] as Record<string, unknown>[]).map((i) => ({
                productId: Number(i["product_id"]),
                name: String(i["name"] ?? ""),
                quantity: Number(i["quantity"]) || 1,
              }))
            : [];
          await respond("store", String(o["status"] ?? ""), o["date_created"], rawItems);
          return;
        }
      }
    }

    // A DB outage must not masquerade as "no such purchase".
    if (dbFailed) {
      res.status(503).json({
        error: "Purchase records temporarily unreachable — please try again shortly.",
        retryable: true,
      });
      return;
    }
    res.status(404).json({ error: REGISTER_NOT_FOUND_MSG });
  },
);

// ─── Orders ──────────────────────────────────────────────────────────────────
router.post("/uc/orders", async (req: Request, res: Response): Promise<void> => {
  if (req.headers.authorization && !verifyToken(req.headers.authorization)) {
    res.status(401).json({error:"Authentication required"}); return;
  }
  // Capture the caller's identity up-front so we can send a push notification
  // after the order is created without re-parsing the header each time.
  const orderUserId = userIdFromBearer(req.headers["authorization"]);
  const orderNumericId = Number(orderUserId);
  if (await guardDeletedAccount(orderNumericId, res)) return;
  // Legacy order branches have parent-only promotion/recovery anchors. Never
  // turn a child-priced request into parent fulfillment on those branches.
  if (req.body?.fulfillment === undefined && Array.isArray(req.body?.lineItems) &&
      req.body.lineItems.some((line: any) => line?.variationId !== undefined || line?.childSku !== undefined)) {
    res.status(422).json({ error: "Refresh your cart and use the updated checkout to order this variant.",
      code: "VARIANT_CHECKOUT_REFRESH_REQUIRED", retryable: false });
    return;
  }
  if (req.body?.fulfillment !== undefined) {
    try {
      const { paymentMethod, paymentReference = "", ...input } = req.body;
      const order = await prepareCheckoutOrder(input, orderUserId, paymentMethod);
      const verification = await verifyPaymentOnServer(paymentMethod, paymentReference);
      if (!verification.ok) { res.status(verification.retryable ? 503 : 402).json({ error: verification.reason ?? "Payment not confirmed" }); return; }
      if (verification.amount !== undefined && (!Number.isFinite(verification.amount) ||
          Math.abs(verification.amount - Number(order.total)) > 0.01 || verification.currency?.toUpperCase() !== "KES")) {
        res.status(402).json({ error: "Verified payment does not match this checkout total or currency" }); return;
      }
      const confirmed = await confirmCheckoutOrder(order.id, paymentReference);
      if (confirmed.reconciliationRequired) {
        res.status(202).json({ ...await checkoutOrderResponse({ ...confirmed.order, wc_order_id: null }), reconciliationRequired: true });
        return;
      }
      const response = await checkoutOrderResponse(confirmed.order);
      if (!confirmed.repeated) await notifyConfirmedCheckout(confirmed.order);
      res.json(response);
    } catch (error) { res.status(422).json({ error: (error as Error).message, fields: (error as { fields?: Record<string, string> }).fields }); }
    return;
  }

  let { lineItems, paymentMethod, paymentReference, shippingAddress, promoCode, idempotencyKey, fulfillment = "collection", applyReferralDiscount } =
    req.body as {
      lineItems: { productId: number; quantity: number }[];
      paymentMethod: string;
      paymentReference?: string;
      shippingAddress?: Record<string, string>;
      promoCode?: string;            // referral or promotion code
      idempotencyKey?: string;
      fulfillment?: Fulfillment;
      applyReferralDiscount?: boolean;
    };
  // Guest checkout is supported for orders that carry their own delivery
  // details.  In particular, never pass the sentinel "anonymous" through to
  // PostgreSQL as an integer: an invalid integer parameter used to turn a
  // perfectly valid guest COD request into a 500 before validation ran.
  // Authenticated orders still use the account email for referral discounts;
  // guests simply have no account-bound email.
  let userEmail: string | undefined;
  if (Number.isInteger(orderNumericId) && orderNumericId > 0) {
    const accountResult = await pool.query(
      `SELECT id,email,phone,address FROM uc_users WHERE id=$1 AND deleted_at IS NULL LIMIT 1`,
      [orderNumericId],
    );
    userEmail = accountResult.rows[0]?.email as string | undefined;
    if (!userEmail) {
      res.status(401).json({ error: "Authenticated customer account required" });
      return;
    }
    const profileContact = validateCustomerContact(accountResult.rows[0]);
    if (!profileContact.ok) {
      res.status(422).json({ code: "CONTACT_COMPLETION_REQUIRED", error: "Complete your account phone and contact address before checkout.",
        fields: profileContact.fields }); return;
    }
  }
  if (!lineItems || !paymentMethod) {
    res.status(400).json({ error: "Missing required fields" });
    return;
  }

  // Phone numbers are persisted and handed to payment/order providers for
  // every payment method, not only COD. Parse with the submitted country for
  // local numbers; without a valid country, local formats are rejected rather
  // than guessed as Kenyan.
  const submittedShipping = shippingAddress;
  const orderContact = validateCustomerContact({ phone: submittedShipping?.phone, address: submittedShipping?.address1, country: submittedShipping?.country });
  const contactErrors = { ...orderContact.fields, ...(paymentMethod === "cod" ? validateCodShipping(submittedShipping).fields : {}) };
  if (contactErrors.address) contactErrors.address1 = contactErrors.address;
  const submittedPhone = typeof submittedShipping?.phone === "string"
    ? submittedShipping.phone
    : "";
  const submittedCountry = typeof submittedShipping?.country === "string"
    ? countryCodeFromValue(submittedShipping.country)
    : undefined;
  const normalizedOrderPhone = submittedPhone
    ? normalizeInternationalPhone(submittedPhone, submittedCountry)
    : null;
  if (!normalizedOrderPhone) contactErrors.phone = "Please enter a valid phone number for the selected country.";
  if (Object.keys(contactErrors).length) {
    res.status(400).json({ error: Object.values(contactErrors).join(" "), fields: contactErrors }); return;
  }
  if (!normalizedOrderPhone) {
    if (paymentMethod === "cod") {
      const codCheck = validateCodShipping(submittedShipping);
      if (!codCheck.ok) {
        res.status(400).json({
          error: "Please check your delivery details",
          fields: codCheck.fields,
        });
        return;
      }
    }
    res.status(400).json({
      error: "Please check your delivery details",
      fields: { phone: "Please enter a valid phone number for the selected country." },
    });
    return;
  }
  const normalizedShippingAddress: Record<string, string> = {
    ...(submittedShipping ?? {}),
    phone: normalizedOrderPhone,
  };

  // ── COD input validation ────────────────────────────────────────────────
  // Cash orders have no payment barrier, so junk submissions (mashed names,
  // invalid phone numbers) are rejected here. Verified-payment methods are
  // deliberately not gated — a confirmed payment already proves intent.
  if (paymentMethod === "cod") {
    const codCheck = validateCodShipping(normalizedShippingAddress);
    if (!codCheck.ok) {
      res.status(400).json({
        error: "Please check your delivery details",
        fields: codCheck.fields,
      });
      return;
    }
    // Normalize the phone (07… → +254…) so SMS/WhatsApp reminders and the
    // team's callbacks always have a dialable international number.
    if (codCheck.normalizedPhone) {
      normalizedShippingAddress.phone = codCheck.normalizedPhone;
    }
  }
  // All downstream persistence/provider calls use this normalized value.
  shippingAddress = normalizedShippingAddress;

  if (
    isCustomerLifecycleFlagEnabled("dualWrites") &&
    paymentMethod === "cod" &&
    hasWCCredentials() &&
    !idempotencyKey?.trim()
  ) {
    res.status(400).json({ error: "idempotencyKey is required for canonical Woo COD checkout", retryable: false });
    return;
  }

  // Server-side payment verification — gate order creation on confirmed payment.
  const verification = await verifyPaymentOnServer(paymentMethod, paymentReference ?? "");
  if (!verification.ok) {
    // Use 503 (not 402) for transient failures so the client's ApiError
    // treats status >= 500 as retryable and offers the right advice.
    const httpStatus = verification.retryable ? 503 : 402;
    res.status(httpStatus).json({
      error: "Payment not verified",
      reason: verification.reason,
      ...(verification.retryable ? { retryable: true } : {}),
    });
    return;
  }

  // ── Idempotency guard ───────────────────────────────────────────────────────
  // If a non-empty paymentReference already has a *confirmed* order in the DB
  // (status != "pending-wc"), return it immediately without inserting a second
  // row or sending another email.
  // "pending-wc" records are WooCommerce in-flight anchors that have not yet
  // been confirmed — they are intentionally skipped here so the WC block can
  // either confirm them (update to "processing") or release them on failure.
  if (paymentReference) {
    try {
      const [existingOrder] = await db
        .select()
        .from(ucOrdersTable)
        .where(
          and(
            eq(ucOrdersTable.paymentReference, paymentReference),
            ne(ucOrdersTable.paymentReference, ""),
            ne(ucOrdersTable.status, "pending-wc"),
          )
        )
        .limit(1);

      if (existingOrder) {
        logger.info(
          { orderId: existingOrder.id },
          `[orders] duplicate paymentReference "${paymentReference}" — returning existing order`,
        );
        const existingItems = await db
          .select()
          .from(ucOrderItemsTable)
          .where(eq(ucOrderItemsTable.orderId, existingOrder.id));
        await reconcileCanonicalPurchaseDualWrite(existingOrder.id, `order-retry:${existingOrder.id}`);

        // If the existing row was created by the webhook recovery path it was
        // only recorded for team fulfilment — no customer confirmation email was
        // sent.  The first app call with a valid authenticated user should emit
        // that receipt now, and mark the row so subsequent retries skip it.
        if (existingOrder.webhookRecovery) {
          await db.update(ucOrdersTable)
            .set({ webhookRecovery: false })
            .where(eq(ucOrdersTable.id, existingOrder.id))
            .catch(() => {});
          const li = existingItems.map(i => ({
            name:     i.name,
            quantity: i.quantity,
            total:    i.total,
          }));
          sendOrderConfirmationEmail(orderUserId, {
            orderId:       existingOrder.id,
            lineItems:     li,
            total:         existingOrder.total,
            currency:      existingOrder.currency,
            paymentMethod: existingOrder.paymentMethod,
            paymentStatus: receiptOrderPaymentStatus(existingOrder),
            shippingAddress: existingOrder.shippingAddress as Record<string, string> | undefined,
            dateCreated:   existingOrder.dateCreated,
            // Prefer the customer-recognisable M-Pesa code when the callback stored one.
            paymentReference: existingOrder.mpesaReceipt || existingOrder.paymentReference || "",
          });
        }

        // When WooCommerce is the system of record, the original call returned
        // the WC order ID — return the same WC order on the retry so duplicate
        // Paystack deliveries observe a consistent order ID.
        //
        // Priority order:
        //   1. Live WC lookup succeeds → return normalised WC order.
        //   2. WC unreachable but wcOrderId was persisted at confirmation time
        //      → return the anchor row using the stored WC ID so the customer
        //      always sees the same order number regardless of WC availability.
        //   3. Nothing available → fall through to the DB anchor row.
        if (hasWCCredentials()) {
          try {
            const wcDup = await findWcOrderByRef(paymentReference);
            if (wcDup.status === "found") {
              res.json(normalizeOrder(wcDup.order));
              return;
            }
          } catch {
            /* WC unreachable — fall through to persisted wcOrderId below */
          }
          // Use the WC order ID persisted at confirmation time if available,
          // so retries return a consistent ID even when WC is temporarily down.
          if (existingOrder.wcOrderId != null) {
            res.json({
              id:              existingOrder.wcOrderId,
              status:          existingOrder.status,
              dateCreated:     existingOrder.dateCreated,
              total:           existingOrder.total,
              currency:        existingOrder.currency,
              paymentMethod:   existingOrder.paymentMethod,
              shippingAddress: existingOrder.shippingAddress ?? {},
              discountPercent: existingOrder.discountPercent,
              discountAmount:  existingOrder.discountAmount,
              promoCode:       existingOrder.promoCode ?? "",
              lineItems:       existingItems.map(i => ({
                productId: i.productId,
                name:      i.name,
                quantity:  i.quantity,
                total:     i.total,
              })),
            });
            return;
          }
        }

        res.json({
          id:              existingOrder.id,
          status:          existingOrder.status,
          dateCreated:     existingOrder.dateCreated,
          total:           existingOrder.total,
          currency:        existingOrder.currency,
          paymentMethod:   existingOrder.paymentMethod,
          shippingAddress: existingOrder.shippingAddress ?? {},
          discountPercent: existingOrder.discountPercent,
          discountAmount:  existingOrder.discountAmount,
          promoCode:       existingOrder.promoCode ?? "",
          lineItems:       existingItems.map(i => ({
            productId: i.productId,
            name:      i.name,
            quantity:  i.quantity,
            total:     i.total,
          })),
        });
        return;
      }
    } catch (dupCheckErr) {
      // DB temporarily unavailable — log and continue so the order is not lost
      logger.warn({ err: dupCheckErr }, "[orders] idempotency pre-check failed, proceeding");
    }
  }
  // ───────────────────────────────────────────────────────────────────────────

  // Replay the stored checkout BEFORE quoting a code that might have reached
  // its cap or expired as a result of the original successful transaction.
  if (idempotencyKey?.trim()) {
    // Older clients have an immutable in-flight Woo anchor without the new
    // claim format. Do not require a fresh catalogue to acknowledge that
    // already-priced attempt, or let a retry issue another remote POST.
    const legacyPending = await pool.query(`SELECT id FROM uc_orders
      WHERE user_id=$1 AND checkout_idempotency_key=$2 AND status='pending-wc'
        AND checkout_claim_id IS NULL AND date_created > now()-interval '15 minutes' LIMIT 1`,
      [orderUserId,idempotencyKey.trim()]);
    if (legacyPending.rows[0]) { res.status(503).json({error:"Order is being processed, please retry shortly",retryable:true}); return; }
    const prior = await pool.query("SELECT * FROM uc_orders WHERE user_id=$1 AND checkout_idempotency_key=$2 AND checkout_claim_id IS NOT NULL", [orderUserId, idempotencyKey.trim()]);
    if (prior.rows[0]) {
      const row = prior.rows[0];
      if (hasWCCredentials() && !row.wc_order_id) {
        const candidates = await wcFetchArray("/orders", { per_page: "100", status: "any", orderby: "date", order: "desc" });
        const remote = candidates?.find(candidate => Array.isArray(candidate.meta_data) &&
          (candidate.meta_data as any[]).some(m => m.key === "uc_checkout_claim_id" && m.value === row.checkout_claim_id));
        if (!remote) { res.status(row.checkout_state ? 202 : 503).json({ id: row.id, retryable: true, reconciliationRequired: true }); return; }
        await pool.query("UPDATE uc_orders SET wc_order_id=$2,status='processing',checkout_state='remote_confirmed' WHERE id=$1", [row.id, remote.id]);
        row.wc_order_id = remote.id; row.status = "processing";
      }
      res.json(await checkoutOrderResponse(row)); return;
    }
  }
  let pricing;
  try { pricing = await checkoutQuote({ lineItems, fulfillment, code: promoCode, applyReferralDiscount }, Number.isInteger(orderNumericId) ? orderNumericId : undefined); }
  catch (error) { res.status(422).json({ error: (error as Error).message }); return; }
  if (fulfillment === "delivery" && (!normalizedShippingAddress.address1?.trim() || !normalizedShippingAddress.city?.trim())) {
    res.status(400).json({ error: "Delivery address and city are required" }); return;
  }
  if (!normalizedShippingAddress.firstName?.trim()) { res.status(400).json({ error: "First name is required" }); return; }
  shippingAddress = { ...normalizedShippingAddress, fulfillment, shippingAmount: String(pricing.delivery),
    discountAmount: String(pricing.discountAmount), subtotal: String(pricing.subtotal) };
  const productLines = pricing.lines;
  const { subtotal, delivery, discountAmount, discountPercent, total: netTotal } = pricing;
  const durableCheckoutPromotion = pricing.promotion;
  const discountType = durableCheckoutPromotion ? "promotion" : discountPercent ? "referral" : null;
  if ((durableCheckoutPromotion || pricing.referralBenefitId) && !idempotencyKey?.trim()) {
    res.status(400).json({ error: "idempotencyKey is required when using a code or reward" }); return;
  }
  if (pricing.referralBenefitId && paymentMethod === "cod") { res.status(422).json({ error: "Referral rewards require a paid order" }); return; }
  if (paymentMethod === "free" && netTotal !== 0) { res.status(422).json({ error: "This order requires payment" }); return; }
  const isPaid = paymentMethod !== "cod";
  // Durable promoted WC checkout uses a local claim before its single remote
  // attempt.  A retry observes that claim and never posts another discount.
  if (idempotencyKey?.trim() && hasWCCredentials() && (promoCode || applyReferralDiscount)) {
    const key = idempotencyKey!.trim();
    const prior = await pool.query("SELECT * FROM uc_orders WHERE user_id=$1 AND checkout_idempotency_key=$2 LIMIT 1", [orderUserId, key]);
    if (prior.rows[0]) {
      const row = prior.rows[0];
      if (row.wc_order_id) {
        const storedItems = await pool.query("SELECT * FROM uc_order_items WHERE order_id=$1 ORDER BY id", [row.id]);
        await reconcileCanonicalPurchaseDualWrite(row.id, `woo:${row.id}`);
        res.json({ id: row.wc_order_id, status: row.status, dateCreated: row.date_created, total: row.total,
          currency: row.currency, paymentMethod: row.payment_method, shippingAddress: row.shipping_address ?? {},
          discountPercent: row.discount_percent, discountAmount: row.discount_amount, promoCode: row.promo_code ?? "",
          lineItems: storedItems.rows.map((item) => ({ productId: item.product_id, name: item.name, quantity: item.quantity, total: item.total })) });
        return;
      }
      const candidates = await wcFetchArray("/orders", { per_page: "100", status: "any", orderby: "date", order: "desc" });
      const matched = candidates?.find((candidate) => Array.isArray(candidate["meta_data"]) &&
        (candidate["meta_data"] as Record<string, unknown>[]).some((meta) => meta["key"] === "uc_checkout_claim_id" && meta["value"] === row.checkout_claim_id));
      if (matched?.["id"]) {
        await pool.query("UPDATE uc_orders SET wc_order_id=$2,status='processing',checkout_state='remote_confirmed' WHERE id=$1", [row.id, Number(matched["id"])]);
        await reconcileCanonicalPurchaseDualWrite(row.id, `woo:${row.id}`);
        res.json(normalizeOrder(matched)); return;
      }
      // Unknown/attempted claims are deliberately reconciliation-only: never
      // make another remote POST after an ambiguous first attempt.
      res.status(202).json({ id: row.id, checkoutState: row.checkout_state ?? "remote_unknown", reconciliationRequired: true });
      return;
    }
    const claimId = randomUUID();
    const client = await pool.connect();
    let anchor: any;
    try {
      await client.query("BEGIN");
      const inserted = await client.query(`INSERT INTO uc_orders (user_id,status,total,currency,payment_method,payment_reference,promo_code,discount_percent,discount_amount,shipping_address,checkout_idempotency_key,checkout_claim_id,checkout_state,cod_collection_status)
        VALUES ($1,'pending-wc',$2,'KES',$3,$4,$5,$6,$7,$8,$9,$10,'remote_pending',$11) RETURNING *`,
        [orderUserId, String(netTotal), paymentMethod, paymentReference ?? "", promoCode ?? "", discountPercent, discountAmount, JSON.stringify(shippingAddress ?? {}), key, claimId, paymentMethod === "cod" ? "awaiting_collection" : null]);
      anchor = inserted.rows[0];
      for (const line of productLines) await client.query("INSERT INTO uc_order_items(order_id,product_id,name,quantity,total) VALUES($1,$2,$3,$4,$5)", [anchor.id,line.productId,line.name,line.quantity,String(line.subtotal)]);
      if (durableCheckoutPromotion) {
        const use = await consumePromotionOnClient(client, { quote: durableCheckoutPromotion, userId: orderNumericId, operation: "checkout", actor: `customer:${orderNumericId}`, idempotencyKey: key, operationRef: `${claimId}:${anchor.id}` });
        await client.query("UPDATE uc_promotion_uses SET operation_ref=$1 WHERE id=$2", [`${claimId}:${anchor.id}`, use.use.id]);
      }
      await claimReferralBenefit(client, pricing.referralBenefitId, orderNumericId, anchor.id);
      await client.query("COMMIT");
    } catch (error) {
      await client.query("ROLLBACK").catch(() => undefined); client.release();
      const priorRace = await pool.query("SELECT * FROM uc_orders WHERE user_id=$1 AND checkout_idempotency_key=$2 LIMIT 1", [orderUserId,key]);
      if (priorRace.rows[0]) { res.status(202).json({ id: priorRace.rows[0].id, reconciliationRequired: true }); return; }
      res.status(409).json({ error: (error as Error).message }); return;
    }
    client.release();
    await pool.query("UPDATE uc_orders SET checkout_state='remote_attempted',remote_attempted_at=now() WHERE id=$1", [anchor.id]);
    const payload = { payment_method: paymentMethod, set_paid: isPaid, shipping: shippingAddress,
      billing: { email: userEmail, first_name: shippingAddress?.firstName, last_name: shippingAddress?.lastName,
        phone: shippingAddress?.phone, country: shippingAddress?.country,
        address_1: shippingAddress?.address1, city: shippingAddress?.city },
      line_items: productLines.map((line) => ({ product_id: line.productId, quantity: line.quantity, subtotal: String(line.subtotal), total: String(line.subtotal) })),
      shipping_lines: [{ method_id: fulfillment === "collection" ? "local_pickup" : "flat_rate", method_title: fulfillment === "collection" ? "Free collection" : "Delivery", total: String(delivery) }],
      fee_lines: discountAmount ? [{ name: `Companion ${promoCode || "referral reward"}`, total: String(-discountAmount), taxable: false }] : [],
      meta_data: [{ key: "uc_checkout_claim_id", value: claimId }, { key: "uc_checkout_key", value: key }, { key: "uc_account_id", value: orderUserId }, { key: "payment_reference", value: paymentReference ?? "" }, { key: "uc_fulfillment", value: fulfillment }] };
    try {
      const remote = await fetch(wcUrl("/orders"), { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      if (!remote.ok) throw new Error(`WC order creation failed with ${remote.status}`);
      const order = await remote.json() as Record<string, unknown>;
      if (!order || !order["id"]) throw new Error("WC did not return an order");
      await pool.query("UPDATE uc_orders SET wc_order_id=$2,status='processing',checkout_state='remote_confirmed' WHERE id=$1", [anchor.id, Number(order["id"])]);
      await reconcileCanonicalPurchaseDualWrite(anchor.id, claimId);
      res.json(normalizeOrder(order)); return;
    } catch (error) {
      if (error instanceof CanonicalPurchaseDualWriteError) {
        res.status(503).json({ error: "Order recorded; canonical reconciliation will retry", retryable: true });
        return;
      }
      await pool.query("UPDATE uc_orders SET checkout_state='remote_unknown' WHERE id=$1", [anchor.id]);
      res.status(202).json({ id: anchor.id, checkoutState: "remote_unknown", reconciliationRequired: true }); return;
    }
  }

  // ── WC order reconciliation helper ─────────────────────────────────────────
  // Paginates through recent WC orders (newest first) to find one carrying an
  // exact payment_reference match in meta_data.  We do NOT rely on WooCommerce's
  // meta_key/meta_value collection filter — that parameter is not part of the
  // documented WC REST API v3 spec and may be silently ignored on many
  // installations, causing unfiltered results that a secondary scan would
  // incorrectly treat as "not_found" and proceed to POST a duplicate.
  //
  // Instead we paginate deterministically through up to MAX_PAGES pages so that
  // "not_found" only fires after exhausting all pages — a reliable confirmed
  // absence within a practical order-volume bound.
  //
  // Returns a tri-state so callers can distinguish a confirmed absence from a
  // lookup failure:
  //   { status: "found",     order }  — exact match in WC
  //   { status: "not_found" }         — all pages exhausted; reference not in WC
  //   { status: "error" }             — WC query itself failed (network / creds)
  type WcLookupResult =
    | { status: "found"; order: Record<string, unknown> }
    | { status: "not_found" }
    | { status: "error" };

  // A normal WooCommerce request should finish well inside this window. Older
  // anchors may be left behind by a crashed process, but are released only
  // after WooCommerce definitively confirms it has no matching order.
  const WC_PENDING_ANCHOR_MAX_AGE_MS = 15 * 60 * 1000;

  async function findWcOrderByRef(ref: string): Promise<WcLookupResult> {
    const PER_PAGE = 100;
    const MAX_PAGES = 5; // up to 500 orders before failing closed

    for (let page = 1; page <= MAX_PAGES; page++) {
      const orders = await wcFetchArray("/orders", {
        per_page: String(PER_PAGE),
        page:     String(page),
        status:   "any",
        orderby:  "date",
        order:    "desc",
      });

      if (orders === null) return { status: "error" };

      for (const o of orders) {
        const meta = o["meta_data"];
        if (!Array.isArray(meta)) continue;
        const found = (meta as Array<Record<string, unknown>>).some(
          (m) => (m["key"] === "payment_reference" || m["key"] === "uc_checkout_key") && m["value"] === ref
        );
        if (found) return { status: "found", order: o };
      }

      // A page shorter than PER_PAGE is the terminal page — we have seen every
      // WC order and can confirm the reference is absent.
      if (orders.length < PER_PAGE) return { status: "not_found" };
    }

    // We reached the scan limit (MAX_PAGES × PER_PAGE) without a terminal short
    // page, so there may be additional WC orders beyond our window.  We cannot
    // confirm absence — fail closed to prevent a duplicate POST.
    return { status: "error" };
  }

  // ── WC confirmation helper ──────────────────────────────────────────────────
  // Atomically transitions the anchor from "pending-wc" to "processing" and
  // persists the WooCommerce order ID so that future retries can return a
  // consistent external ID even when WC is briefly unreachable.
  // Returns true only when THIS call won the state transition.  Callers must
  // send notifications ONLY when this returns true.
  async function confirmWcAnchor(anchorId: number, wcOrderId: number): Promise<boolean> {
    const updated = await db.update(ucOrdersTable)
      .set({ status: "processing", wcOrderId })
      .where(and(eq(ucOrdersTable.id, anchorId), eq(ucOrdersTable.status, "pending-wc")))
      .returning()
      .catch((e: unknown) => {
        logger.warn({ err: e, anchorId }, "[orders] confirmWcAnchor DB update failed");
        return [] as { id: number }[];
      });
    if (updated.length > 0) {
      await reconcileCanonicalPurchaseDualWrite(anchorId, `woo:${anchorId}`);
    }
    return updated.length > 0;
  }

  // ── WC notification helper ──────────────────────────────────────────────────
  // Fire-and-forget push + SMS + email for a confirmed WC order.  Must be
  // called ONLY by the request that won the confirmWcAnchor race.
  function sendWcOrderNotifications(
    normalized: Record<string, unknown>,
    ownerUserId: string,
  ): void {
    sendPushToUser(
      ownerUserId,
      "✅ Order confirmed!",
      `Your order #${normalized["id"] ?? "–"} is being processed.`,
      { screen: "orders", orderId: String(normalized["id"] ?? "") },
      "orders"
    );
    sendOrderConfirmationEmail(ownerUserId, {
      orderId:       normalized["id"] as string | number,
      lineItems:     (normalized["lineItems"] as Array<{ name: string; quantity: number; total: string }> | undefined) ?? [],
      total:         String(normalized["total"] ?? "0"),
      currency:      String(normalized["currency"] ?? "KES"),
      paymentMethod: String(normalized["paymentMethod"] ?? ""),
      paymentStatus: String(normalized["paymentStatus"] ?? "pending"),
      shippingAddress: normalized["shippingAddress"] as Record<string, string> | undefined,
      discountAmount: Number(normalized["discountAmount"] ?? discountAmount),
      promoCode: String(normalized["promoCode"] ?? promoCode ?? ""),
      dateCreated:   normalized["dateCreated"] as string | undefined,
      paymentReference: paymentReference ?? "",
    });
  }

  try {
    if (hasWCCredentials()) {
      // ── WooCommerce idempotency: claim → call → confirm ───────────────────
      //
      // Step 1: Atomically insert a "pending-wc" anchor + line items into
      //   uc_orders / uc_order_items inside a DB transaction BEFORE calling
      //   WooCommerce.  If either insert fails the whole transaction rolls back.
      //   The "pending-wc" sentinel is skipped by the pre-check above so it
      //   never causes a confirmed-order early return.
      //
      // Step 2: Call WooCommerce.
      //
      // Step 3a (WC success): Call confirmWcAnchor — atomically UPDATE WHERE
      //   status='pending-wc'.  Send notifications ONLY when it returns true
      //   (this request won the race).  Concurrent requests that lose skip
      //   notifications and return the same WC order.
      //
      // Step 3b (WC failure): Reconcile by inspecting each candidate WC order's
      //   meta_data for an EXACT payment_reference match.  If found → try atomic
      //   confirmation → notify only if we won.  If uncertain (no match or WC
      //   query fails) → keep anchor intact, return retriable 503.  Anchors for
      //   permanently failed WC calls are cleaned up by a periodic job.

      let wcAnchorId: number | null = null;
      let pendingAnchorId: number | null = null;
      let pendingAnchorReleased = false;
      let createdByThisRequest = false;
      // Reference-less COD still gets a durable, request-scoped claim. Empty
      // payment references are never used as a global idempotency key.
      const wcCheckoutKey = paymentReference || (paymentMethod === "cod" ? idempotencyKey?.trim() : "");

      if (wcCheckoutKey) {
        const [confirmedKeyOrder] = await db.select().from(ucOrdersTable).where(and(
          eq(ucOrdersTable.userId, orderUserId),
          eq(ucOrdersTable.checkoutIdempotencyKey, wcCheckoutKey),
          eq(ucOrdersTable.status, "processing"),
        )).limit(1);
        if (confirmedKeyOrder) {
          await reconcileCanonicalPurchaseDualWrite(confirmedKeyOrder.id, `woo-retry:${confirmedKeyOrder.id}`);
          const confirmedItems = await db.select().from(ucOrderItemsTable)
            .where(eq(ucOrderItemsTable.orderId, confirmedKeyOrder.id));
          res.json({
            id: confirmedKeyOrder.id, status: confirmedKeyOrder.status,
            dateCreated: confirmedKeyOrder.dateCreated, total: confirmedKeyOrder.total,
            currency: confirmedKeyOrder.currency, paymentMethod: confirmedKeyOrder.paymentMethod,
            shippingAddress: confirmedKeyOrder.shippingAddress ?? {},
            lineItems: confirmedItems.map((i) => ({ productId: i.productId, name: i.name, quantity: i.quantity, total: i.total })),
          });
          return;
        }
        const [pendingAnchor] = await db
          .select({
            id: ucOrdersTable.id,
            userId: ucOrdersTable.userId,
            dateCreated: ucOrdersTable.dateCreated,
          })
          .from(ucOrdersTable)
          .where(and(
             or(
               and(eq(ucOrdersTable.paymentReference, paymentReference ?? ""), ne(ucOrdersTable.paymentReference, "")),
               eq(ucOrdersTable.checkoutIdempotencyKey, wcCheckoutKey),
             ),
             eq(ucOrdersTable.userId, orderUserId),
            eq(ucOrdersTable.status, "pending-wc"),
          ))
          .limit(1);

        const staleBefore = new Date(Date.now() - WC_PENDING_ANCHOR_MAX_AGE_MS);
        if (pendingAnchor && pendingAnchor.dateCreated <= staleBefore) {
          const staleLookup = await findWcOrderByRef(wcCheckoutKey || paymentReference || "");
          if (staleLookup.status === "found") {
            const normalized = normalizeOrder(staleLookup.order);
            const iConfirmed = await confirmWcAnchor(
              pendingAnchor.id,
              Number(staleLookup.order["id"]),
            );
            if (iConfirmed) {
              sendWcOrderNotifications(normalized, pendingAnchor.userId);
              const pendingOwnerId = Number(pendingAnchor.userId);
              if (pendingOwnerId > 0 && !isNaN(pendingOwnerId)) {
                creditQualifyingProductPoints(pendingOwnerId, pendingAnchor.id).catch((err) => {
                  logger.warn(
                    { err, userId: pendingOwnerId, orderId: pendingAnchor.id },
                    "createOrder (stale WC reconcile): qualifying-product rewards credit failed (non-fatal)",
                  );
                });
              }
            }
            res.json(normalized);
            return;
          }
          if (staleLookup.status === "not_found") {
            const released = await db
              .delete(ucOrdersTable)
              .where(and(
                eq(ucOrdersTable.id, pendingAnchor.id),
                eq(ucOrdersTable.status, "pending-wc"),
                sql`${ucOrdersTable.dateCreated} <= ${staleBefore}`,
              ))
              .returning({ id: ucOrdersTable.id });
            if (released.length > 0) {
              pendingAnchorId = null;
              pendingAnchorReleased = true;
              logger.info(
                { anchorId: pendingAnchor.id, paymentReference },
                "[orders] released stale WC anchor after confirmed absence",
              );
            }
          }
        }
        if (pendingAnchor && !pendingAnchorReleased) pendingAnchorId = pendingAnchor.id;

        if (pendingAnchorId) {
          wcAnchorId = pendingAnchorId;
          if (paymentReference) {
            const inFlightLookup = await findWcOrderByRef(paymentReference);
            if (inFlightLookup.status === "found") {
              const normalized = normalizeOrder(inFlightLookup.order);
              const iConfirmed = await confirmWcAnchor(
                pendingAnchorId,
                Number(inFlightLookup.order["id"]),
              );
              if (iConfirmed) {
                sendWcOrderNotifications(normalized, pendingAnchor!.userId);
                const pendingOwnerId = Number(pendingAnchor!.userId);
                if (pendingOwnerId > 0 && !isNaN(pendingOwnerId)) {
                  creditQualifyingProductPoints(pendingOwnerId, pendingAnchorId).catch((err) => {
                    logger.warn(
                      { err, userId: pendingOwnerId, orderId: pendingAnchorId },
                      "createOrder (in-flight WC reconcile): qualifying-product rewards credit failed (non-fatal)",
                    );
                  });
                }
              }
              res.json(normalized);
              return;
            }
          }
          // A young anchor belongs to another in-flight request. Never issue
          // a second Woo POST; the owner will confirm it or the caller can
          // safely retry after this bounded hand-off window.
          res.status(503).json({ error: "Order is being processed, please retry shortly", retryable: true });
          return;
        } else try {
          // Atomic insert of anchor + items — if either fails, both roll back.
          const claim = await db.transaction(async (tx) => {
            await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtextextended(${"uc-checkout-key:" + wcCheckoutKey}, 0))`);
            const [claimed] = await tx.select({ id: ucOrdersTable.id, userId: ucOrdersTable.userId })
              .from(ucOrdersTable)
              .where(eq(ucOrdersTable.checkoutIdempotencyKey, wcCheckoutKey))
              .limit(1);
            if (claimed) {
              if (String(claimed.userId) !== String(orderUserId)) throw new CheckoutKeyOwnershipConflict();
              return { anchorId: claimed.id, createdByThisRequest: false, state: "existing" as const };
            }
            const [anchor] = await tx.insert(ucOrdersTable).values({
              userId:           orderUserId,
              status:           "pending-wc",
              total:            String(netTotal),
              currency:         "KES",
              paymentMethod,
             paymentReference: paymentReference || "",
             checkoutIdempotencyKey: wcCheckoutKey,
              promoCode:        promoCode ?? "",
              discountPercent,
              discountAmount,
              shippingAddress:  shippingAddress ?? {},
               codCollectionStatus: paymentMethod === "cod" ? "awaiting_collection" : null,
            }).returning();
            const anchorId = anchor!.id;
            if (productLines.length > 0) {
              await tx.insert(ucOrderItemsTable).values(
                productLines.map(({ productId, name, quantity, subtotal: t }) => ({
                  orderId:   anchorId,
                  productId,
                  name,
                  quantity,
                  total:     String(t),
                }))
              );
            }
            return { anchorId, createdByThisRequest: true, state: "created" as const };
          });
          wcAnchorId = claim.anchorId;
          createdByThisRequest = claim.createdByThisRequest;
          if (!createdByThisRequest) {
            res.status(503).json({ error: "Order is being processed, please retry shortly", retryable: true });
            return;
          }
        } catch (claimErr) {
          if (claimErr instanceof CheckoutKeyOwnershipConflict) {
            res.status(409).json({ error: "Idempotency key is already in use", retryable: false });
            return;
          }
          // DrizzleQueryError wraps the pg error in `.cause`; check both locations.
          const _wcPgCode =
            (claimErr as { code?: string }).code ??
            (claimErr as { cause?: { code?: string } }).cause?.code;
          if (_wcPgCode === "23505") {
            const [winner] = await db
              .select()
              .from(ucOrdersTable)
              .where(and(
                eq(ucOrdersTable.userId, orderUserId),
                eq(ucOrdersTable.checkoutIdempotencyKey, wcCheckoutKey),
              ))
              .limit(1);

            if (winner?.status === "processing") {
              // Confirmed order — return without re-notifying.
              logger.info(
                { orderId: winner.id },
                "[orders] WC idempotency conflict — returning existing confirmed order",
              );
              const winnerItems = await db
                .select()
                .from(ucOrderItemsTable)
                .where(eq(ucOrderItemsTable.orderId, winner.id));
              await reconcileCanonicalPurchaseDualWrite(winner.id, `woo-retry:${winner.id}`);
              res.json({
                id:              winner.id,
                status:          winner.status,
                dateCreated:     winner.dateCreated,
                total:           winner.total,
                currency:        winner.currency,
                paymentMethod:   winner.paymentMethod,
                shippingAddress: winner.shippingAddress ?? {},
                discountPercent: winner.discountPercent,
                discountAmount:  winner.discountAmount,
                promoCode:       winner.promoCode ?? "",
                lineItems:       winnerItems.map(i => ({
                  productId: i.productId,
                  name:      i.name,
                  quantity:  i.quantity,
                  total:     i.total,
                })),
              });
              return;
            }

            if (winner?.status === "pending-wc") {
              // Another request still owns this anchor, or stale reconciliation
              // could not confirm absence. Reconcile against WC without deleting
              // on uncertain data.
              const wcLookup = await findWcOrderByRef(wcCheckoutKey || paymentReference || "");
              if (wcLookup.status === "found") {
                // WC has the order — atomically claim the confirmation.
                // Only the request that wins the status transition sends
                // notifications; concurrent requests skip them and return.
                // Use the anchor's persisted userId (winner.userId), NOT the
                // retry caller's identity, to correctly address the customer.
                const normalized = normalizeOrder(wcLookup.order);
                const iConfirmed = await confirmWcAnchor(winner.id, Number(wcLookup.order["id"]));
                if (iConfirmed) {
                  sendWcOrderNotifications(normalized, winner.userId);
                  // Credit qualifying-product reward for this paid WC order
                  const winnerNumericId = Number(winner.userId);
                  if (winnerNumericId > 0 && !isNaN(winnerNumericId)) {
                    creditQualifyingProductPoints(winnerNumericId, winner.id).catch((err) => {
                      logger.warn({ err, userId: winnerNumericId, orderId: winner.id },
                        "createOrder (WC reconcile anchor): qualifying-product rewards credit failed (non-fatal)");
                    });
                  }
                }
                res.json(normalized);
                return;
              }
              // "not_found" for a young anchor may still be an in-flight WC POST;
              // "error" is uncertain. Keep either intact for the next retry.
              res.status(503).json({ error: "Order is being processed, please retry shortly", retryable: true });
              return;
            }
            // The global uniqueness constraint may have been claimed by a
            // different customer. Never fall through to Woo or expose it.
            res.status(409).json({ error: "Idempotency key is already in use", retryable: false });
            return;
          }
          logger.error({ err: claimErr }, "[orders] idempotency claim failed before WC");
          res.status(503).json({ error: "Service temporarily unavailable, please retry", retryable: true });
          return;
        }
      }

      // ── WC pre-flight deduplication check ────────────────────────────────
      // Before POSTing to WooCommerce, query it for an existing order that
      // already carries this payment_reference in meta_data.  This covers the
      // scenario where the DB was briefly unavailable on a prior attempt so the
      // DB guard did not fire, but WC already accepted the order — without this
      // guard a retry would POST a second WC order for the same payment.
      //
      // Tri-state handling:
      //   "found"     → skip POST, confirm anchor, return normalised order.
      //   "not_found" → safe to proceed with POST (WC confirmed no match).
      //   "error"     → fail closed: retain anchor, return retriable 503.
      //                 A WC lookup failure is indistinguishable from "order
      //                 exists but temporarily unreachable" — proceeding would
      //                 risk a duplicate POST.
      if (paymentReference) {
        const wcPreFlight = await findWcOrderByRef(wcCheckoutKey || paymentReference);
        if (wcPreFlight.status === "found") {
          logger.info(
            { paymentReference, wcAnchorId },
            "[orders] WC pre-flight: existing WC order found — skipping POST",
          );
          const normalized = normalizeOrder(wcPreFlight.order);
          if (wcAnchorId !== null) {
            const iConfirmed = await confirmWcAnchor(wcAnchorId, Number(wcPreFlight.order["id"]));
            if (iConfirmed) {
              sendWcOrderNotifications(normalized, orderUserId);
              // Credit qualifying-product reward for this paid WC pre-flight order
              if (orderNumericId > 0 && !isNaN(orderNumericId)) {
                creditQualifyingProductPoints(orderNumericId, wcAnchorId).catch((err) => {
                  logger.warn({ err, userId: orderNumericId, orderId: wcAnchorId },
                    "createOrder (WC pre-flight): qualifying-product rewards credit failed (non-fatal)");
                });
              }
            }
          }
          res.json(normalized);
          return;
        }
        if (wcPreFlight.status === "error") {
          // WC is unreachable — fail closed to prevent a duplicate POST.
          logger.warn(
            { paymentReference, wcAnchorId },
            "[orders] WC pre-flight: lookup failed — failing closed, client should retry",
          );
          res.status(503).json({ error: "Service temporarily unavailable, please retry", retryable: true });
          return;
        }
        // status: "not_found" — WC confirmed no existing order; safe to POST.
      }

      // ── Step 2: Call WooCommerce ─────────────────────────────────────────
      const orderPayload = {
        payment_method: paymentMethod,
        payment_method_title:
          paymentMethod === "mpesa" ? "M-Pesa" :
          paymentMethod === "stripe" ? "Credit Card (Stripe)" :
          paymentMethod === "paystack" ? "Paystack" : "Cash on Delivery",
        set_paid: isPaid,
        shipping: shippingAddress,
        line_items: productLines.map((i) => ({ product_id: i.productId, variation_id: i.variationId || 0, quantity: i.quantity, subtotal: String(i.subtotal), total: String(i.subtotal) })),
        shipping_lines: [{ method_id: fulfillment === "collection" ? "local_pickup" : "flat_rate", method_title: fulfillment === "collection" ? "Free collection" : "Delivery", total: String(delivery) }],
        fee_lines: discountAmount ? [{ name: `Companion ${promoCode || "referral reward"}`, total: String(-discountAmount), taxable: false }] : [],
        meta_data: [
          { key: "payment_reference", value: paymentReference ?? "" },
          ...(wcCheckoutKey ? [{ key: "uc_checkout_key", value: wcCheckoutKey }] : []),
          { key: "promo_code", value: promoCode ?? "" },
          { key: "discount_percent", value: String(discountPercent) },
        ],
        coupon_lines: [],
      };

      let wcOrder: Record<string, unknown> | null = null;
      try {
        const orderRes = await fetch(wcUrl("/orders"), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(orderPayload),
        });
        const parsed: unknown = await orderRes.json();
        if (parsed && typeof parsed === "object" && "id" in parsed) {
          wcOrder = parsed as Record<string, unknown>;
        }
      } catch {
        // WC call threw — attempt reconciliation below.
      }

      // ── Step 3b: Reconcile when WC result is uncertain ───────────────────
      // Uses the targeted meta_key/meta_value query; secondary exact-match scan
      // guards against partial WC filtering.
      // Tri-state: "found" → use reconciled order; "not_found" or "error" →
      // keep anchor intact and return a retriable 503 — both states mean we
      // cannot safely confirm that WC did not create an order.
      if (!wcOrder && wcCheckoutKey) {
        const reconciled = await findWcOrderByRef(wcCheckoutKey);
        if (reconciled.status === "found") {
          wcOrder = reconciled.order;
        } else {
          logger.warn(
            { paymentReference, wcAnchorId, reconcileStatus: reconciled.status },
            "[orders] WC call failed; reconciliation inconclusive — anchor retained; client should retry",
          );
          res.status(503).json({ error: "Service temporarily unavailable, please retry", retryable: true });
          return;
        }
      }

      // A reference-less order (normally COD) cannot be reconciled after an
      // uncertain WooCommerce POST.  Falling through to the local DB path
      // would report success even though the store order was not created (and
      // could create a duplicate when the caller retries), so surface the
      // outage explicitly as retryable.
      if (!wcOrder) {
        logger.warn(
          { paymentMethod, paymentReference },
          "[orders] WooCommerce order creation failed; client should retry",
        );
        res.status(503).json({
          error: "WooCommerce is temporarily unavailable, please retry",
          retryable: true,
        });
        return;
      }

      if (wcOrder) {
        // ── Step 3a: Atomic anchor confirmation ──────────────────────────
        // confirmWcAnchor uses UPDATE WHERE status='pending-wc'; only the
        // request that wins the transition (returns true) sends notifications.
        // Concurrent requests that lose skip notifications and return normally.
        const normalized = normalizeOrder(wcOrder);
        if (wcAnchorId !== null) {
          const iConfirmed = await confirmWcAnchor(wcAnchorId, Number(wcOrder["id"]));
          if (iConfirmed) {
            sendWcOrderNotifications(normalized, orderUserId);
            // Credit qualifying-product reward for this paid WC order (main path)
            if (orderNumericId > 0 && !isNaN(orderNumericId)) {
              creditQualifyingProductPoints(orderNumericId, wcAnchorId).catch((err) => {
                logger.warn({ err, userId: orderNumericId, orderId: wcAnchorId },
                  "createOrder (WC main): qualifying-product rewards credit failed (non-fatal)");
              });
            }
          }
        } else {
          // COD order (no payment reference → no anchor).  There is no
          // concurrent-request race for reference-less orders, so send
          // the confirmation unconditionally whenever WC accepts the order.
          // COD orders are not paid at time of placement — no rewards credit.
          sendWcOrderNotifications(normalized, orderUserId);
        }
        res.json(normalized);
        return;
      }
      // ── WC returned no usable order and reconciliation was skipped ────────
      // (paymentReference was empty / COD — fall through to DB path)
    }
  } catch (error) {
    if (error instanceof CanonicalPurchaseDualWriteError ||
      (error instanceof Error && error.message.includes("Canonical purchase"))) {
      throw error;
    }
    /* fall through to local/mock persistence */
  }

  // Persist order to DB
  try {
    let dbOrder: any;
    if (idempotencyKey?.trim()) {
      // Local-order path: one transaction owns the order, lines and promotion
      // use.  A cap/validation failure rolls all three back.
      // Claiming the key on the order itself (rather than on promotion use)
      // makes COD and concurrent retries idempotent even when no payment
      // reference exists.
      const priorCheckout = await pool.query(
        "SELECT * FROM uc_orders WHERE user_id=$1 AND checkout_idempotency_key=$2 LIMIT 1",
        [orderUserId, idempotencyKey!.trim()],
      );
      if (priorCheckout.rows[0]) {
        const row = priorCheckout.rows[0];
        await reconcileCanonicalPurchaseDualWrite(Number(row.id), `checkout-retry:${row.id}`);
        const priorItems = await pool.query("SELECT * FROM uc_order_items WHERE order_id=$1 ORDER BY id", [row.id]);
        res.json({ id: row.id, status: row.status, dateCreated: row.date_created, total: row.total,
          currency: row.currency, paymentMethod: row.payment_method, shippingAddress: row.shipping_address ?? {},
          discountPercent: row.discount_percent, discountAmount: row.discount_amount, promoCode: row.promo_code ?? "",
          lineItems: priorItems.rows.map((item) => ({ productId: item.product_id, name: item.name, quantity: item.quantity, total: item.total })) });
        return;
      }
      const client = await pool.connect();
      try {
        await client.query("BEGIN");
        const inserted = await client.query(
          `INSERT INTO uc_orders (user_id,status,total,currency,payment_method,payment_reference,promo_code,discount_percent,discount_amount,shipping_address,checkout_idempotency_key,cod_collection_status)
           VALUES ($1,$2,$3,'KES',$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
          [orderUserId, paymentMethod === "cod" ? "pending" : "processing", String(netTotal), paymentMethod, paymentReference ?? "", promoCode ?? "", discountPercent, discountAmount, JSON.stringify(shippingAddress ?? {}), idempotencyKey!.trim(), paymentMethod === "cod" ? "awaiting_collection" : null],
        );
        const insertedOrder = inserted.rows[0];
        // Raw SQL returns snake_case; the shared receipt/notification path
        // below consumes the same camelCase fields as Drizzle-returned orders.
        dbOrder = {
          ...insertedOrder,
          userId: insertedOrder.user_id,
          dateCreated: insertedOrder.date_created,
          paymentMethod: insertedOrder.payment_method,
          paymentReference: insertedOrder.payment_reference,
          paymentConfirmedAt: insertedOrder.payment_confirmed_at,
          codCollectionStatus: insertedOrder.cod_collection_status,
          checkoutState: insertedOrder.checkout_state,
          wcOrderId: insertedOrder.wc_order_id,
          shippingAddress: insertedOrder.shipping_address,
          discountPercent: insertedOrder.discount_percent,
          discountAmount: insertedOrder.discount_amount,
          promoCode: insertedOrder.promo_code,
        };
        const promotionUse = durableCheckoutPromotion ? await consumePromotionOnClient(client, {
          quote: durableCheckoutPromotion, userId: orderNumericId, operation: "checkout",
          actor: `customer:${orderNumericId}`, idempotencyKey: idempotencyKey!.trim(),
        }) : null;
        await claimReferralBenefit(client, pricing.referralBenefitId, orderNumericId, dbOrder.id);
        if (promotionUse?.repeated) {
          const priorOrderId = Number(promotionUse.use.operation_ref);
          const prior = Number.isInteger(priorOrderId)
            ? await client.query("SELECT * FROM uc_orders WHERE id=$1 AND user_id=$2 LIMIT 1", [priorOrderId, orderUserId])
            : { rows: [] };
          if (!prior.rows[0]) {
            throw Object.assign(new Error("The previous checkout could not be recovered"), { code: "INVALID_PROMOTION_RETRY" });
          }
          const priorItems = await client.query("SELECT * FROM uc_order_items WHERE order_id=$1 ORDER BY id", [priorOrderId]);
          await client.query("COMMIT");
          const row = prior.rows[0];
          await reconcileCanonicalPurchaseDualWrite(Number(row.id), `promotion-retry:${row.id}`);
          res.json({
            id: row.id, status: row.status, dateCreated: row.date_created,
            total: row.total, currency: row.currency, paymentMethod: row.payment_method,
            shippingAddress: row.shipping_address ?? {}, discountPercent: row.discount_percent,
            discountAmount: row.discount_amount, promoCode: row.promo_code ?? "",
            lineItems: priorItems.rows.map((item) => ({
              productId: item.product_id, name: item.name, quantity: item.quantity, total: item.total,
            })),
          });
          return;
        }
        for (const line of productLines) await client.query(
          `INSERT INTO uc_order_items (order_id,product_id,name,quantity,total,variation_id,child_sku,variant_label) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
          [dbOrder.id, line.productId, line.name, line.quantity, String(line.subtotal), line.variationId ?? null, line.childSku ?? null, line.variantLabel ?? null],
        );
        await client.query(
          "UPDATE uc_promotion_uses SET operation_ref=$1 WHERE id=$2",
          [String(dbOrder.id), promotionUse?.use.id ?? null],
        );
        await client.query("COMMIT");
      } catch (error) {
        await client.query("ROLLBACK").catch(() => undefined);
        const typed = error as Error & { code?: string };
        // A concurrent request may have committed the order-key claim while
        // this request was waiting on the unique index.  Return that durable
        // result rather than treating the retry as a failed promotion.
        if (typed.code === "23505") {
          const prior = await client.query(
            "SELECT * FROM uc_orders WHERE user_id=$1 AND checkout_idempotency_key=$2 LIMIT 1",
            [orderUserId, idempotencyKey!.trim()],
          );
          if (prior.rows[0]) {
            const row = prior.rows[0];
            const items = await client.query("SELECT * FROM uc_order_items WHERE order_id=$1 ORDER BY id", [row.id]);
            await reconcileCanonicalPurchaseDualWrite(Number(row.id), `promotion-race:${row.id}`);
            res.json({ id: row.id, status: row.status, dateCreated: row.date_created, total: row.total,
              currency: row.currency, paymentMethod: row.payment_method, shippingAddress: row.shipping_address ?? {},
              discountPercent: row.discount_percent, discountAmount: row.discount_amount, promoCode: row.promo_code ?? "",
              lineItems: items.rows.map((item) => ({ productId: item.product_id, name: item.name, quantity: item.quantity, total: item.total })) });
            return;
          }
        }
        res.status(typed.code === "PROMOTION_EXHAUSTED" ? 409 : 422).json({ error: typed.message || "Could not apply promotion" });
        return;
      } finally { client.release(); }
    } else {
      [dbOrder] = await db.insert(ucOrdersTable).values({
      userId:           orderUserId,
      status:           paymentMethod === "cod" ? "pending" : "processing",
       codCollectionStatus: paymentMethod === "cod" ? "awaiting_collection" : null,
      total:            String(netTotal),
      currency:         "KES",
      paymentMethod,
      paymentReference: paymentReference ?? "",
      promoCode:        promoCode ?? "",
      discountPercent,
      discountAmount,
      shippingAddress:  shippingAddress ?? {},
    }).returning();
    }

    // The durable-promotion branch inserted its item rows inside the same
    // transaction as the order and promotion use. Do not duplicate them here.
    if (dbOrder && productLines.length > 0 && !idempotencyKey?.trim()) {
      await db.insert(ucOrderItemsTable).values(
        productLines.map(({ productId, name, quantity, subtotal: t, variationId, childSku, variantLabel }) => ({
          orderId:   dbOrder.id,
          productId,
          name,
          quantity,
          total:     String(t),
          variationId, childSku, variantLabel,
        }))
      );
    }
    if (!hasWCCredentials()) {
      await reconcileCanonicalPurchaseDualWrite(dbOrder!.id, `companion:${dbOrder!.id}`);
    }

    // Credit qualifying-product rewards for paid (non-COD) orders.
    // Fire-and-forget — a credit failure must never block order confirmation.
    // The refId unique index in uc_rewards_ledger ensures idempotency.
    if (orderNumericId > 0 && !isNaN(orderNumericId) && paymentMethod !== "cod") {
      creditQualifyingProductPoints(orderNumericId, dbOrder!.id).catch((err) => {
        logger.warn({ err, userId: orderNumericId, orderId: dbOrder!.id },
          "createOrder: qualifying-product rewards credit failed (non-fatal)");
      });
    }

    // Record referral conversion so the referrer earns credit

    const newOrder = {
      id:              dbOrder!.id,
      status:          dbOrder!.status,
      dateCreated:     dbOrder!.dateCreated,
      total:           dbOrder!.total,
      currency:        dbOrder!.currency,
      paymentMethod:   dbOrder!.paymentMethod,
      paymentStatus:   receiptOrderPaymentStatus(dbOrder!),
      receiptSerial:   orderReceiptSerial(dbOrder!.wcOrderId ?? dbOrder!.id, dbOrder!.dateCreated),
      codCollectionStatus: dbOrder!.codCollectionStatus ?? null,
      shippingAddress: dbOrder!.shippingAddress ?? {},
      discountPercent,
      discountAmount,
      promoCode:       promoCode ?? "",
      lineItems:       productLines.map(({ productId, name, quantity, subtotal: t }) => ({
        productId, name, quantity, total: String(t),
      })),
    };

    sendPushToUser(
      orderUserId,
      "✅ Order confirmed!",
      `Your order #${newOrder.id} is placed and being processed.`,
      { screen: "orders", orderId: String(newOrder.id) },
      "orders"
    );
    // SMS + email confirmations (fire-and-forget)
    sendOrderConfirmationEmail(orderUserId, {
      orderId:         newOrder.id,
      lineItems:       newOrder.lineItems,
      total:           newOrder.total,
      currency:        newOrder.currency,
      paymentMethod:   newOrder.paymentMethod,
      paymentStatus:   receiptOrderPaymentStatus(dbOrder!),
      shippingAddress: newOrder.shippingAddress as Record<string, string> | undefined,
      discountAmount:  newOrder.discountAmount,
      promoCode:       newOrder.promoCode,
      dateCreated:     newOrder.dateCreated,
      paymentReference: dbOrder!.paymentReference ?? "",
    });

    res.json(newOrder);
  } catch (dbErr) {
    // ── Unique-constraint violation (concurrent duplicate request) ────────────
    // Two requests can race through the pre-check and both try to insert.
    // The loser hits Postgres error 23505. Re-read the winner's row and return
    // it without sending any additional notification.
    // DrizzleQueryError wraps the underlying pg error in `.cause`; the Postgres
    // error code "23505" (unique_violation) is therefore at dbErr.cause.code,
    // not dbErr.code.  Check both so the handler fires whether the raw pg error
    // or a Drizzle-wrapped version reaches this catch block.
    const _pgErrCode =
      (dbErr as { code?: string }).code ??
      (dbErr as { cause?: { code?: string } }).cause?.code;
    if (paymentReference && _pgErrCode === "23505") {
      try {
        const [winner] = await db
          .select()
          .from(ucOrdersTable)
          .where(and(
            eq(ucOrdersTable.paymentReference, paymentReference),
            ne(ucOrdersTable.paymentReference, ""),
          ))
          .limit(1);
        if (winner) {
          await reconcileCanonicalPurchaseDualWrite(winner.id, `payment-race:${winner.id}`);
          logger.info(
            { orderId: winner.id },
            "[orders] unique-constraint race resolved — returning existing order without re-notifying",
          );
          const winnerItems = await db
            .select()
            .from(ucOrderItemsTable)
            .where(eq(ucOrderItemsTable.orderId, winner.id));
          res.json({
            id:              winner.id,
            status:          winner.status,
            dateCreated:     winner.dateCreated,
            total:           winner.total,
            currency:        winner.currency,
            paymentMethod:   winner.paymentMethod,
            shippingAddress: winner.shippingAddress ?? {},
            discountPercent: winner.discountPercent,
            discountAmount:  winner.discountAmount,
            promoCode:       winner.promoCode ?? "",
            lineItems:       winnerItems.map(i => ({
              productId: i.productId,
              name:      i.name,
              quantity:  i.quantity,
              total:     i.total,
            })),
          });
          return;
        }
      } catch (rerr) {
        if (rerr instanceof CanonicalPurchaseDualWriteError) throw rerr;
        logger.error({ err: rerr }, "[orders] failed to re-read order after unique-constraint conflict");
      }
    }

    // DB unavailable — fall back to in-memory so the order is not lost in the response
    console.error("[orders] DB insert failed, using fallback:", dbErr);
    const fallbackOrder = {
      id:          Date.now(),
      status:      paymentMethod === "cod" ? "pending" : "processing",
      dateCreated: new Date().toISOString(),
      total:       String(netTotal),
      currency:    "KES",
      userId:      orderUserId,
      lineItems:   productLines.map(({ productId, name, quantity, subtotal: t }) => ({
        productId, name, quantity, total: String(t),
      })),
      paymentMethod,
      shippingAddress: shippingAddress ?? {},
      discountPercent,
      discountAmount,
      promoCode:   promoCode ?? "",
    };
    orderStoreFallback.push(fallbackOrder);
    sendPushToUser(
      orderUserId,
      "✅ Order confirmed!",
      `Your order #${fallbackOrder.id} is placed and being processed.`,
      { screen: "orders", orderId: String(fallbackOrder.id) },
      "orders"
    );
    // SMS + email confirmations (fire-and-forget, fallback path)
    sendOrderConfirmationEmail(orderUserId, {
      orderId:         fallbackOrder.id,
      lineItems:       fallbackOrder.lineItems,
      total:           fallbackOrder.total,
      currency:        fallbackOrder.currency,
      paymentMethod:   fallbackOrder.paymentMethod,
      paymentStatus:   receiptOrderPaymentStatus(fallbackOrder),
      shippingAddress: fallbackOrder.shippingAddress as Record<string, string> | undefined,
      discountAmount:  fallbackOrder.discountAmount,
      promoCode:       fallbackOrder.promoCode,
      dateCreated:     fallbackOrder.dateCreated,
      paymentReference: paymentReference ?? "",
    });
    res.json(fallbackOrder);
  }
});

// ─── Push notification endpoints ─────────────────────────────────────────────

/**
 * POST /api/uc/notify/register
 * Authenticated — stores the caller's Expo push token in the server-side map.
 * The token is keyed by the user ID extracted from the Bearer JWT, so only
 * the authenticated user's own token is ever registered here.
 */
router.post("/uc/notify/register", async (req: Request, res: Response): Promise<void> => {
  const userId = userIdFromBearer(req.headers["authorization"]);
  if (userId === "anonymous") {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  const notifyNumericId = Number(userId);
  if (await guardDeletedAccount(notifyNumericId, res)) return;
  const { pushToken } = req.body as { pushToken?: string };
  if (!pushToken) {
    res.status(400).json({ error: "pushToken required" });
    return;
  }
  try {
    // Check whether this user already has saved notification preferences so we
    // can carry them over into the push token row (handles the case where the
    // user opted out before granting push permission).
    const existingPrefs = await db.query.ucNotifPrefsTable
      .findFirst({ where: eq(ucNotifPrefsTable.userId, userId) })
      .catch(() => null);

    await db
      .insert(ucPushTokensTable)
      .values({
        userId,
        pushToken,
        optOutOrders: existingPrefs?.optOutOrders ?? false,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: ucPushTokensTable.userId,
        set: {
          pushToken,
          // Preserve the opt-out flag from the prefs table if available; otherwise
          // keep whatever was already stored (don't reset an existing opt-out).
          ...(existingPrefs != null ? { optOutOrders: existingPrefs.optOutOrders } : {}),
          updatedAt: new Date(),
        },
      });
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: "Failed to register push token", detail: String(err) });
  }
});

/**
 * DELETE /api/uc/notify/register
 * Authenticated — removes the caller's registered push token so a logged-out
 * (or handed-over) device stops receiving that user's order-update pushes.
 *
 * Device-specific: when the body includes { pushToken }, the row is deleted
 * only if the stored token matches — so logging out on device A never wipes
 * a token that device B registered more recently. When no pushToken is sent
 * (legacy clients / token unavailable), the user's row is deleted regardless.
 * Idempotent: succeeds even when no token row exists.
 */
router.delete("/uc/notify/register", async (req: Request, res: Response): Promise<void> => {
  const userId = userIdFromBearer(req.headers["authorization"]);
  if (userId === "anonymous") {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  const { pushToken } = (req.body ?? {}) as { pushToken?: string };
  try {
    const where = typeof pushToken === "string" && pushToken.length > 0
      ? and(eq(ucPushTokensTable.userId, userId), eq(ucPushTokensTable.pushToken, pushToken))
      : eq(ucPushTokensTable.userId, userId);
    await db.delete(ucPushTokensTable).where(where);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: "Failed to unregister push token", detail: String(err) });
  }
});

/**
 * POST /api/uc/notify/prefs
 * Authenticated — upserts the caller's server-side notification opt-out flags.
 * Works even when no push token has been registered yet: prefs are stored in
 * uc_notif_prefs and synced into uc_push_tokens the next time a token is
 * registered, so user opt-outs are never silently lost.
 * Body: { optOutOrders?: boolean, optOutWaterTests?: boolean, reminderEmail?: boolean,
 *         reminderSms?: boolean, reminderWhatsapp?: boolean }
 * The reminder* flags are the OPT-IN switches for filter-reminder delivery
 * via external channels (email / SMS / WhatsApp) — only provided keys are
 * updated, so toggling one channel never clobbers the others.
 */
router.post("/uc/notify/prefs", async (req: Request, res: Response): Promise<void> => {
  const userId = userIdFromBearer(req.headers["authorization"]);
  if (userId === "anonymous") {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  const prefsNumericId = Number(userId);
  if (await guardDeletedAccount(prefsNumericId, res)) return;
  const { optOutOrders, optOutWaterTests, reminderEmail, reminderSms, reminderWhatsapp } = req.body as {
    optOutOrders?: boolean;
    optOutWaterTests?: boolean;
    reminderEmail?: boolean;
    reminderSms?: boolean;
    reminderWhatsapp?: boolean;
  };
  const value = optOutOrders ?? false;
  const waterTestValue = optOutWaterTests ?? false;
  // Only include reminder flags that were explicitly provided (and boolean).
  const reminderSet: Partial<{
    reminderEmail: boolean; reminderSms: boolean; reminderWhatsapp: boolean;
  }> = {};
  if (typeof reminderEmail === "boolean") reminderSet.reminderEmail = reminderEmail;
  if (typeof reminderSms === "boolean") reminderSet.reminderSms = reminderSms;
  if (typeof reminderWhatsapp === "boolean") reminderSet.reminderWhatsapp = reminderWhatsapp;
  try {
    // Upsert into the dedicated prefs table — always works, even without a push token row.
    await db
      .insert(ucNotifPrefsTable)
      .values({ userId, optOutOrders: value, optOutWaterTests: waterTestValue, ...reminderSet, updatedAt: new Date() })
      .onConflictDoUpdate({
        target: ucNotifPrefsTable.userId,
        set: {
          ...(optOutOrders !== undefined ? { optOutOrders: value } : {}),
          ...(optOutWaterTests !== undefined ? { optOutWaterTests: waterTestValue } : {}),
          ...reminderSet,
          updatedAt: new Date(),
        },
      });
    // Best-effort: also sync to the push token row if one exists so sendPushToUser
    // can use a single-table lookup.
    await db
      .update(ucPushTokensTable)
      .set({ optOutOrders: value })
      .where(eq(ucPushTokensTable.userId, userId));
    res.json({ ok: true, created: true });
  } catch (err) {
    res.status(500).json({ error: "Failed to update preferences", detail: String(err) });
  }
});

/**
 * GET /api/uc/notify/prefs
 * Authenticated — returns the caller's server-side notification preferences,
 * including the opt-in flags for filter-reminder delivery via external
 * channels. Missing row = all defaults (opted out of nothing, no channels).
 */
router.get("/uc/notify/prefs", async (req: Request, res: Response): Promise<void> => {
  const userId = userIdFromBearer(req.headers["authorization"]);
  if (userId === "anonymous") {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  const prefsNumericId = Number(userId);
  if (await guardDeletedAccount(prefsNumericId, res)) return;
  try {
    const [row] = await db
      .select()
      .from(ucNotifPrefsTable)
      .where(eq(ucNotifPrefsTable.userId, userId))
      .limit(1);
    res.json({
      optOutOrders:     row?.optOutOrders     ?? false,
      optOutWaterTests: row?.optOutWaterTests ?? false,
      reminderEmail:    row?.reminderEmail    ?? false,
      reminderSms:      row?.reminderSms      ?? false,
      reminderWhatsapp: row?.reminderWhatsapp ?? false,
    });
  } catch (err) {
    res.status(500).json({ error: "Failed to load preferences", detail: String(err) });
  }
});

/**
 * POST /api/uc/notify
 * Authenticated — sends a push notification to the authenticated user's
 * registered device.  The server resolves the recipient token from the
 * registered store; clients never supply a raw destination token.
 *
 * Body: { title: string, body?: string, data?: object }
 */
router.post("/uc/notify", async (req: Request, res: Response): Promise<void> => {
  // Require authentication — no unauthenticated push relay
  const userId = userIdFromBearer(req.headers["authorization"]);
  if (userId === "anonymous") {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const tokenRow = await getPushTokenRow(userId);
  if (!tokenRow) {
    res.status(404).json({ error: "No push token registered for this account" });
    return;
  }
  const token = tokenRow.pushToken;

  const { title, body, data } = req.body as {
    title?: string;
    body?: string;
    data?: Record<string, unknown>;
  };
  if (!title) {
    res.status(400).json({ error: "title is required" });
    return;
  }

  try {
    const { staleToken } = await callExpoPushApi(token, title, body ?? "", data ?? {});
    if (staleToken) {
      await removePushToken(userId);
      res.status(410).json({ error: "Push token is no longer valid — device has unregistered" });
      return;
    }
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: "Push notification failed", detail: String(err) });
  }
});

// ─── Enquiries ────────────────────────────────────────────────────────────────

// ─── Office notifications ─────────────────────────────────────────────────────

/** Official office inbox for all customer form submissions. */
const OFFICE_EMAIL  = "sales@ucfilters.com";

// ─── Team alert email (DB-backed, 60 s cache) ─────────────────────────────────
// The DB value supersedes the TEAM_ALERT_EMAIL env var, which in turn supersedes
// the hardcoded fallback.  Same pattern as getTeamAlertPhone in payments.ts.

interface _EmailSecretCache { value: string; expiresAt: number }
let _teamAlertEmailCache: _EmailSecretCache | null = null;

/** Resolve the configured recipient without reading process or database state. */
export function resolveTeamAlertEmail(
  databaseValue: string | null | undefined,
  environmentValue: string | undefined,
): string {
  return databaseValue?.trim() || environmentValue?.trim() || "info@ucfilters.com";
}

/**
 * Resolve the team alert email address.
 * Priority: DB (team_settings.team_alert_email) → TEAM_ALERT_EMAIL env var → info@ucfilters.com
 * Result is cached for 60 seconds to keep DB cost negligible.
 */
export async function getTeamAlertEmail(): Promise<string> {
  const now = Date.now();
  if (_teamAlertEmailCache && _teamAlertEmailCache.expiresAt > now) {
    return _teamAlertEmailCache.value;
  }

  let databaseValue: string | null = null;

  try {
    const [row] = await db
      .select({ teamAlertEmail: teamSettingsTable.teamAlertEmail })
      .from(teamSettingsTable)
      .where(eq(teamSettingsTable.id, "singleton"))
      .limit(1);

    if (row?.teamAlertEmail) {
      databaseValue = row.teamAlertEmail;
    }
  } catch (err) {
    console.error("[uc] DB read for team alert email failed — falling back to env var:", err);
  }

  const value = resolveTeamAlertEmail(databaseValue, process.env["TEAM_ALERT_EMAIL"]);

  _teamAlertEmailCache = { value, expiresAt: now + 60_000 };
  return value;
}

export function invalidateTeamAlertEmailCache(): void {
  _teamAlertEmailCache = null;
}

/**
 * Recipient for account-deletion team alerts.
 * Delegates to getTeamAlertEmail() — DB setting → TEAM_ALERT_EMAIL env var → info@ucfilters.com.
 * @internal Exported for unit tests.
 */
export async function accountDeletionAlertRecipient(): Promise<string> {
  return getTeamAlertEmail();
}

type AccountDeletionNotifierDeps = {
  resendSender?: typeof sendViaResend;
  fallbackSender?: typeof sendEmail;
  slackSender?: typeof sendSlackTeamMessage;
  warn?: (details: Record<string, unknown>, message: string) => void;
};

/**
 * Best-effort team alert for completed account deletions.
 * Resend returns false for ordinary delivery failures, so that result must be
 * handled explicitly before trying the secondary email chain. Never throws:
 * notification delivery must not undo a completed erasure.
 *
 * @internal Exported for focused failure-path tests.
 */
export async function notifyTeamAccountDeletion(
  userId: number,
  deletedAt: string,
  recipient: string,
  deps: AccountDeletionNotifierDeps = {},
): Promise<void> {
  const resendSender = deps.resendSender ?? sendViaResend;
  const fallbackSender = deps.fallbackSender ?? sendEmail;
  const slackSender = deps.slackSender ?? sendSlackTeamMessage;
  const warn = deps.warn ?? ((details, message) => logger.warn(details, message));
  const subject = `Account deleted — user #${userId}`;
  const text = [
    "A customer has exercised their right to erasure.",
    "",
    `User ID   : ${userId}`,
    `Deleted at: ${deletedAt} (UTC)`,
    "",
    "All personal data has been anonymised. No action is required unless",
    "a dispute or order investigation is in progress for this account.",
  ].join("\n");
  const html = [
    "<p>A customer has exercised their right to erasure.</p>",
    "<ul>",
    `<li><strong>User ID:</strong> ${userId}</li>`,
    `<li><strong>Deleted at:</strong> ${deletedAt} (UTC)</li>`,
    "</ul>",
    "<p>All personal data has been anonymised. No action is required unless",
    "a dispute or order investigation is in progress for this account.</p>",
  ].join("\n");

  try {
    const sent = await resendSender({
      from: "Ultra Clear App <noreply@contacts.ucfilters.com>",
      to: recipient,
      subject,
      text,
      html,
      meta: { template: "account_deleted" },
    });
    if (sent) return;

    warn(
      { userId, provider: "resend" },
      "Account-deletion team notification not sent via Resend — trying SendGrid/SMTP fallback",
    );
    const fallbackSent = await fallbackSender({
      to: recipient,
      subject,
      text,
      html,
      template: "account_deleted",
    });
    if (fallbackSent) return;

    warn(
      { userId, provider: "sendgrid/smtp" },
      "Account-deletion team notification not delivered by any email provider — trying Slack fallback",
    );
    const slackSent = await slackSender(
      `Account deleted — user #${userId}\nDeleted at: ${deletedAt} (UTC)\nNo customer PII is included.`,
      "account_deleted",
    );
    if (slackSent) return;

    warn(
      { userId, provider: "slack" },
      "Account-deletion team notification not delivered by any provider",
    );
  } catch (err) {
    warn({ err, userId }, "Account-deletion team notification failed unexpectedly");
  }
}
const SERVICE_EMAIL = "service@ucfilters.com";

/**
 * Append a form submission record to a local JSONL file as a durable backup.
 * One JSON object per line — safe to append concurrently. Fire-and-forget.
 */
async function appendToLocalStore(filename: string, record: Record<string, unknown>): Promise<void> {
  try {
    await appendFile(join(UC_DATA_DIR, filename), JSON.stringify(record) + "\n", "utf8");
  } catch (err) {
    console.error(`[local-store] append to ${filename} failed:`, err instanceof Error ? err.message : err);
  }
}

/**
 * Send a plain-text notification to service@ucfilters.com — same delivery chain
 * as notifyOffice (Resend → SendGrid/SMTP fallback). Fire-and-forget; never throws.
 */
async function notifyService(subject: string, lines: string[], meta?: { testId?: string; ticketId?: string; orderId?: number | string }): Promise<void> {
  const text = lines.join("\n");
  const sent = await sendViaResend({
    from: "Ultra Clear App <noreply@contacts.ucfilters.com>",
    to:   SERVICE_EMAIL,
    subject,
    text,
    meta: { template: "service_notification" },
  });
  if (sent) return;
  console.error(`[service-notify] Resend unavailable for "${subject}" — falling back`);
  sendEmail({
    to: SERVICE_EMAIL, subject, text,
    html: `<pre style="font-family:monospace">${escapeHtml(text)}</pre>`,
    template: "service_notification",
    testId:   meta?.testId,
    ticketId: meta?.ticketId,
    orderId:  meta?.orderId != null ? Number(meta.orderId) : undefined,
  }).catch(err =>
    console.error(`[service-notify] email failed for "${subject}":`, err instanceof Error ? err.message : err),
  );
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g,  "&amp;")
    .replace(/</g,  "&lt;")
    .replace(/>/g,  "&gt;")
    .replace(/"/g,  "&quot;")
    .replace(/'/g,  "&#x27;");
}

/**
 * Send a plain-text form-submission email to the office inbox (sales@ucfilters.com).
 * Prefers Resend (Replit connector, or direct API when RESEND_API_KEY /
 * RESEND_BASE_URL is set); falls back to the SendGrid/SMTP chain in lib/email
 * when Resend delivery fails. Fire-and-forget — never throws. Logs only the subject/request id,
 * never the form payload (it contains customer PII; the submission itself is
 * already persisted in the database).
 */
export async function notifyOffice(subject: string, lines: string[], meta?: { testId?: string; ticketId?: string; orderId?: number | string }): Promise<void> {
  const text = lines.join("\n");
  const sent = await sendViaResend({
    from: "Ultra Clear App <noreply@contacts.ucfilters.com>",
    to: OFFICE_EMAIL,
    subject,
    text,
    meta: { template: "office_notification" },
  });
  if (sent) return;
  console.error(`[office-notify] Resend unavailable for "${subject}" — falling back to SendGrid/SMTP`);
  sendSlackTeamMessage(
    `⚠️ *Office email delivery failed*\nResend could not deliver: *${subject}*\nThe legacy email provider is being attempted.`,
    "OFFICE_NOTIFICATION_RESEND_FAILURE",
  ).catch(() => {});
  try {
    await sendEmail({
      to: OFFICE_EMAIL,
      subject,
      text,
      html: `<pre style="font-family:monospace">${escapeHtml(text)}</pre>`,
      template: "office_notification",
      testId:   meta?.testId,
      ticketId: meta?.ticketId,
      orderId:  meta?.orderId != null ? Number(meta.orderId) : undefined,
    });
  } catch (err) {
    console.error(`[office-notify] email failed for "${subject}":`, err instanceof Error ? err.message : err);
  }
}

/**
 * Send a plain-text notification email to info@ucfilters.com via Resend
 * (Replit connector or direct API). Fire-and-forget — the submission itself
 * is persisted in the database regardless of email delivery.
 */
async function sendEnquiryEmail(enquiry: {
  productName: string;
  name: string;
  email: string;
  phone: string;
  message: string;
}): Promise<void> {
  const sent = await sendViaResend({
    from: "Ultra Clear App <noreply@contacts.ucfilters.com>",
    to: "info@ucfilters.com",
    subject: `New Enquiry: ${enquiry.productName}`,
    text: [
      `Product: ${enquiry.productName}`,
      `Name:    ${enquiry.name}`,
      `Email:   ${enquiry.email}`,
      `Phone:   ${enquiry.phone}`,
      "",
      enquiry.message,
    ].join("\n"),
    meta: { template: "product_enquiry" },
  });
  if (sent) return;
  console.error(`[enquiry] Resend unavailable for "${enquiry.productName}" — falling back to SendGrid/SMTP`);
  try {
    const text = [
      `Product: ${enquiry.productName}`,
      `Name:    ${enquiry.name}`,
      `Email:   ${enquiry.email}`,
      `Phone:   ${enquiry.phone}`,
      "",
      enquiry.message,
    ].join("\n");
    await sendEmail({
      to: "info@ucfilters.com",
      subject: `New Enquiry: ${enquiry.productName}`,
      text,
      html: `<pre style="font-family:monospace">${escapeHtml(text)}</pre>`,
      template: "product_enquiry",
    });
  } catch (err) {
    console.error(`[enquiry] email failed for "${enquiry.productName}":`, err instanceof Error ? err.message : err);
  }
}

/** In-memory fallback when the DB insert fails (e.g. table not yet created). */
const enquiryStoreFallback: Record<string, unknown>[] = [];

router.post("/uc/enquiries", async (req: Request, res: Response): Promise<void> => {
  const { productId, productName, name, email, phone, message } = req.body as {
    productId?: number;
    productName?: string;
    name?: string;
    email?: string;
    phone?: string;
    message?: string;
  };
  if (!productId || !productName || !name || !email || !phone || !message) {
    res.status(400).json({ error: "All fields are required" });
    return;
  }

  const userId = userIdFromBearer(req.headers["authorization"]);
  // Reject deleted accounts — guest enquiries (userId === "anonymous") are allowed.
  if (userId !== "anonymous") {
    if (await guardDeletedAccount(Number(userId), res)) return;
  }

  try {
    await db.insert(ucEnquiriesTable).values({
      userId: userId === "anonymous" ? null : userId,
      productId: String(productId),
      productName,
      name,
      email,
      phone,
      message,
    });
  } catch {
    // DB not yet available — store in memory so we don't lose the lead
    enquiryStoreFallback.push({
      productId, productName, name, email, phone, message,
      createdAt: new Date().toISOString(),
    });
  }

  // Fire-and-forget email notification
  sendEnquiryEmail({ productName, name, email, phone, message }).catch(() => {});

  res.status(201).json({
    ok: true,
    message: "Enquiry received. We'll be in touch within 24 hours.",
  });
});

// ─── Locations ────────────────────────────────────────────────────────────────
// Location discovery is intentionally sourced only from the managed table.  A
// location is not public until a staff member has explicitly verified it.
const LOCATION_TYPES = new Set(["experience_centre", "refill_atm", "vendor", "water_atm", "refill_station", "city_tap"]);
type LocationInput = {
  type: string; name: string; address: string; latitude: number; longitude: number;
  hours: string; phone: string | null; vendorName: string | null; countryIso?: string;
  city?: string | null; accessNotes?: string | null; municipal?: string | null; sourceAttribution?: string | null;
  lastFieldVerifiedOn?: string | null; nextReviewOn?: string | null;
};

export function locationInput(body: unknown, partial = false): LocationInput | null {
  if (!body || typeof body !== "object" || Array.isArray(body)) return null;
  const source = body as Record<string, unknown>;
  const editable = new Set(["active", "type", "name", "address", "latitude", "lat", "longitude", "lng", "hours", "phone", "vendorName", "countryIso", "city", "accessNotes", "municipal", "sourceAttribution", "lastFieldVerifiedOn", "nextReviewOn"]);
  if (partial && (!Object.keys(source).some((key) => editable.has(key)) ||
      Object.keys(source).some((key) => !editable.has(key)))) return null;
  const text = (field: string, required = false): string | null => {
    const value = source[field];
    if (value === undefined && partial) return null;
    if (typeof value !== "string") return null;
    const result = value.trim().slice(0, 500);
    return required && !result ? null : result;
  };
  const type = text("type", !partial);
  const name = text("name", !partial);
  const address = text("address", !partial);
  const hours = text("hours", !partial);
  const latRaw = source["latitude"] !== undefined ? source["latitude"] : source["lat"];
  const lngRaw = source["longitude"] !== undefined ? source["longitude"] : source["lng"];
  const invalidCoordinateValue = (value: unknown) =>
    value !== undefined && (value === null || (typeof value === "string" && value.trim() === ""));
  const latitude = latRaw === undefined && partial ? NaN : Number(latRaw);
  const longitude = lngRaw === undefined && partial ? NaN : Number(lngRaw);
  const phoneValue = text("phone");
  const vendorValue = text("vendorName");
  const countryValue = text("countryIso");
  const cityValue = text("city");
  const accessNotesValue = text("accessNotes");
  const municipalValue = text("municipal");
  const sourceValue = text("sourceAttribution");
  const fieldCheckValue = text("lastFieldVerifiedOn");
  const nextReviewValue = text("nextReviewOn");
  const calendarDate = (value: string | null) => {
    if (value === null || value === "") return true;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const parsed = new Date(`${value}T00:00:00Z`);
    return !Number.isNaN(parsed.valueOf()) && parsed.toISOString().slice(0, 10) === value;
  };
  const normalizedCountry = countryValue === null ? null : countryValue.toUpperCase();
  if ((type !== null && type !== "" && !LOCATION_TYPES.has(type)) ||
      (!partial && (name === null || address === null || hours === null)) ||
      (partial && (source["type"] !== undefined && (!type || type.length === 0)) ||
        (source["name"] !== undefined && (!name || name.length === 0)) ||
        (source["address"] !== undefined && (!address || address.length === 0)) ||
        (source["hours"] !== undefined && (!hours || hours.length === 0))) ||
      (!partial && (!Number.isFinite(latitude) || !Number.isFinite(longitude))) ||
       (partial && ((latRaw !== undefined && (invalidCoordinateValue(latRaw) || !Number.isFinite(latitude))) ||
         (lngRaw !== undefined && (invalidCoordinateValue(lngRaw) || !Number.isFinite(longitude))))) ||
      (Number.isFinite(latitude) && (latitude < -90 || latitude > 90)) ||
       (Number.isFinite(longitude) && (longitude < -180 || longitude > 180)) ||
       (normalizedCountry !== null && !/^[A-Z]{2}$/.test(normalizedCountry)) ||
       (cityValue !== null && cityValue.length > 120) ||
       (accessNotesValue !== null && accessNotesValue.length > 1000) ||
       (municipalValue !== null && municipalValue.length > 200) ||
       (sourceValue !== null && sourceValue.length > 500) ||
       !calendarDate(fieldCheckValue) || !calendarDate(nextReviewValue) ||
       (fieldCheckValue && nextReviewValue && nextReviewValue < fieldCheckValue)) return null;
  return {
    type: type ?? "", name: name ?? "", address: address ?? "", latitude, longitude, hours: hours ?? "",
    phone: phoneValue === null || phoneValue === "" ? null : phoneValue,
    vendorName: vendorValue === null || vendorValue === "" ? null : vendorValue,
    ...(source["countryIso"] !== undefined ? { countryIso: normalizedCountry ?? "" } : {}),
    ...(source["city"] !== undefined ? { city: cityValue } : {}),
    ...(source["accessNotes"] !== undefined ? { accessNotes: accessNotesValue } : {}),
    ...(source["municipal"] !== undefined ? { municipal: municipalValue } : {}),
    ...(source["sourceAttribution"] !== undefined ? { sourceAttribution: sourceValue } : {}),
    ...(source["lastFieldVerifiedOn"] !== undefined ? { lastFieldVerifiedOn: fieldCheckValue || null } : {}),
    ...(source["nextReviewOn"] !== undefined ? { nextReviewOn: nextReviewValue || null } : {}),
  };
}
function cityTapMetadataValid(input: LocationInput): boolean {
  return input.type !== "city_tap" || (
    !!input.countryIso && /^[A-Z]{2}$/.test(input.countryIso) &&
    !!input.city?.trim() && !!input.accessNotes?.trim() &&
    !!input.municipal?.trim() && !!input.sourceAttribution?.trim()
  );
}

function publicLocation(row: typeof ucLocationsTable.$inferSelect) {
  return {
    id: row.id, type: row.type, name: row.name, address: row.address,
    lat: Number(row.latitude), lng: Number(row.longitude), hours: row.hours,
    phone: row.phone, vendorName: row.vendorName,
    countryIso: row.countryIso, city: row.city, accessNotes: row.accessNotes,
    municipal: row.municipal, sourceAttribution: row.sourceAttribution,
    lastFieldVerifiedOn: row.lastFieldVerifiedOn,
  };
}

async function locationActor(req: Request): Promise<string> {
  const claims = verifyToken(req.headers["authorization"]);
  if (!claims) return "admin:unknown";
  if (claims.type === "team-session" && typeof claims.id === "string") {
    const [team] = await db.select({ email: teamUsersTable.email }).from(teamUsersTable)
      .where(eq(teamUsersTable.id, claims.id)).limit(1);
    if (team) return team.email.toLowerCase();
  }
  const id = Number(claims.id);
  if (Number.isInteger(id) && id > 0 && id < 1_000_000_000) {
    const [user] = await db.select({ email: ucUsersTable.email }).from(ucUsersTable)
      .where(eq(ucUsersTable.id, id)).limit(1);
    if (user) return user.email.toLowerCase();
  }
  return "admin:unknown";
}

router.get("/uc/locations", async (_req: Request, res: Response): Promise<void> => {
  try {
    const locations = await db.select().from(ucLocationsTable)
      .where(and(eq(ucLocationsTable.active, true), eq(ucLocationsTable.verified, true)))
      .orderBy(asc(ucLocationsTable.name));
    res.json(locations.map(publicLocation));
  } catch (err) {
    logger.error({ err }, "Unable to list public locations");
    res.status(503).json({ error: "Locations are temporarily unavailable" });
  }
});

router.get("/uc/admin/locations", async (req: Request, res: Response): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) { res.status(403).json({ error: "Admin access required" }); return; }
  const locations = await db.select().from(ucLocationsTable).orderBy(asc(ucLocationsTable.name));
  res.json({ locations });
});

router.post("/uc/admin/locations", async (req: Request, res: Response): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) { res.status(403).json({ error: "Admin access required" }); return; }
  const input = locationInput(req.body);
  if (!input || !cityTapMetadataValid(input)) { res.status(400).json({ error: "Valid location fields and city_tap metadata are required" }); return; }
  const actor = await locationActor(req);
  const [location] = await db.insert(ucLocationsTable).values({
    id: randomUUID(), ...input, latitude: String(input.latitude), longitude: String(input.longitude),
    active: true, verified: false, createdBy: actor,
  }).returning();
  res.status(201).json({ location });
});

router.patch("/uc/admin/locations/:id", async (req: Request, res: Response): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) { res.status(403).json({ error: "Admin access required" }); return; }
  const locationId = Array.isArray(req.params["id"]) ? req.params["id"][0] : req.params["id"];
  if (!locationId) { res.status(400).json({ error: "Invalid location id" }); return; }
  const existing = await db.select().from(ucLocationsTable).where(eq(ucLocationsTable.id, locationId)).limit(1);
  if (!existing[0]) { res.status(404).json({ error: "Location not found" }); return; }
  const source = req.body && typeof req.body === "object" && !Array.isArray(req.body)
    ? req.body as Record<string, unknown>
    : null;
  if (!source || Object.keys(source).length === 0) {
    res.status(400).json({ code: "LOCATION_UPDATE_EMPTY", error: "Provide at least one location field to update." });
    return;
  }
  if (source["active"] !== undefined && typeof source["active"] !== "boolean") {
    res.status(400).json({ code: "LOCATION_ACTIVE_INVALID", error: "active must be a boolean." });
    return;
  }
  const input = locationInput(source, true);
  if (!input) {
    res.status(400).json({ code: "LOCATION_UPDATE_INVALID", error: "Provide valid location fields to update." });
    return;
  }
  const mergedLastFieldVerifiedOn = source["lastFieldVerifiedOn"] === undefined
    ? existing[0].lastFieldVerifiedOn
    : input.lastFieldVerifiedOn;
  const mergedNextReviewOn = source["nextReviewOn"] === undefined
    ? existing[0].nextReviewOn
    : input.nextReviewOn;
  if (mergedLastFieldVerifiedOn && mergedNextReviewOn && mergedNextReviewOn < mergedLastFieldVerifiedOn) {
    res.status(400).json({
      code: "LOCATION_REVIEW_DATES_INVALID",
      error: "nextReviewOn cannot be earlier than lastFieldVerifiedOn.",
    });
    return;
  }
  const mergedInput = { ...existing[0], ...input, type: source["type"] === undefined ? existing[0].type : input.type };
  if (!cityTapMetadataValid({
    ...input, type: String(mergedInput.type), countryIso: source["countryIso"] === undefined ? existing[0].countryIso : input.countryIso,
    city: source["city"] === undefined ? existing[0].city : input.city,
    accessNotes: source["accessNotes"] === undefined ? existing[0].accessNotes : input.accessNotes,
    municipal: source["municipal"] === undefined ? existing[0].municipal : input.municipal,
    sourceAttribution: source["sourceAttribution"] === undefined ? existing[0].sourceAttribution : input.sourceAttribution,
  })) {
    res.status(400).json({ code: "LOCATION_CITY_TAP_METADATA_REQUIRED", error: "city_tap requires countryIso, city, accessNotes, municipal, and sourceAttribution." });
    return;
  }
  const identityChanged =
    (source["type"] !== undefined && input.type !== existing[0].type) ||
    (source["name"] !== undefined && input.name !== existing[0].name) ||
    (source["address"] !== undefined && input.address !== existing[0].address) ||
    (source["vendorName"] !== undefined && input.vendorName !== existing[0].vendorName) ||
    ((source["latitude"] !== undefined || source["lat"] !== undefined) &&
      input.latitude !== Number(existing[0].latitude)) ||
    ((source["longitude"] !== undefined || source["lng"] !== undefined) &&
      input.longitude !== Number(existing[0].longitude));
  const updates: Record<string, unknown> = { updatedAt: new Date() };
  if (source["type"] !== undefined) updates["type"] = input.type;
  if (source["name"] !== undefined) updates["name"] = input.name;
  if (source["address"] !== undefined) updates["address"] = input.address;
  if (source["hours"] !== undefined) updates["hours"] = input.hours;
  if (source["phone"] !== undefined) updates["phone"] = input.phone;
  if (source["vendorName"] !== undefined) updates["vendorName"] = input.vendorName;
  if (source["countryIso"] !== undefined) updates["countryIso"] = input.countryIso;
  if (source["city"] !== undefined) updates["city"] = input.city;
  if (source["accessNotes"] !== undefined) updates["accessNotes"] = input.accessNotes;
  if (source["municipal"] !== undefined) updates["municipal"] = input.municipal;
  if (source["sourceAttribution"] !== undefined) updates["sourceAttribution"] = input.sourceAttribution;
  if (source["lastFieldVerifiedOn"] !== undefined) updates["lastFieldVerifiedOn"] = input.lastFieldVerifiedOn;
  if (source["nextReviewOn"] !== undefined) updates["nextReviewOn"] = input.nextReviewOn;
  if (source["latitude"] !== undefined || source["lat"] !== undefined) updates["latitude"] = String(input.latitude);
  if (source["longitude"] !== undefined || source["lng"] !== undefined) updates["longitude"] = String(input.longitude);
  if (source["active"] !== undefined) {
    if (typeof source["active"] !== "boolean") { res.status(400).json({ error: "active must be a boolean" }); return; }
    updates["active"] = source["active"];
  }
  if (identityChanged) Object.assign(updates, { verified: false, verifiedBy: null, verifiedAt: null });
  const [location] = await db.update(ucLocationsTable).set(updates).where(eq(ucLocationsTable.id, existing[0].id)).returning();
  res.json({ location, verificationReset: identityChanged });
});

router.post("/uc/admin/locations/:id/verify", async (req: Request, res: Response): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) { res.status(403).json({ error: "Admin access required" }); return; }
  const locationId = Array.isArray(req.params["id"]) ? req.params["id"][0] : req.params["id"];
  if (!locationId) { res.status(400).json({ error: "Invalid location id" }); return; }
  const [location] = await db.update(ucLocationsTable).set({
    verified: true, verifiedBy: await locationActor(req), verifiedAt: new Date(), updatedAt: new Date(),
  }).where(eq(ucLocationsTable.id, locationId)).returning();
  if (!location) { res.status(404).json({ error: "Location not found" }); return; }
  res.json({ location });
});

// ─── Managed location quality (community observations, separate from tests) ───
const RATING_FIELDS = ["waterQuality", "cleanliness", "equipmentCondition", "serviceReliability", "safetyConfidence"] as const;
const REPORT_REASONS = new Set(["spam", "unsafe", "inaccurate", "offensive", "other"]);
function qualityInput(body: unknown): Record<string, number> | null {
  if (!body || typeof body !== "object" || Array.isArray(body)) return null;
  const out: Record<string, number> = {};
  for (const key of RATING_FIELDS) {
    const value = (body as Record<string, unknown>)[key];
    if (!Number.isInteger(value) || Number(value) < 1 || Number(value) > 5) return null;
    out[key] = Number(value);
  }
  return out;
}
function qualityUserId(req: Request): number | null {
  const id = Number(userIdFromBearer(req.headers["authorization"]));
  return Number.isInteger(id) && id > 0 && id < 1_000_000_000 ? id : null;
}
async function activeQualityUser(req: Request): Promise<number | null> {
  const id = qualityUserId(req);
  if (!id) return null;
  const [user] = await db.select({ id: ucUsersTable.id }).from(ucUsersTable)
    .where(and(eq(ucUsersTable.id, id), isNull(ucUsersTable.deletedAt))).limit(1);
  return user?.id ?? null;
}

router.get("/uc/locations/:id/ratings", async (req: Request, res: Response): Promise<void> => {
  const locationId = String(req.params["id"] ?? "");
  const page = Math.max(1, Number.parseInt(String(req.query["page"] ?? "1"), 10) || 1);
  const limit = Math.min(50, Math.max(1, Number.parseInt(String(req.query["limit"] ?? "20"), 10) || 20));
  const [aggregate] = await db.select({
    count: sql<number>`count(*)::int`,
    waterQuality: sql<number>`round(avg(${ucLocationRatingsTable.waterQuality})::numeric, 1)`,
    cleanliness: sql<number>`round(avg(${ucLocationRatingsTable.cleanliness})::numeric, 1)`,
    equipmentCondition: sql<number>`round(avg(${ucLocationRatingsTable.equipmentCondition})::numeric, 1)`,
    serviceReliability: sql<number>`round(avg(${ucLocationRatingsTable.serviceReliability})::numeric, 1)`,
    safetyConfidence: sql<number>`round(avg(${ucLocationRatingsTable.safetyConfidence})::numeric, 1)`,
  }).from(ucLocationRatingsTable).where(and(eq(ucLocationRatingsTable.locationId, locationId), eq(ucLocationRatingsTable.status, "published")));
  const ratings = await db.select({
    id: ucLocationRatingsTable.id,
    waterQuality: ucLocationRatingsTable.waterQuality,
    cleanliness: ucLocationRatingsTable.cleanliness,
    equipmentCondition: ucLocationRatingsTable.equipmentCondition,
    serviceReliability: ucLocationRatingsTable.serviceReliability,
    safetyConfidence: ucLocationRatingsTable.safetyConfidence,
    comment: ucLocationRatingsTable.comment,
    createdAt: ucLocationRatingsTable.createdAt,
    updatedAt: ucLocationRatingsTable.updatedAt,
  }).from(ucLocationRatingsTable)
    .where(and(eq(ucLocationRatingsTable.locationId, locationId), eq(ucLocationRatingsTable.status, "published")))
    .orderBy(desc(ucLocationRatingsTable.createdAt)).limit(limit).offset((page - 1) * limit);
  const { count: aggregateCount, ...averages } = aggregate ?? {};
  res.json({ locationId, page, limit, count: aggregateCount ?? 0, averages, ratings });
});

router.get("/uc/me/locations/:id/rating", async (req: Request, res: Response): Promise<void> => {
  const userId = await activeQualityUser(req);
  if (!userId) { res.status(401).json({ error: "Authentication required" }); return; }
  const [rating] = await db.select().from(ucLocationRatingsTable).where(and(
    eq(ucLocationRatingsTable.locationId, String(req.params["id"])), eq(ucLocationRatingsTable.userId, userId),
  )).limit(1);
  res.json({ rating: rating ?? null });
});

router.put("/uc/locations/:id/rating", locationQualityLimiter, async (req: Request, res: Response): Promise<void> => {
  const userId = await activeQualityUser(req);
  if (!userId) { res.status(401).json({ error: "Authentication required" }); return; }
  const input = qualityInput(req.body);
  if (!input) { res.status(400).json({ error: "All five scores must be integers from 1 to 5" }); return; }
  const rawComment = req.body && typeof req.body === "object" ? (req.body as Record<string, unknown>).comment : undefined;
  if (rawComment !== undefined && rawComment !== null && (typeof rawComment !== "string" || rawComment.length > 1000)) {
    res.status(400).json({ error: "comment must be at most 1000 characters" }); return;
  }
  const locationId = String(req.params["id"] ?? "");
  const [location] = await db.select({ id: ucLocationsTable.id }).from(ucLocationsTable)
    .where(and(eq(ucLocationsTable.id, locationId), eq(ucLocationsTable.active, true))).limit(1);
  if (!location) { res.status(404).json({ error: "Location not found" }); return; }
  const [rating] = await db.insert(ucLocationRatingsTable).values({
    id: randomUUID(), locationId, userId,
    waterQuality: input.waterQuality, cleanliness: input.cleanliness,
    equipmentCondition: input.equipmentCondition, serviceReliability: input.serviceReliability,
    safetyConfidence: input.safetyConfidence, comment: rawComment as string | null ?? null,
  }).onConflictDoUpdate({ target: [ucLocationRatingsTable.userId, ucLocationRatingsTable.locationId],
    set: { ...input, comment: rawComment as string | null ?? null, status: "published", updatedAt: new Date() },
  }).returning();
  res.json({ rating });
});

router.post("/uc/locations/:locationId/ratings/:ratingId/reports", locationQualityLimiter, async (req: Request, res: Response): Promise<void> => {
  const userId = await activeQualityUser(req);
  if (!userId) { res.status(401).json({ error: "Authentication required" }); return; }
  const reason = req.body?.reason;
  const detail = req.body?.detail;
  if (typeof reason !== "string" || !REPORT_REASONS.has(reason) || (detail !== undefined && (typeof detail !== "string" || detail.length > 500))) {
    res.status(400).json({ error: "Invalid report reason or detail" }); return;
  }
  const locationId = String(req.params["locationId"]);
  const ratingId = String(req.params["ratingId"]);
  try {
    const report = await db.transaction(async (tx) => {
      const [target] = await tx.select({ userId: ucLocationRatingsTable.userId })
        .from(ucLocationRatingsTable).where(and(
          eq(ucLocationRatingsTable.id, ratingId),
          eq(ucLocationRatingsTable.locationId, locationId),
          eq(ucLocationRatingsTable.status, "published"),
        )).limit(1);
      if (!target) throw new Error("RATING_NOT_FOUND");
      if (target.userId === userId) throw new Error("RATING_OWNER");
      const [created] = await tx.insert(ucLocationRatingReportsTable).values({
        id: randomUUID(), ratingId, reporterUserId: userId, reason, detail: detail ?? null,
      }).returning();
      return created;
    });
    res.status(201).json({ report: { id: report.id, reason: report.reason, createdAt: report.createdAt } });
  } catch (error) {
    if (error instanceof Error && error.message === "RATING_NOT_FOUND") {
      res.status(404).json({ error: "Published rating not found for this location" }); return;
    }
    if (error instanceof Error && error.message === "RATING_OWNER") {
      res.status(400).json({ error: "You cannot report your own rating" }); return;
    }
    res.status(409).json({ error: "You have already reported this rating" });
  }
});

router.get("/uc/admin/location-rating-reports", async (req: Request, res: Response): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) { res.status(403).json({ error: "Admin access required" }); return; }
  const reports = await db.select().from(ucLocationRatingReportsTable).orderBy(desc(ucLocationRatingReportsTable.createdAt));
  res.json({ reports });
});
router.patch("/uc/admin/location-ratings/:id/moderation", async (req: Request, res: Response): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) { res.status(403).json({ error: "Admin access required" }); return; }
  const status = req.body?.status;
  if (!["published", "hidden", "removed"].includes(status)) { res.status(400).json({ error: "Invalid moderation status" }); return; }
  const [rating] = await db.update(ucLocationRatingsTable).set({ status, updatedAt: new Date() })
    .where(eq(ucLocationRatingsTable.id, String(req.params["id"]))).returning();
  if (!rating) { res.status(404).json({ error: "Rating not found" }); return; }
  res.json({ rating });
});

router.get("/uc/admin/locations/:id/assessment", async (req: Request, res: Response): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) { res.status(403).json({ error: "Admin access required" }); return; }
  const [assessment] = await db.select().from(ucLocationAssessmentsTable).where(eq(ucLocationAssessmentsTable.locationId, String(req.params["id"]))).limit(1);
  res.json({ assessment: assessment ?? null });
});
router.put("/uc/admin/locations/:id/assessment", async (req: Request, res: Response): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) { res.status(403).json({ error: "Admin access required" }); return; }
  const input = qualityInput(req.body);
  if (!input) { res.status(400).json({ error: "All five scores must be integers from 1 to 5" }); return; }
  const checks = req.body?.checks;
  const notes = req.body?.notes;
  if (checks !== undefined && (typeof checks !== "object" || checks === null || Array.isArray(checks)) || notes !== undefined && (typeof notes !== "string" || notes.length > 2000)) {
    res.status(400).json({ error: "Invalid checks or notes" }); return;
  }
  const claims = verifyToken(req.headers["authorization"]);
  const assessorId = claims?.type === "team-session" ? String(claims.id) : String(userIdFromBearer(req.headers["authorization"]));
  const locationId = String(req.params["id"]);
  const [assessment] = await db.insert(ucLocationAssessmentsTable).values({
    id: randomUUID(), locationId, assessorId,
    waterQuality: input.waterQuality, cleanliness: input.cleanliness,
    equipmentCondition: input.equipmentCondition, serviceReliability: input.serviceReliability,
    safetyConfidence: input.safetyConfidence, checks: JSON.stringify(checks ?? {}), notes: notes ?? null, verifiedAt: new Date(),
  }).onConflictDoUpdate({ target: ucLocationAssessmentsTable.locationId,
    set: { assessorId, ...input, checks: JSON.stringify(checks ?? {}), notes: notes ?? null, status: "verified", verifiedAt: new Date(), updatedAt: new Date() },
  }).returning();
  res.json({ assessment });
});

// ─── Tickets ──────────────────────────────────────────────────────────────────
router.get("/uc/tickets", async (req: Request, res: Response): Promise<void> => {
  const userId = userIdFromBearer(req.headers["authorization"]);
  try {
    const tickets = await db.select().from(ucTicketsTable)
      .where(eq(ucTicketsTable.userId, userId))
      .orderBy(desc(ucTicketsTable.createdAt));
    res.json(tickets);
  } catch {
    res.json(ticketStoreFallback.filter(t => (t as Record<string,unknown>)["userId"] === userId));
  }
});

router.post("/uc/tickets", async (req: Request, res: Response): Promise<void> => {
  const userId = userIdFromBearer(req.headers["authorization"]);
  if (userId === "anonymous") {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  const ticketNumericId = Number(userId);
  if (await guardDeletedAccount(ticketNumericId, res)) return;
  const { productModel, issueDescription, preferredContactTime, photos, videos } = req.body as {
    productModel?: string;
    issueDescription?: string;
    preferredContactTime?: string;
    photos?: string[];
    videos?: string[];
  };
  if (!productModel || !issueDescription) {
    res.status(400).json({ error: "Required fields missing" });
    return;
  }
  const photoList = sanitizeMediaUrls(photos, 6);
  const videoList = sanitizeMediaUrls(videos, 2);
  if (photoList === null || videoList === null) {
    res.status(400).json({ error: "Invalid attachment" });
    return;
  }
  const ticketMediaError = await verifyUploadedMediaItems([
    ...photoList.map((u) => ({ url: u, type: "photo" as const })),
    ...videoList.map((u) => ({ url: u, type: "video" as const })),
  ]);
  if (ticketMediaError) {
    res.status(400).json({ error: ticketMediaError });
    return;
  }
  const id = `TKT-${Date.now()}`;
  /** Build the notification lines for a ticket (shared between DB and fallback paths). */
  function tktNotifyLines(ticketId: string, customerStr: string): string[] {
    return [
      `Ticket:        ${ticketId}`,
      `Product(s):    ${productModel}`,
      `Issue:         ${issueDescription}`,
      `Contact time:  ${preferredContactTime ?? "Any time"}`,
      `Customer:      ${customerStr}`,
      ...(photoList!.length ? [`Photos:        ${photoList!.join(", ")}`] : []),
      ...(videoList!.length ? [`Videos:        ${videoList!.join(", ")}`] : []),
    ];
  }

  /** Fire all post-submission notifications for a ticket. */
  function dispatchTktNotifications(ticketId: string): void {
    getUserContact(userId).then(contact => {
      const customerStr = contact
        ? `${contact.firstName ?? ""} ${contact.email ?? ""} ${contact.phone ?? ""}`.trim()
        : "(guest)";
      const lines   = tktNotifyLines(ticketId, customerStr);
      const subject = `New Service Request ${ticketId}: ${productModel}`;

      if (contact?.phone) {
        sendSms(contact.phone, ticketConfirmationSms({ ticketId, firstName: contact.firstName }), { template: "ticket_confirmation", ticketId });
      }
      if (contact?.email) {
        const receipt = buildTicketConfirmationEmail({
          ticketId, firstName: contact.firstName, email: contact.email,
          productModel: productModel ?? "", issueDescription: issueDescription ?? "",
        });
        sendEmail({ to: contact.email, ...receipt, template: "ticket_confirmation", ticketId }).catch(() => {});
      }
      notifyOffice(subject, lines, { ticketId }).catch(() => {});
      notifyService(subject, [
        ...lines,
        "",
        `Service type:  Maintenance / Support Ticket`,
        `Ticket ref:    ${ticketId}`,
      ], { ticketId }).catch(() => {});
    }).catch(() => {});

    // Local JSONL backup regardless of login state
    appendToLocalStore("tickets.jsonl", {
      id: ticketId, userId, productModel, issueDescription,
      preferredContactTime: preferredContactTime ?? "Any time",
      photos: photoList, videos: videoList, submittedAt: new Date().toISOString(),
    });
  }

  try {
    const [ticket] = await db.insert(ucTicketsTable).values({
      id,
      userId,
      productModel,
      issueDescription,
      preferredContactTime: preferredContactTime ?? "Any time",
      photos: photoList,
      videos: videoList,
    }).returning();
    dispatchTktNotifications(ticket.id);
    res.status(201).json(ticket);
  } catch (err) {
    console.error("[tickets] DB insert failed, using fallback:", err);
    const fallback = {
      id, userId, productModel, issueDescription,
      preferredContactTime: preferredContactTime ?? "Any time",
      photos: photoList,
      videos: videoList,
      status: "submitted",
      createdAt: new Date().toISOString(),
    };
    ticketStoreFallback.push(fallback);
    dispatchTktNotifications(id);
    res.status(201).json(fallback);
  }
});

// ─── Water Tests ──────────────────────────────────────────────────────────────
router.post("/uc/water-tests", async (req: Request, res: Response): Promise<void> => {
  const userId = userIdFromBearer(req.headers["authorization"]);
  if (userId === "anonymous") {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  const wtNumericId = Number(userId);
  if (await guardDeletedAccount(wtNumericId, res)) return;
  const { name, address, phone, email: formEmail, waterSource, concerns, photos, videos } = req.body as {
    name?: string;
    address?: string;
    phone?: string;
    email?: string;
    waterSource?: string;
    concerns?: string;
    photos?: string[];
    videos?: string[];
  };
  if (!name || !address || !phone) {
    res.status(400).json({ error: "Required fields missing" });
    return;
  }
  const photoList = sanitizeMediaUrls(photos, 6);
  const videoList = sanitizeMediaUrls(videos, 2);
  if (photoList === null || videoList === null) {
    res.status(400).json({ error: "Invalid attachment" });
    return;
  }
  const wtMediaError = await verifyUploadedMediaItems([
    ...photoList.map((u) => ({ url: u, type: "photo" as const })),
    ...videoList.map((u) => ({ url: u, type: "video" as const })),
  ]);
  if (wtMediaError) {
    res.status(400).json({ error: wtMediaError });
    return;
  }
  const id = `WT-${Date.now()}`;
  const firstName = name.split(" ")[0] ?? name;

  /** Build the notification lines (shared between DB path and fallback path). */
  function wtNotifyLines(testId: string): string[] {
    return [
      `Request:      ${testId}`,
      `Name:         ${name}`,
      `Phone:        ${phone}`,
      ...(formEmail ? [`Email:        ${formEmail}`] : []),
      `Address:      ${address}`,
      `Water source: ${waterSource ?? "Municipal"}`,
      `Concerns:     ${concerns || "(none given)"}`,
      ...(photoList!.length ? [`Photos:       ${photoList!.join(", ")}`] : []),
      ...(videoList!.length ? [`Videos:       ${videoList!.join(", ")}`] : []),
    ];
  }

  /** Send all post-submission notifications (fire-and-forget). */
  function dispatchWtNotifications(testId: string): void {
    const lines = wtNotifyLines(testId);
    const subject = `New Water Test Request ${testId}: ${name}`;

    // SMS to the phone number given in the form
    sendSms(phone!, waterTestConfirmationSms({ testId, address: address!, firstName }), { template: "water_test_confirmation", testId });

    // Receipt email to submitted address (always, regardless of login)
    const emailTarget = formEmail?.trim() || null;
    if (emailTarget) {
      const receipt = buildWaterTestConfirmationEmail({
        testId, firstName, email: emailTarget,
        address: address!, waterSource: waterSource ?? "Municipal", concerns: concerns ?? "",
      });
      sendEmail({ to: emailTarget, ...receipt, template: "water_test_confirmation", testId }).catch(() => {});
    }

    // If logged in, also send to registered account email (may differ from form email)
    getUserContact(userId).then(contact => {
      if (contact?.email && contact.email !== emailTarget) {
        const receipt = buildWaterTestConfirmationEmail({
          testId, firstName: contact.firstName, email: contact.email,
          address: address!, waterSource: waterSource ?? "Municipal", concerns: concerns ?? "",
        });
        sendEmail({ to: contact.email, ...receipt, template: "water_test_confirmation", testId }).catch(() => {});
      }
    }).catch(() => {});

    // Full copy to sales@ucfilters.com (office) and service@ucfilters.com
    notifyOffice(subject, lines, { testId }).catch(() => {});
    notifyService(subject, [
      ...lines,
      "",
      `Service type: Water Quality Test`,
      `Ticket:       ${testId}`,
    ], { testId }).catch(() => {});

    // Local JSONL backup for retrieval without DB access
    appendToLocalStore("water-tests.jsonl", {
      id: testId, userId, name, phone, email: formEmail ?? null, address,
      waterSource: waterSource ?? "Municipal", concerns: concerns ?? "",
      photos: photoList, videos: videoList, submittedAt: new Date().toISOString(),
    });
  }

  try {
    const [wt] = await db.insert(ucWaterTestsTable).values({
      id, userId, name, address, phone,
      waterSource: waterSource ?? "Municipal",
      concerns:    concerns ?? "",
      photos:      photoList,
      videos:      videoList,
    }).returning();
    dispatchWtNotifications(wt.id);
    res.status(201).json(wt);
  } catch (err) {
    console.error("[water-tests] DB insert failed, using fallback:", err);
    const fallback = {
      id, userId, name, address, phone,
      waterSource: waterSource ?? "Municipal",
      concerns:    concerns ?? "",
      photos:      photoList,
      videos:      videoList,
      status:      "pending",
      createdAt:   new Date().toISOString(),
    };
    waterTestStoreFallback.push(fallback);
    dispatchWtNotifications(id);
    res.status(201).json(fallback);
  }
});

// ─── Inventory: list products with live WooCommerce stock ─────────────────────
// Admin-only. Falls back to the mock product catalogue when WC credentials
// are absent so the page always loads something meaningful in development.
router.get("/uc/admin/inventory", async (req, res): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const syncedAt = new Date().toISOString();

  if (!hasWCCredentials()) {
    const items = MOCK_PRODUCTS.map((p) => ({
      id:            p["id"],
      name:          p["name"],
      sku:           p["sku"] ?? "",
      stockQuantity: typeof p["stockQuantity"] === "number" ? p["stockQuantity"] : 0,
      stockStatus:   p["stockStatus"] ?? "instock",
      permalink:     null,
      syncedAt,
    }));
    res.json({ products: items, source: "mock" });
    return;
  }

  // Fetch all published products from WooCommerce (up to 3 pages × 100)
  const all: Record<string, unknown>[] = [];
  for (let page = 1; page <= 3; page++) {
    const batch = await wcFetchArray("/products", {
      per_page: "100", page: String(page), status: "publish",
    });
    if (!batch || batch.length === 0) break;
    all.push(...batch);
    if (batch.length < 100) break;
  }

  const items = all.map((p) => ({
    id:            p["id"],
    name:          String(p["name"] ?? ""),
    sku:           String(p["sku"] ?? ""),
    stockQuantity: typeof p["stock_quantity"] === "number"
      ? p["stock_quantity"]
      : p["stock_quantity"] != null ? Number(p["stock_quantity"]) : 0,
    stockStatus:   String(p["stock_status"] ?? "instock"),
    permalink:     typeof p["permalink"] === "string" ? p["permalink"] : null,
    syncedAt,
  }));

  res.json({ products: items, source: "woocommerce" });
});

// ─── Inventory: summarize active wishlist demand ─────────────────────────────
// Admin-only. Wishlist rows stay active after a restock notification so the
// team can see both the total demand and whether the current cycle has fired.
router.get("/uc/admin/inventory/wishlist-demand", async (req, res): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  try {
    const rows = await db
      .select({
        productId:                 ucWishlistTable.productId,
        productName:               sql<string>`MAX(${ucWishlistTable.productName})`,
        waitingCustomerCount:      sql<number>`COUNT(*)`,
        pendingCustomerCount:      sql<number>`COUNT(*) FILTER (WHERE ${ucWishlistTable.notifiedRestockAt} IS NULL)`,
        notifiedCustomerCount:     sql<number>`COUNT(*) FILTER (WHERE ${ucWishlistTable.notifiedRestockAt} IS NOT NULL)`,
        lastAddedAt:               sql<Date | null>`MAX(${ucWishlistTable.addedAt})`,
        lastNotifiedRestockAt:     sql<Date | null>`MAX(${ucWishlistTable.notifiedRestockAt})`,
      })
      .from(ucWishlistTable)
      .groupBy(ucWishlistTable.productId)
      .orderBy(desc(sql`COUNT(*)`), asc(sql`MAX(${ucWishlistTable.productName})`));

    const demandAlertStates = rows.length === 0
      ? []
      : await db
        .select({
          productId: ucRestockDemandAlertsTable.productId,
          alertedAt: ucRestockDemandAlertsTable.alertedAt,
        })
        .from(ucRestockDemandAlertsTable)
        .where(inArray(
          ucRestockDemandAlertsTable.productId,
          rows.map((row) => row.productId),
        ));
    const alertedAtByProduct = new Map(
      demandAlertStates.map((state) => [state.productId, state.alertedAt]),
    );

    res.json(rows.map((row) => ({
      productId:             row.productId,
      productName:           row.productName,
      waitingCustomerCount:  Number(row.waitingCustomerCount),
      pendingCustomerCount:  Number(row.pendingCustomerCount),
      notifiedCustomerCount: Number(row.notifiedCustomerCount),
      lastAddedAt:           row.lastAddedAt,
      lastNotifiedRestockAt: row.lastNotifiedRestockAt,
      restockDemandAlertedAt: alertedAtByProduct.get(row.productId) ?? null,
    })));
  } catch (err) {
    logger.error({ err }, "[inventory/wishlist-demand] Failed to load wishlist demand");
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── Admin: edit product details (name, description, price, stock) ────────────
// Forwards a partial update to WooCommerce. All fields are optional — only
// provided keys are forwarded. Falls back to a mock acknowledgement when no
// WC credentials exist so the screen works in dev/demo environments.
router.patch("/uc/admin/products/:id", async (req, res): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const productId = Number(req.params["id"]);
  if (!Number.isInteger(productId) || productId <= 0) {
    res.status(400).json({ error: "Invalid product id" });
    return;
  }

  const body = req.body as {
    name?:             unknown;
    description?:      unknown;
    shortDescription?: unknown;
    regularPrice?:     unknown;
    salePrice?:        unknown;
    stockStatus?:      unknown;
    stockQuantity?:    unknown;
  };

  // Build the WooCommerce payload with only the fields supplied by the caller.
  const wcPayload: Record<string, unknown> = {};

  if (body.name !== undefined) {
    if (typeof body.name !== "string" || !body.name.trim()) {
      res.status(400).json({ error: "name must be a non-empty string" }); return;
    }
    wcPayload["name"] = body.name.trim();
  }
  if (body.description !== undefined) {
    if (typeof body.description !== "string") {
      res.status(400).json({ error: "description must be a string" }); return;
    }
    wcPayload["description"] = body.description;
  }
  if (body.shortDescription !== undefined) {
    if (typeof body.shortDescription !== "string") {
      res.status(400).json({ error: "shortDescription must be a string" }); return;
    }
    wcPayload["short_description"] = body.shortDescription;
  }
  if (body.regularPrice !== undefined) {
    const p = String(body.regularPrice ?? "");
    if (isNaN(parseFloat(p)) || parseFloat(p) < 0) {
      res.status(400).json({ error: "regularPrice must be a non-negative number" }); return;
    }
    wcPayload["regular_price"] = p;
  }
  if (body.salePrice !== undefined) {
    // Empty string removes sale price
    const p = String(body.salePrice ?? "");
    if (p !== "" && (isNaN(parseFloat(p)) || parseFloat(p) < 0)) {
      res.status(400).json({ error: "salePrice must be a non-negative number or empty string" }); return;
    }
    wcPayload["sale_price"] = p;
  }
  if (body.stockStatus !== undefined) {
    if (!["instock", "outofstock", "onbackorder"].includes(String(body.stockStatus))) {
      res.status(400).json({ error: "stockStatus must be 'instock', 'outofstock', or 'onbackorder'" }); return;
    }
    wcPayload["stock_status"] = body.stockStatus;
  }
  if (body.stockQuantity !== undefined) {
    const qty = Number(body.stockQuantity);
    if (!Number.isInteger(qty) || qty < 0) {
      res.status(400).json({ error: "stockQuantity must be a non-negative integer" }); return;
    }
    wcPayload["stock_quantity"] = qty;
    wcPayload["manage_stock"]   = true;
  }

  if (Object.keys(wcPayload).length === 0) {
    res.status(400).json({ error: "No editable fields provided" });
    return;
  }

  if (!hasWCCredentials()) {
    // Dev/demo mode — acknowledge without hitting WooCommerce
    res.json({ ok: true, productId, updated: Object.keys(wcPayload), source: "mock" });
    return;
  }

  try {
    const url = wcUrl(`/products/${productId}`);
    const wcRes = await fetch(url, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(wcPayload),
    });
    const text = await wcRes.text();
    const data = parseWcJson(text) as Record<string, unknown>;

    if (!wcRes.ok) {
      logger.warn({ productId, status: wcRes.status, wcPayload }, "[product-edit] WooCommerce update failed");
      res.status(502).json({
        error:  "WooCommerce update failed",
        detail: String(data?.["message"] ?? wcRes.statusText),
      });
      return;
    }

    logger.info({ productId, updated: Object.keys(wcPayload) }, "[product-edit] product updated in WooCommerce");
    res.json({ ok: true, productId, updated: Object.keys(wcPayload), source: "woocommerce" });
  } catch (err) {
    logger.error({ err, productId }, "[product-edit] WooCommerce PUT error");
    res.status(502).json({ error: "Failed to reach WooCommerce" });
  }
});

// ─── Inventory: update a product's stock quantity in WooCommerce ──────────────
router.patch("/uc/admin/inventory/:productId", async (req, res): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const productId = Number(req.params["productId"]);
  if (!Number.isInteger(productId) || productId <= 0) {
    res.status(400).json({ error: "Invalid productId" });
    return;
  }

  const { stockQuantity } = req.body as { stockQuantity?: unknown };
  if (typeof stockQuantity !== "number" || !Number.isInteger(stockQuantity) || stockQuantity < 0) {
    res.status(400).json({ error: "stockQuantity must be a non-negative integer" });
    return;
  }

  if (!hasWCCredentials()) {
    // Mock mode: acknowledge without actually persisting
    res.json({ ok: true, productId, stockQuantity, source: "mock" });
    return;
  }

  try {
    const url = wcUrl(`/products/${productId}`);
    const wcRes = await fetch(url, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ stock_quantity: stockQuantity, manage_stock: true }),
    });
    const text = await wcRes.text();
    const data = parseWcJson(text) as Record<string, unknown>;

    if (!wcRes.ok) {
      logger.warn({ productId, status: wcRes.status }, "[inventory] WooCommerce stock update failed");
      res.status(502).json({ error: "WooCommerce update failed", detail: String(data?.["message"] ?? wcRes.statusText) });
      return;
    }

    const confirmedQty: number =
      typeof data["stock_quantity"] === "number" ? data["stock_quantity"] : stockQuantity;

    // ── Immediate low-stock alert ─────────────────────────────────────────
    // Fire an email when the newly confirmed quantity is at or below the
    // configured threshold so the team is notified without waiting for the
    // nightly scheduled check. Await it so a shutdown after the response
    // cannot discard the urgent send or its dedupe timestamp.
    await (async () => {
      try {
        let threshold = 5;
        try {
          const { rows } = await pool.query<{ low_stock_threshold: number | null }>(
            "SELECT low_stock_threshold FROM team_settings WHERE id = 'singleton' LIMIT 1",
          );
          if (rows[0]?.low_stock_threshold != null) threshold = rows[0].low_stock_threshold;
        } catch { /* use default */ }

        if (confirmedQty > threshold) return; // still healthy — no alert needed

        const productName = String(data["name"] ?? `Product #${productId}`);
        const productSku  = String(data["sku"]  ?? "");
        const permalink   = typeof data["permalink"] === "string" ? data["permalink"] : null;

        let wcEditUrl = `https://www.ucfilters.com/wp-admin/post.php?post=${productId}&action=edit`;
        if (permalink) {
          try { wcEditUrl = `${new URL(permalink).origin}/wp-admin/post.php?post=${productId}&action=edit`; } catch { /* use default */ }
        }

        const level = confirmedQty === 0 ? "OUT OF STOCK" : "LOW STOCK";
        const subject = confirmedQty === 0
          ? `📦 ${productName} is now out of stock`
          : `📦 Low stock: ${productName} — ${confirmedQty} unit${confirmedQty !== 1 ? "s" : ""} remaining`;

        const body = [
          `${level}: ${productName}${productSku ? ` (SKU ${productSku})` : ""}`,
          ``,
          `Current stock:  ${confirmedQty} unit${confirmedQty !== 1 ? "s" : ""}`,
          `Alert threshold: ≤ ${threshold} units`,
          ``,
          `Edit in WooCommerce: ${wcEditUrl}`,
          ``,
          "You can adjust the alert threshold from ProjectHub → Admin → Inventory → Settings.",
        ].join("\n");

        const emailOk = await sendViaResend({
          from:    "Ultra Clear App <noreply@contacts.ucfilters.com>",
          to:      "info@ucfilters.com",
          subject,
          text:    body,
          meta:    { template: "low_stock_alert" },
        });

        if (emailOk) {
          try {
            await pool.query(
              `INSERT INTO uc_low_stock_alerts (product_id, alerted_at)
               VALUES ($1, now())
               ON CONFLICT (product_id)
               DO UPDATE SET alerted_at =
                 GREATEST(uc_low_stock_alerts.alerted_at, EXCLUDED.alerted_at)`,
              [productId],
            );
          } catch (historyErr) {
            logger.error(
              { historyErr, productId },
              "[inventory] Immediate low-stock email sent but alert history could not be recorded",
            );
          }
          logger.info(
            { productId, productName, confirmedQty, threshold },
            "[inventory] Immediate low-stock alert sent",
          );
        } else {
          logger.warn(
            { productId, productName, confirmedQty, threshold },
            "[inventory] Immediate low-stock alert failed",
          );
        }
      } catch (alertErr) {
        logger.error({ alertErr, productId }, "[inventory] Failed to send immediate low-stock alert");
      }
    })();

    res.json({
      ok: true,
      productId,
      stockQuantity: confirmedQty,
      source: "woocommerce",
    });
  } catch (err) {
    logger.error({ err, productId }, "[inventory] WooCommerce PATCH error");
    res.status(502).json({ error: "Failed to reach WooCommerce" });
  }
});

// ─── Inventory: trigger the n8n inventory-sync webhook ───────────────────────
export const _inventorySyncSeams: {
  getWebhookUrl: (() => Promise<string | null>) | null;
} = { getWebhookUrl: null };

router.post("/uc/admin/inventory/sync", async (req, res): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  // Read and decrypt the configured n8n webhook URL
  let webhookUrl: string | null = null;
  try {
    if (_inventorySyncSeams.getWebhookUrl) {
      webhookUrl = await _inventorySyncSeams.getWebhookUrl();
    } else {
      const { rows } = await pool.query<{ n8n_inventory_webhook_url_enc: string | null }>(
        "SELECT n8n_inventory_webhook_url_enc FROM team_settings WHERE id = 'singleton' LIMIT 1",
      );
      const enc = rows[0]?.n8n_inventory_webhook_url_enc ?? null;
      webhookUrl = enc ? decryptSecret(enc) : null;
    }
  } catch (err) {
    logger.error({ err }, "[inventory/sync] Failed to read n8n webhook URL from DB");
    res.status(500).json({ error: "Internal server error" });
    return;
  }

  if (!webhookUrl) {
    res.status(422).json({
      error: "n8n webhook URL is not configured. Go to Admin → Integrations to set it.",
    });
    return;
  }

  // ssrfSafePost enforces SSRF policy at every request:
  //  • Re-resolves ALL A/AAAA records at request time (defeats DNS rebinding)
  //  • Rejects ANY private/loopback/link-local answer (defeats split-brain DNS)
  //  • Pins the TCP connection to the validated IP via https.request's lookup
  //    callback so the OS cannot re-resolve after our check
  //  • Preserves TLS SNI so the cert is validated against the original hostname
  //  • Does not follow redirects (https.request never auto-follows 3xx)
  const controller = new AbortController();
  const timeoutHandle = setTimeout(() => controller.abort(), 10_000);

  try {
    const statusCode = await ssrfSafePost(
      webhookUrl,
      JSON.stringify({
        trigger:   "manual",
        source:    "projecthub",
        timestamp: new Date().toISOString(),
      }),
      controller.signal,
    );
    clearTimeout(timeoutHandle);

    if (statusCode < 200 || statusCode >= 300) {
      logger.warn({ status: statusCode }, "[inventory/sync] n8n returned non-2xx");
      res.status(502).json({ error: `n8n responded with ${statusCode}` });
      return;
    }

    res.json({ ok: true, triggeredAt: new Date().toISOString() });
  } catch (err) {
    clearTimeout(timeoutHandle);
    if (err instanceof SsrfBlockedError) {
      // DNS rebinding attempt detected at request time — URL passed save-time
      // validation but now resolves to a private address.
      logger.warn({ address: err.address }, "[inventory/sync] SSRF blocked at request time (DNS rebind?)");
      res.status(422).json({
        error: "Webhook URL is no longer valid — it now resolves to a private address. Update it in Admin → Integrations.",
      });
    } else if (err instanceof Error && err.name === "AbortError") {
      logger.warn("[inventory/sync] n8n webhook timed out after 10s");
      res.status(504).json({ error: "n8n webhook timed out (10s) — check that n8n is reachable" });
    } else {
      logger.error({ err }, "[inventory/sync] n8n webhook request failed");
      res.status(502).json({ error: "Failed to reach n8n webhook" });
    }
  }
});

// ─── UC Companion: customer list & detail (admin only) ────────────────────────

router.get("/uc/admin/customers", async (req, res): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  try {
    const q = typeof req.query["q"] === "string"
      ? req.query["q"].trim().replace(/\s+/g, " ")
      : "";
    const from = typeof req.query["from"] === "string" ? req.query["from"].trim() : "";
    const to = typeof req.query["to"] === "string" ? req.query["to"].trim() : "";
    const page = Math.max(1, parseInt(String(req.query["page"] ?? "1"), 10) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(String(req.query["limit"] ?? "50"), 10) || 50));
    const offset = (page - 1) * limit;

    // Build WHERE clauses
    const conditions: string[] = ["u.deleted_at IS NULL"];
    const params: unknown[] = [];
    let pi = 1;

    if (q) {
      conditions.push(
        `(u.email ILIKE $${pi}
          OR u.phone ILIKE $${pi}
          OR u.first_name ILIKE $${pi}
          OR u.last_name ILIKE $${pi}
          OR REGEXP_REPLACE(
               CONCAT_WS(' ', NULLIF(BTRIM(u.first_name), ''), NULLIF(BTRIM(u.last_name), '')),
               '\\s+',
               ' ',
               'g'
             ) ILIKE $${pi})`
      );
      params.push(`%${q}%`);
      pi++;
    }
    if (from) {
      conditions.push(`u.created_at >= $${pi}::timestamptz`);
      params.push(from);
      pi++;
    }
    if (to) {
      conditions.push(`u.created_at < ($${pi}::date + interval '1 day')::timestamptz`);
      params.push(to);
      pi++;
    }

    const where = conditions.join(" AND ");

    // Count total matching rows
    const countRes = await pool.query<{ total: number }>(
      `SELECT COUNT(*)::int AS total FROM uc_users u WHERE ${where}`,
      params
    );
    const total = countRes.rows[0]?.total ?? 0;

    // Fetch paginated customer rows
    const custRes = await pool.query<{
      id: number; email: string; first_name: string; last_name: string;
      phone: string; created_at: string;
    }>(
      `SELECT u.id, u.email, u.first_name, u.last_name, u.phone, u.created_at
       FROM uc_users u
       WHERE ${where}
       ORDER BY u.created_at DESC
       LIMIT $${pi} OFFSET $${pi + 1}`,
      [...params, limit, offset]
    );

    const customerIds = custRes.rows.map((r) => r.id);

    // Fetch order counts and product names for the page of customers
    let orderCountMap: Record<number, number> = {};
    let productNamesMap: Record<number, string[]> = {};

    if (customerIds.length > 0) {
      // We store userId as text in uc_orders; cast for the join
      const idList = customerIds.map(String);
      const orderRes = await pool.query<{ user_id: string; order_count: number }>(
        `SELECT user_id, COUNT(*)::int AS order_count
         FROM uc_orders
         WHERE user_id = ANY($1)
         GROUP BY user_id`,
        [idList]
      );
      for (const row of orderRes.rows) {
        orderCountMap[parseInt(row.user_id, 10)] = row.order_count;
      }

      // Get up to 3 distinct product names per customer from their orders
      const prodRes = await pool.query<{ user_id: string; name: string }>(
        `SELECT DISTINCT ON (o.user_id, oi.name) o.user_id, oi.name
         FROM uc_orders o
         JOIN uc_order_items oi ON oi.order_id = o.id
         WHERE o.user_id = ANY($1)
         ORDER BY o.user_id, oi.name`,
        [idList]
      );
      for (const row of prodRes.rows) {
        const uid = parseInt(row.user_id, 10);
        if (!productNamesMap[uid]) productNamesMap[uid] = [];
        if (productNamesMap[uid].length < 3) productNamesMap[uid].push(row.name);
      }
    }

    const customers = custRes.rows.map((r) => ({
      id: r.id,
      email: r.email,
      firstName: r.first_name,
      lastName: r.last_name,
      name: `${r.first_name} ${r.last_name}`.trim(),
      phone: r.phone,
      joinedAt: r.created_at,
      orderCount: orderCountMap[r.id] ?? 0,
      products: productNamesMap[r.id] ?? [],
    }));

    res.json({ customers, total, page, limit });
  } catch (err) {
    logger.error({ err }, "[customers/list] query failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

// GET /api/uc/admin/customers/export — CSV download of every customer matching
// the current search and joined-date filters. Protected by the same admin gate
// as the paginated customer list.
router.get("/uc/admin/customers/export", async (req: Request, res: Response): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }

  const dateRange = parseDateRange(req, res);
  if (!dateRange) return;

  const q = typeof req.query["q"] === "string" ? req.query["q"].trim() : "";
  const conditions: string[] = ["u.deleted_at IS NULL"];
  const params: unknown[] = [];
  let pi = 1;

  if (q) {
    conditions.push(
      `(u.email ILIKE $${pi} OR u.phone ILIKE $${pi} OR u.first_name ILIKE $${pi} OR u.last_name ILIKE $${pi} OR CONCAT(u.first_name,' ',u.last_name) ILIKE $${pi})`
    );
    params.push(`%${q}%`);
    pi++;
  }
  if (dateRange.from) {
    conditions.push(`u.created_at >= $${pi}::timestamptz`);
    params.push(dateRange.from);
    pi++;
  }
  if (dateRange.to) {
    conditions.push(`u.created_at < ($${pi}::date + interval '1 day')::timestamptz`);
    params.push(dateRange.to);
  }

  try {
    const customerRes = await pool.query<{
      email: string;
      first_name: string;
      last_name: string;
      phone: string;
      created_at: string;
      order_count: number;
    }>(
      `SELECT
         u.email,
         u.first_name,
         u.last_name,
         u.phone,
         u.created_at,
         COUNT(o.id)::int AS order_count
       FROM uc_users u
       LEFT JOIN uc_orders o ON o.user_id = u.id::text
       WHERE ${conditions.join(" AND ")}
       GROUP BY u.id, u.email, u.first_name, u.last_name, u.phone, u.created_at
       ORDER BY u.created_at DESC`,
      params,
    );

    const rows = customerRes.rows.map((customer) => csvRow([
      `${customer.first_name} ${customer.last_name}`.trim(),
      customer.email,
      customer.phone,
      new Date(customer.created_at).toISOString(),
      customer.order_count,
    ]));
    const csv = [
      csvRow(["name", "email", "phone", "joinedDate", "orderCount"]),
      ...rows,
    ].join("\r\n") + "\r\n";

    const filenameParts = [`customers_${new Date().toISOString().slice(0, 10)}`];
    if (q) {
      const safeQuery = q.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40);
      filenameParts.push(`search-${safeQuery || "filtered"}`);
    }
    if (dateRange.from) filenameParts.push(`from-${dateRange.from}`);
    if (dateRange.to) filenameParts.push(`to-${dateRange.to}`);

    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${filenameParts.join("_")}.csv"`);
    res.send(csv);
  } catch (err) {
    req.log.error({ err }, "Failed to export customers CSV");
    res.status(500).json({ error: "Failed to export customers" });
  }
});

// ─── UC Companion: registered customer count ──────────────────────────────────
// Must be registered before /:id so Express doesn't treat "count" as an id.
// Any logged-in team member (admin or regular) can read this count.
// UC-only credentials are not accepted; the endpoint uses the ProjectHub
// team-session JWT issued by POST /api/auth/login.
router.get("/uc/admin/customers/count", async (req, res): Promise<void> => {
  const claims = verifyToken(req.headers["authorization"]);
  if (!claims || claims.type !== "team-session") {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  try {
    // Identity claims alone cannot prove this is still an active team account.
    // Keep member access, but reject deactivated/deleted and legacy principals.
    const [teamUser] = await db.select({ isActive: teamUsersTable.isActive })
      .from(teamUsersTable).where(eq(teamUsersTable.id, String(claims.id))).limit(1);
    if (!teamUser?.isActive) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }
    const { rows } = await pool.query<{ count: number; new_this_week: number; new_this_month: number }>(
      `SELECT
         COUNT(*)::int                                                        AS count,
         COUNT(*) FILTER (WHERE created_at >= date_trunc('week',  now()))::int AS new_this_week,
         COUNT(*) FILTER (WHERE created_at >= date_trunc('month', now()))::int AS new_this_month
       FROM uc_users
       WHERE deleted_at IS NULL`
    );
    const row = rows[0];
    res.json({
      count:        row?.count         ?? 0,
      newThisWeek:  row?.new_this_week  ?? 0,
      newThisMonth: row?.new_this_month ?? 0,
    });
  } catch (err) {
    logger.error({ err }, "[customers/count] query failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── UC Companion: customer detail (admin only) ────────────────────────────────
// Registered after /count so the static segment takes precedence.
router.get("/uc/admin/customers/:id", async (req, res): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  const customerId = parseInt(req.params["id"] ?? "", 10);
  if (!customerId || customerId < 1) {
    res.status(400).json({ error: "Invalid customer id" });
    return;
  }
  try {
    const custRes = await pool.query<{
      id: number; email: string; first_name: string; last_name: string;
      phone: string; created_at: string; auth_provider: string;
      email_verified: boolean; phone_verified: boolean;
    }>(
      `SELECT id, email, first_name, last_name, phone, created_at, auth_provider,
              email_verified, phone_verified
       FROM uc_users WHERE id = $1 AND deleted_at IS NULL`,
      [customerId]
    );
    if (!custRes.rows[0]) {
      res.status(404).json({ error: "Customer not found" });
      return;
    }
    const cu = custRes.rows[0];

    // Recent orders (last 10)
    const ordersRes = await pool.query<{
      id: number; status: string; total: string; currency: string;
      payment_method: string; date_created: string;
    }>(
      `SELECT id, status, total, currency, payment_method, date_created
       FROM uc_orders WHERE user_id = $1 ORDER BY date_created DESC LIMIT 10`,
      [String(customerId)]
    );

    let ordersWithItems: {
      id: number; status: string; total: string; currency: string;
      paymentMethod: string; dateCreated: string;
      lineItems: { name: string; quantity: number; total: string }[];
    }[] = [];

    if (ordersRes.rows.length > 0) {
      const orderIds = ordersRes.rows.map((r) => r.id);
      const itemsRes = await pool.query<{
        order_id: number; name: string; quantity: number; total: string;
      }>(
        `SELECT order_id, name, quantity, total FROM uc_order_items WHERE order_id = ANY($1)`,
        [orderIds]
      );
      const itemsByOrder: Record<number, { name: string; quantity: number; total: string }[]> = {};
      for (const item of itemsRes.rows) {
        if (!itemsByOrder[item.order_id]) itemsByOrder[item.order_id] = [];
        itemsByOrder[item.order_id].push({ name: item.name, quantity: item.quantity, total: item.total });
      }
      ordersWithItems = ordersRes.rows.map((o) => ({
        id: o.id,
        status: o.status,
        total: o.total,
        currency: o.currency,
        paymentMethod: o.payment_method,
        dateCreated: o.date_created,
        lineItems: itemsByOrder[o.id] ?? [],
      }));
    }

    // Recent tickets (last 10)
    const ticketsRes = await pool.query<{
      id: string; product_model: string; issue_description: string;
      status: string; created_at: string;
    }>(
      `SELECT id, product_model, issue_description, status, created_at
       FROM uc_tickets WHERE user_id = $1 ORDER BY created_at DESC LIMIT 10`,
      [String(customerId)]
    );

    res.json({
      customer: {
        id: cu.id,
        email: cu.email,
        firstName: cu.first_name,
        lastName: cu.last_name,
        name: `${cu.first_name} ${cu.last_name}`.trim(),
        phone: cu.phone,
        joinedAt: cu.created_at,
        authProvider: cu.auth_provider,
         emailVerified: cu.email_verified === true,
         phoneVerified: cu.phone_verified === true,
         recoveryChannels: {
           email: {
             available: cu.email_verified === true && Boolean(cu.email.trim()),
             verified: cu.email_verified === true,
           },
           whatsapp: {
             available: cu.phone_verified === true && Boolean(normalizePhone(cu.phone)),
             verified: cu.phone_verified === true,
             status: getWhatsAppStatus().state,
           },
         },
      },
      orders: ordersWithItems,
      tickets: ticketsRes.rows.map((t) => ({
        id: t.id,
        productModel: t.product_model,
        issueDescription: t.issue_description,
        status: t.status,
        createdAt: t.created_at,
      })),
    });
  } catch (err) {
    logger.error({ err }, "[customers/detail] query failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

// ─── Wishlist ─────────────────────────────────────────────────────────────────
// Three endpoints let the Companion app add / remove / list wishlist items for
// out-of-stock products. The scheduler periodically checks whether any wishlisted
// product has come back in stock and fires push notifications automatically.

/** GET /api/uc/wishlist — return the authenticated user's wishlist. */
router.get("/uc/wishlist", async (req: Request, res: Response): Promise<void> => {
  const claims = verifyToken(req.headers["authorization"]);
  if (!claims) { res.status(401).json({ error: "Authentication required" }); return; }
  const userId = String(claims.id);
  try {
    const rows = await db
      .select()
      .from(ucWishlistTable)
      .where(eq(ucWishlistTable.userId, userId))
      .orderBy(desc(ucWishlistTable.addedAt));
    res.json(rows.map((r) => ({
      id:                r.id,
      productId:         r.productId,
      productName:       r.productName,
      addedAt:           r.addedAt,
      notifiedRestockAt: r.notifiedRestockAt,
    })));
  } catch (err) {
    logger.error({ err, userId }, "Wishlist GET failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

/** POST /api/uc/wishlist — add a product; idempotent (upserts). */
router.post("/uc/wishlist", async (req: Request, res: Response): Promise<void> => {
  const claims = verifyToken(req.headers["authorization"]);
  if (!claims) { res.status(401).json({ error: "Authentication required" }); return; }
  const userId = String(claims.id);

  const { productId, productName } = req.body as {
    productId?: unknown; productName?: unknown;
  };
  if (!productId || typeof productId !== "number") {
    res.status(400).json({ error: "productId (number) is required" }); return;
  }
  if (!productName || typeof productName !== "string" || !productName.trim()) {
    res.status(400).json({ error: "productName (string) is required" }); return;
  }

  try {
    const [row] = await db
      .insert(ucWishlistTable)
      .values({ userId, productId, productName: productName.trim() })
      .onConflictDoUpdate({
        target: [ucWishlistTable.userId, ucWishlistTable.productId],
        set: { productName: productName.trim() },
      })
      .returning();

    // Wishlist membership is the out-of-stock demand signal. Evaluate it
    // before responding so the threshold crossing is not delayed until the
    // four-hour scheduler check. The scheduler uses the same atomic claim and
    // provider idempotency key as this request path.
    try {
      const demandThreshold = await getRestockDemandThreshold();
      const demandResult = await checkRestockDemandForProduct({
        productId,
        stockStatus: "outofstock",
        deps: {
          threshold: demandThreshold,
          sendEmail: sendViaResend,
          getAlertEmail: getTeamAlertEmail,
          inventoryUrl: projectHubInventoryUrl(),
        },
      });
      if (demandResult === "failed") {
        logger.warn({ productId }, "Wishlist POST: restock-demand alert email failed");
      }
    } catch (err) {
      // The customer must still be able to join the waiting list if alert
      // delivery is temporarily unavailable; the scheduled check retries it.
      logger.warn({ err, productId }, "Wishlist POST: restock-demand evaluation failed");
    }

    res.status(201).json({
      id:          row!.id,
      productId:   row!.productId,
      productName: row!.productName,
      addedAt:     row!.addedAt,
    });
  } catch (err) {
    logger.error({ err, userId, productId }, "Wishlist POST failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

/** DELETE /api/uc/wishlist/:productId — remove a product from the wishlist. */
router.delete("/uc/wishlist/:productId", async (req: Request, res: Response): Promise<void> => {
  const claims = verifyToken(req.headers["authorization"]);
  if (!claims) { res.status(401).json({ error: "Authentication required" }); return; }
  const userId = String(claims.id);

  const pid = parseInt(String(req.params["productId"] ?? ""), 10);
  if (isNaN(pid)) { res.status(400).json({ error: "Invalid productId" }); return; }

  try {
    await db
      .delete(ucWishlistTable)
      .where(and(eq(ucWishlistTable.userId, userId), eq(ucWishlistTable.productId, pid)));
    res.json({ ok: true });
  } catch (err) {
    logger.error({ err, userId, productId: pid }, "Wishlist DELETE failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;

export async function wcCreateCheckoutOrder(payload: unknown): Promise<Record<string, unknown> | null> {
  void payload;
  return null;
}

export function invalidateCatalogueCache(): void {
  catalogueCache.invalidate();
}

export function hasCompanionCatalogue(): boolean {
  return true;
}

const catalogueCache = new CatalogueCache<{
  payload: Record<string, unknown>[];
  publishedSource: boolean;
}>();

router.patch("/uc/orders/:id/status", async (req: Request, res: Response): Promise<void> => {
  if (!(await isAdminRequest(req.headers["authorization"]))) {
    res.status(403).json({ error: "Admin access required" }); return;
  }
  const id = Number(req.params["id"]);
  const body = req.body ?? {};
  if (!Number.isSafeInteger(id) || id <= 0 || !["shipped", "ready-to-collect"].includes(body.status)) {
    res.status(400).json({ error: "A valid order id and status (shipped or ready-to-collect) are required" }); return;
  }
  const details: Record<string, string> = {};
  for (const [key, max] of Object.entries({
    trackingNumber: 100, trackingUrl: 2048, estimatedDelivery: 10, collectionLocation: 300, note: 500,
  })) {
    if (body[key] === undefined) continue;
    if (typeof body[key] !== "string" || body[key].length > max || /[\u0000-\u001f\u007f]/.test(body[key])) {
      res.status(400).json({ error: `Invalid ${key}` }); return;
    }
    const value = body[key].trim();
    if (value) details[key] = value;
  }
  if (details.estimatedDelivery &&
      (!/^\d{4}-\d{2}-\d{2}$/.test(details.estimatedDelivery) ||
       Number.isNaN(Date.parse(details.estimatedDelivery)) ||
       new Date(details.estimatedDelivery).toISOString().slice(0, 10) !== details.estimatedDelivery)) {
    res.status(400).json({ error: "estimatedDelivery must be a valid YYYY-MM-DD date" }); return;
  }
  if (details.trackingUrl) {
    try {
      const url = new URL(details.trackingUrl);
      if (!["http:", "https:"].includes(url.protocol) || url.username || url.password) throw new Error();
    } catch {
      res.status(400).json({ error: "trackingUrl must be an HTTP or HTTPS URL without credentials" }); return;
    }
  }
  if (body.status === "ready-to-collect" && !details.collectionLocation) {
    res.status(400).json({ error: "collectionLocation is required for ready-to-collect orders" }); return;
  }
  if (body.idempotencyKey !== undefined &&
      (typeof body.idempotencyKey !== "string" || !body.idempotencyKey.trim() || body.idempotencyKey.length > 200)) {
    res.status(400).json({ error: "Invalid idempotencyKey" }); return;
  }
  try {
    const saved = await transitionOrderStatus({
      orderId: id, status: body.status, customerStage: "shipped",
      fulfillment: details,
      eventKey: `fulfillment:${id}:${body.idempotencyKey?.trim() ?? body.status}`,
      actor: String(verifyToken(req.headers["authorization"])?.id ?? "admin"),
      source: "staff",
    });
    res.json({
      ok: true, id, status: saved.status, customerStage: saved.customerStage, repeated: saved.repeated,
      notification: { status: saved.outboxCreated ? "queued" : "skipped", channels: ["sms", "push", "email"] },
    });
  } catch (err) {
    const error = err as Error & { code?: string };
    if (error.code === "NOT_FOUND") res.status(404).json({ error: error.message });
    else if (error.code === "INVALID_STAGE_TRANSITION") res.status(409).json({ error: error.message });
    else {
      logger.error({ err, orderId: id }, "Failed to update order fulfillment");
      res.status(500).json({ error: "Failed to update order fulfillment" });
    }
  }
});

export async function notifyConfirmedCheckout(order: any) {
  await reconcileCanonicalPurchaseDualWrite(order.id, `checkout:${order.id}`);
  if (order.payment_method !== "cod" && order.payment_method !== "free") {
    await enqueueReferralSettlement(order.id);
    const userId = Number(order.user_id);
    if (Number.isInteger(userId) && userId > 0) await creditQualifyingProductPoints(userId, order.id);
  }
  const response = await checkoutOrderResponse(order);
  sendPushToUser(order.user_id, "Order confirmed", `Order #${response.id} confirmed for ${response.fulfillment === "collection" ? "collection" : "delivery"}.`,
    { screen: "orders", orderId: String(response.id) }, "orders");
  sendOrderConfirmationEmail(order.user_id, { orderId: response.id, lineItems: response.lineItems,
    total: response.total, currency: response.currency, paymentMethod: order.payment_method,
    shippingAddress: response.shippingAddress, discountAmount: response.discountAmount, promoCode: response.promoCode,
    dateCreated: response.dateCreated, paymentStatus: response.paymentStatus,
    paymentReference: order.payment_method === "cod" ? "" : order.mpesa_receipt || order.payment_reference });
}

export function legacyCallbackPricedLines(lineItems: { productId: number; quantity: number }[], allowEmpty = false) {
  if (!Array.isArray(lineItems) || (!lineItems.length && !allowEmpty)) return null;
  const lines = lineItems.map((item) => {
    const productId = Number(item.productId), quantity = Number(item.quantity);
    const product = MOCK_PRODUCTS.find((candidate) => candidate["id"] === productId);
    if (!product || !Number.isInteger(quantity) || quantity <= 0) return null;
    const price = Number(product["price"]);
    if (!Number.isFinite(price) || price < 0) return null;
    return { productId, name: String(product["name"]), quantity, subtotal: price * quantity };
  });
  return lines.some((line) => !line) ? null : lines as { productId: number; name: string; quantity: number; subtotal: number }[];
}
